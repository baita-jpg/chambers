<?php
/**
 * Niger Fintech System - Login Page
 */

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/includes/auth.php';
// Top of login.php
require_once 'includes/functions.php';

// Check for remember-me cookie before any other output
checkRememberMeCookie();

// Redirect if already logged in
if (isLoggedIn()) {
    $user = getCurrentUser();
    switch ($user['user_type']) {
        case 'admin':
            header('Location: admin/dashboard.php');
            break;
        case 'agent':
        case 'super_agent':
            header('Location: agent/dashboard.php');
            break;
        default:
            header('Location: customer/dashboard.php');
    }
    exit;
}

$error = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    // Ensure checkRateLimit exists in functions.php, otherwise this will throw a fatal error.
    $rateLimitCheck = function_exists('checkRateLimit') ? checkRateLimit('login_fail', $ipAddress, 5, 300) : ['is_blocked' => false];

    if ($rateLimitCheck['is_blocked']) {
        $error = $rateLimitCheck['message'];
    } elseif (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Zama mara inganci. Da fatan za a sake gwadawa.';
    } else {
        $phone = sanitizeInput($_POST['phone'] ?? '');
        $pin = $_POST['pin'] ?? '';
        
        if (empty($phone) || empty($pin)) {
            $error = 'Da fatan za a shigar da lambar wayar ka da kuma PIN.';
        } else {
            $result = authenticateUser($phone, $pin);
            
            if ($result['success']) {
                if (function_exists('clearRateLimit')) {
                    clearRateLimit('login_fail', $ipAddress);
                }
                // Redirect to 2FA Page
                header('Location: login-2fa.php');
                exit;
            } else {
                if (function_exists('incrementRateLimit')) {
                    incrementRateLimit('login_fail', $ipAddress, 300);
                }
                $error = $result['message'];
            }
        }
    }
}

$pageTitle = 'Shiga - NigerPay';
?>
<!DOCTYPE html>
<html lang="ha">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
                    colors: {
                        primary: { 50: '#f0fdfa', 100: '#ccfbf1', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e', 800: '#115e59' }
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
        .pin-input { letter-spacing: 0.5em; text-align: center; font-variant-numeric: tabular-nums; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .fade-in { animation: fadeIn 0.3s ease-in; }
    </style>
</head>
<body class="bg-gradient-to-br from-primary-700 via-primary-800 to-primary-900 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <div class="text-center mb-8 fade-in">
            <div class="w-20 h-20 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
                <i class="fas fa-wallet text-primary-700 text-3xl"></i>
            </div>
            <h1 class="text-2xl font-bold text-white mb-1">NigerPay</h1>
            <p class="text-primary-100 text-sm">Jakar kuɗin ku ta wayar hannu mai aminci</p>
        </div>
        
        <div class="bg-white rounded-2xl shadow-2xl overflow-hidden fade-in">
            <div class="p-6 sm:p-8">
                <h2 class="text-xl font-semibold text-gray-900 mb-1">Shiga Cikin Asusunka</h2>
                <p class="text-gray-500 text-sm mb-6">Shigar da bayanan ka don shiga asusunka</p>
                
                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-center">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <span class="text-sm"><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" class="space-y-5" onsubmit="return handleFormSubmit(this);">
                    <?php if(function_exists('csrfField')) csrfField(); ?>
                    
                    <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">
                            Lambar Waya
                        </label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-phone text-gray-400"></i>
                            </div>
                            <input 
                                type="tel" 
                                id="phone" 
                                name="phone" 
                                value="<?php echo htmlspecialchars($phone); ?>"
                                placeholder="XX XX XX XX" 
                                class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition text-lg"
                                required
                                autocomplete="tel"
                                maxlength="14"
                                oninput="formatPhoneInput(this)"
                            >
                        </div>
                    </div>
                    
                    <div>
                        <label for="pin" class="block text-sm font-medium text-gray-700 mb-1" lang="ha">
                            Lambar PIN
                        </label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                            <input 
                                type="password" 
                                id="pin" 
                                name="pin" 
                                placeholder="••••••" 
                                class="pin-input w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition text-lg"
                                required
                                maxlength="6"
                                inputmode="numeric"
                                autocomplete="current-password"
                            >
                            <button 
                                type="button" 
                                onclick="togglePinVisibility()"
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 focus:outline-none"
                            >
                                <i class="fas fa-eye" id="toggleIcon"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="flex items-center justify-between">
                        <label class="flex items-center cursor-pointer">
                            <input type="checkbox" name="remember" class="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500">
                            <span class="ml-2 text-sm text-gray-600">Tuna da ni</span>
                        </label>
                        <a href="forgot-pin.php" class="text-sm text-primary-600 hover:text-primary-700 font-medium">
                            An manta PIN?
                        </a>
                    </div>
                    
                    <button 
                        type="submit" 
                        id="submitBtn"
                        class="w-full bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-200 flex items-center justify-center btn-press"
                    >
                        <span>Shiga</span>
                        <i class="fas fa-arrow-right ml-2"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function togglePinVisibility() {
            const pinInput = document.getElementById('pin');
            const toggleIcon = document.getElementById('toggleIcon');
            if (pinInput.type === 'password') {
                pinInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                pinInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
        
        function formatPhoneInput(input) {
            let value = input.value.replace(/[^\d]/g, '');
            if (value.startsWith('227')) value = value.substring(3);
            if (value.length > 8) value = value.substring(0, 8);
            if (value.length >= 2) value = value.replace(/(\d{2})(?=(\d{2})+$)/g, '$1 ');
            input.value = value;
        }
        
        // FIX: Handle form submission correctly without blocking the POST request
        function handleFormSubmit(form) {
            const btn = document.getElementById('submitBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Ana shiga...';
            btn.classList.add('opacity-75', 'cursor-not-allowed');
            
            // Allow the form data to be submitted before disabling the button
            setTimeout(() => {
                btn.disabled = true;
            }, 10);
            return true;
        }
        
        document.getElementById('pin').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '').slice(0, 6);
        });
        
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('phone').focus();
        });
    </script>
</body>
</html>