<?php
/**
 * Niger Fintech System - Two-Factor Authentication
 */

// Temporarily display errors in case something else is broken
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/includes/auth.php'; // Includes functions.php

$currentLang = getCurrentLanguage();

startSecureSession();

// Redirect if user isn't in the middle of a 2FA check
if (!isset($_SESSION['2fa_pending_user_id'])) {
    header('Location: login.php');
    exit;
}

$error = '';
$successMessage = '';
$phoneNumber = $_SESSION['2fa_pending_phone'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    
    // Check if the user is requesting a new OTP
    if (isset($_POST['action']) && $_POST['action'] === 'resend') {
        $resendLimitCheck = function_exists('checkRateLimit') ? checkRateLimit('otp_resend', $ipAddress, 3, 300) : ['is_blocked' => false];
        
        if ($resendLimitCheck['is_blocked']) {
            $error = $resendLimitCheck['message'];
        } else {
            if (function_exists('incrementRateLimit')) {
                incrementRateLimit('otp_resend', $ipAddress, 300);
            }
            generateOTP($phoneNumber);
            $successMessage = ($currentLang === 'ha') ? 'An sake aiko da sabon lambar.' : 'Un nouveau code a été envoyé.';
        }
    } 
    // Otherwise, process the OTP submission
    else {
        $rateLimitCheck = function_exists('checkRateLimit') ? checkRateLimit('otp_fail', $ipAddress, 4, 600) : ['is_blocked' => false];

        if ($rateLimitCheck['is_blocked']) {
            $error = $rateLimitCheck['message'];
        } elseif (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
            $error = ($currentLang === 'ha') ? 'Zama mara inganci. Da fatan za a sake gwadawa.' : 'Session invalide. Veuillez réessayer.';
        } else {
            $otp = $_POST['otp'] ?? '';

            if (empty($otp)) {
                $error = ($currentLang === 'ha') ? 'Da fatan za a shigar da lambar tantancewa.' : 'Veuillez saisir le code de vérification.';
            } else {
                // Verify the OTP
                if (verifyOTP($otp, $phoneNumber)) {
                    $db = getDB();
                    
                    // Get user data
                    $stmt = $db->prepare("
                        SELECT u.*, wa.id as wallet_id, wa.balance, wa.available_balance, wa.account_number
                        FROM users u
                        LEFT JOIN wallet_accounts wa ON u.id = wa.user_id AND wa.account_type = 'primary'
                        WHERE u.id = ?
                    ");
                    $stmt->execute([$_SESSION['2fa_pending_user_id']]);
                    $user = $stmt->fetch();

                    if ($user) {
                        // Update last login time
                        $stmt = $db->prepare("UPDATE users SET last_login_at = NOW() WHERE id = ?");
                        $stmt->execute([$user['id']]);

                        // Create the final user session
                        createUserSession($user);

                        // Check if "Remember Me" was selected
                        if (isset($_SESSION['2fa_remember_me']) && $_SESSION['2fa_remember_me']) {
                            rememberUser($user['id']);
                        }

                        // Log successful login
                        logActivity('users', $user['id'], 'LOGIN_2FA_SUCCESS', [], ['ip' => $_SERVER['REMOTE_ADDR']]);
                        
                        // Clean up 2FA session variables
                        unset($_SESSION['2fa_pending_user_id']);
                        unset($_SESSION['2fa_pending_phone']);
                        unset($_SESSION['2fa_remember_me']);

                        if (function_exists('clearRateLimit')) clearRateLimit('otp_fail', $ipAddress);
                        
                        // Redirect to the appropriate dashboard
                        $redirect = 'customer/dashboard.php';
                        if ($user['user_type'] === 'agent' || $user['user_type'] === 'super_agent') {
                            $redirect = 'agent/dashboard.php';
                        } elseif ($user['user_type'] === 'admin') {
                            $redirect = 'admin/dashboard.php';
                        }
                        header("Location: " . $redirect);
                        exit;
                    } else {
                        $error = ($currentLang === 'ha') ? 'Ba a sami mai amfani ba. Da fatan za a sake gwada shiga.' : 'Utilisateur non trouvé. Veuillez réessayer de vous connecter.';
                    }
                } else {
                    if (function_exists('incrementRateLimit')) incrementRateLimit('otp_fail', $ipAddress, 600);
                    $error = ($currentLang === 'ha') ? 'Lambar tantancewa ba daidai ba ko ta ƙare.' : 'Code de vérification incorrect ou expiré.';
                    logActivity('users', $_SESSION['2fa_pending_user_id'], 'LOGIN_2FA_FAILED', [], ['ip' => $_SERVER['REMOTE_ADDR']]);
                }
            }
        }
    }
}

$pageTitle = ($currentLang === 'ha') ? 'Tabbatarwa Mataki Biyu - NigerPay' : 'Vérification en deux étapes - NigerPay';
?>
<!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
                    colors: {
                        primary: { 50: '#f0fdfa', 100: '#ccfbf1', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e', 800: '#115e59' }
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .fade-in { animation: fadeIn 0.3s ease-in; }
    </style>
</head>
<body class="bg-gradient-to-br from-primary-700 via-primary-800 to-primary-900 min-h-screen flex items-center justify-center p-4">

<div class="max-w-md w-full">
    <div class="bg-white rounded-2xl shadow-2xl overflow-hidden p-6 sm:p-8 fade-in">
        <div class="text-center mb-6">
            <div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-shield-alt text-primary-600 text-2xl"></i>
            </div>
            <h2 class="text-2xl font-bold text-gray-900" <?php echo function_exists('getLangAttribute') ? getLangAttribute() : ''; ?>>
                <?php echo ($currentLang === 'ha') ? 'Ana Bukatar Tabbatarwa' : 'Vérification requise'; ?>
            </h2>

             <div class="bg-yellow-100 text-yellow-800 p-2 rounded mb-4 font-mono text-xl">
                TEST OTP: <?php echo $_SESSION['otp']['code'] ?? 'EXPIRED'; ?>
            </div>
            
            <div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-shield-alt text-primary-600 text-2xl"></i>
            </div>

            <p class="mt-2 text-sm text-gray-500" <?php echo function_exists('getLangAttribute') ? getLangAttribute() : ''; ?>>
                <?php echo ($currentLang === 'ha') ? 'An aiko da lamba zuwa wayarka' : 'Un code a été envoyé à votre numéro'; ?><br>
                <strong class="font-semibold text-gray-800"><?php echo htmlspecialchars($phoneNumber); ?></strong>
            </p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-center text-sm">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($successMessage): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 flex items-center text-sm">
                <i class="fas fa-check-circle mr-2"></i>
                <span><?php echo htmlspecialchars($successMessage); ?></span>
            </div>
        <?php endif; ?>

        <form id="otpForm" class="space-y-6" method="POST" action="" onsubmit="return handleFormSubmit();">
            <?php if(function_exists('csrfField')) csrfField(); ?>
            
            <div>
                <label for="otp" class="sr-only"><?php echo ($currentLang === 'ha') ? 'Lambar tantancewa' : 'Code de vérification'; ?></label>
                <input 
                    id="otp" 
                    name="otp" 
                    type="text" 
                    inputmode="numeric" 
                    required 
                    class="appearance-none rounded-lg relative block w-full px-3 py-4 border border-gray-300 placeholder-gray-400 text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 sm:text-2xl font-bold text-center tracking-[0.5em] transition" 
                    placeholder="------" 
                    maxlength="6" 
                    autofocus
                >
            </div>

            <button 
                type="submit" 
                id="submitBtn"
                class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-semibold text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition duration-200" 
                <?php echo function_exists('getLangAttribute') ? getLangAttribute() : ''; ?>
            >
                <i class="fas fa-check-circle mr-2 mt-0.5"></i>
                <span><?php echo ($currentLang === 'ha') ? 'Tabbatar & Shiga' : 'Vérifier et se connecter'; ?></span>
            </button>
        </form>

        <form method="POST" action="" class="mt-4 text-center">
            <?php if(function_exists('csrfField')) csrfField(); ?>
            <input type="hidden" name="action" value="resend">
            <button type="submit" class="text-sm font-medium text-gray-500 hover:text-primary-600 transition" <?php echo function_exists('getLangAttribute') ? getLangAttribute() : ''; ?>>
                <?php echo ($currentLang === 'ha') ? 'Ban sami lamba ba? Sake aiko da sabon' : 'Code non reçu? Renvoyer'; ?>
            </button>
        </form>

        <div class="mt-6 border-t border-gray-100 pt-6 text-center text-sm">
            <a href="login.php" class="font-medium text-primary-600 hover:text-primary-700 transition" <?php echo function_exists('getLangAttribute') ? getLangAttribute() : ''; ?>>
                <i class="fas fa-arrow-left mr-1"></i>
                <?php echo ($currentLang === 'ha') ? 'Komawa zuwa shiga' : 'Retour à la connexion'; ?>
            </a>
        </div>
    </div>
</div>

<script>
    document.getElementById('otp').addEventListener('input', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '').slice(0, 6);
        
        if (this.value.length === 6) {
            handleFormSubmit();
            document.getElementById('otpForm').submit();
        }
    });

    function handleFormSubmit() {
        const btn = document.getElementById('submitBtn');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2 mt-0.5"></i> <span><?php echo ($currentLang === 'ha') ? "Ana tabbatarwa..." : "Vérification..."; ?></span>';
        btn.classList.add('opacity-75', 'cursor-not-allowed');
        
        setTimeout(() => {
            btn.disabled = true;
        }, 10);
        return true;
    }
</script>

</body>
</html>