<?php
/**
 * NigerPay - Airtime & Data Recharge
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'customer') {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$balance = getAccountBalance($currentUser['id'], 'primary')['available_balance'] ?? 0;

$pageTitle = $isHausa ? 'Sayan Kati' : 'Recharge Crédit';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto pb-20">
    <div class="mb-8 px-2">
        <h1 class="text-2xl font-black text-slate-900"><?php echo $isHausa ? 'Sayan Kati' : 'Recharge Airtime'; ?></h1>
        <p class="text-slate-500 text-sm"><?php echo $isHausa ? 'Saka kati a kowace lamba' : 'Créditez n\'importe quel numéro au Niger'; ?></p>
    </div>

    
    <div class="space-y-4 mb-8">
        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2"><?php echo $isHausa ? 'Zaɓi Kamfani' : 'Choisir l\'opérateur'; ?></label>
        <div class="grid grid-cols-4 gap-3">
            <button onclick="selectOperator('Airtel', '#ed1c24')" class="operator-btn group bg-white border-2 border-slate-50 p-3 rounded-2xl transition-all hover:border-red-500">
                <div class="w-full aspect-square bg-red-50 rounded-xl flex items-center justify-center text-red-600 font-black">A</div>
            </button>
            <button onclick="selectOperator('Moov', '#005da9')" class="operator-btn group bg-white border-2 border-slate-50 p-3 rounded-2xl transition-all hover:border-blue-500">
                <div class="w-full aspect-square bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 font-black">M</div>
            </button>
            <button onclick="selectOperator('Orange', '#ff7900')" class="operator-btn group bg-white border-2 border-slate-50 p-3 rounded-2xl transition-all hover:border-orange-500">
                <div class="w-full aspect-square bg-orange-50 rounded-xl flex items-center justify-center text-orange-600 font-black">O</div>
            </button>
            <button onclick="selectOperator('Zamani', '#7030a0')" class="operator-btn group bg-white border-2 border-slate-50 p-3 rounded-2xl transition-all hover:border-purple-500">
                <div class="w-full aspect-square bg-purple-50 rounded-xl flex items-center justify-center text-purple-600 font-black">Z</div>
            </button>
        </div>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-8">
        <form id="airtimeForm" class="space-y-6">
            <?php csrfField(); ?>
            <input type="hidden" id="selected_operator" name="operator" value="">

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Lambar Waya' : 'Numéro de téléphone'; ?></label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 pl-5 flex items-center text-slate-400 font-bold">+227</span>
                    <input type="tel" name="phone" value="<?php echo $currentUser['phone_number']; ?>" 
                           class="w-full pl-16 pr-4 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-bold text-xl">
                </div>
                <button type="button" class="text-[10px] font-black text-primary-600 uppercase tracking-tight px-2"><?php echo $isHausa ? 'Amfani da lamba ta' : 'Utiliser mon numéro'; ?></button>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Adadin Kuɗi' : 'Montant'; ?></label>
                <div class="relative">
                    <input type="number" id="airtime_amount" name="amount" placeholder="0" 
                           class="w-full px-6 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-black text-3xl">
                    <span class="absolute inset-y-0 right-0 pr-6 flex items-center text-slate-400 font-black">XOF</span>
                </div>
            </div>

            <div class="grid grid-cols-3 gap-2">
                <?php foreach([200, 500, 1000, 2000, 5000, 10000] as $val): ?>
                    <button type="button" onclick="document.getElementById('airtime_amount').value=<?php echo $val; ?>" 
                            class="py-2 bg-slate-50 rounded-xl text-xs font-bold text-slate-600 border border-slate-100 hover:bg-slate-200 transition-colors">
                        <?php echo number_format($val, 0); ?>
                    </button>
                <?php endforeach; ?>
            </div>

            <div class="pt-4 border-t border-slate-50 flex justify-between items-center text-xs">
                <span class="font-bold text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Ragowar Kuɗi' : 'Votre solde'; ?></span>
                <span class="font-black text-slate-900"><?php echo number_format($balance, 0, ',', ' '); ?> XOF</span>
            </div>

            <button type="button" onclick="processAirtime()" 
                    class="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-xl transition-all active:scale-95 flex items-center justify-center">
                <span><?php echo $isHausa ? 'SAYA YANZU' : 'ACHETER MAINTENANT'; ?></span>
                <i class="fas fa-bolt ml-2 text-yellow-400"></i>
            </button>
        </form>
    </div>
</div>

<script>
let activeColor = '#14b8a6';

function selectOperator(name, color) {
    document.getElementById('selected_operator').value = name;
    activeColor = color;
    
    // UI Feedback
    document.querySelectorAll('.operator-btn').forEach(btn => {
        btn.style.borderColor = '#f8fafc';
    });
    event.currentTarget.style.borderColor = color;
}

function processAirtime() {
    const operator = document.getElementById('selected_operator').value;
    const amount = document.getElementById('airtime_amount').value;
    
    if(!operator) {
        alert("Zaɓi Kamfani / Choisissez un opérateur");
        return;
    }
    if(!amount || amount < 100) {
        alert("Mafi ƙarancin kuɗi shine 100 / Minimum 100 XOF");
        return;
    }

    // Logic: Trigger PIN validation modal here
    alert(`Recharge ${operator} successful!`);
    window.location.href = 'dashboard.php';
}
</script>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>