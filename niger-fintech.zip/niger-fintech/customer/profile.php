<?php
/**
 * NigerPay - Settings & Security
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) { header('Location: /login.php'); exit; }

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

$pageTitle = $isHausa ? 'Saituna' : 'Paramètres';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto space-y-6 pb-12">
    <div class="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100 text-center">
        <div class="w-20 h-20 bg-primary-100 text-primary-600 rounded-3xl flex items-center justify-center text-3xl font-black mx-auto mb-4 border-4 border-white shadow-lg">
            <?php echo strtoupper(substr($currentUser['first_name'],0,1)); ?>
        </div>
        <h2 class="text-xl font-black text-slate-900"><?php echo htmlspecialchars($currentUser['first_name'] . ' ' . $currentUser['last_name']); ?></h2>
        <p class="text-slate-400 text-xs font-bold">+227 <?php echo $currentUser['phone_number']; ?></p>
    </div>

    
    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
        <div class="px-8 py-6 border-b border-slate-50 flex justify-between items-center">
            <h3 class="font-black text-xs uppercase tracking-widest text-slate-400">KYC Status</h3>
            <span class="bg-green-100 text-green-700 text-[10px] font-black px-3 py-1 rounded-full uppercase">Verified</span>
        </div>
        <div class="p-8 space-y-4">
            <div class="flex items-center justify-between">
                <span class="text-sm font-bold text-slate-600">Current Tier</span>
                <span class="text-sm font-black text-primary-600">Level <?php echo $currentUser['kyc_tier']; ?></span>
            </div>
            <div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div class="bg-primary-500 h-full" style="width: <?php echo ($currentUser['kyc_tier']/3)*100; ?>%"></div>
            </div>
            <p class="text-[10px] text-slate-400 font-medium">
                <?php echo $isHausa ? 'Inganta matsayinka don samun damar tura manyan kuɗi.' : 'Augmentez votre niveau pour débloquer des limites plus élevées.'; ?>
            </p>
        </div>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-8 space-y-4">
        <h3 class="font-black text-xs uppercase tracking-widest text-slate-400 mb-4">Security</h3>
        
        <button onclick="togglePinForm()" class="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl group transition-all hover:bg-primary-50">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 group-hover:text-primary-600 shadow-sm"><i class="fas fa-lock"></i></div>
                <span class="ml-4 text-sm font-bold text-slate-700"><?php echo $isHausa ? 'Canza PIN' : 'Changer mon PIN'; ?></span>
            </div>
            <i class="fas fa-chevron-right text-slate-300 text-xs"></i>
        </button>

        <form id="pinForm" class="hidden animate-fade-in space-y-4 pt-4 border-t border-slate-100">
            <input type="password" placeholder="Tsohon PIN / Ancien PIN" class="w-full px-4 py-3 bg-slate-100 border-none rounded-xl text-sm font-bold">
            <input type="password" placeholder="Sabuwar PIN / Nouveau PIN" class="w-full px-4 py-3 bg-slate-100 border-none rounded-xl text-sm font-bold">
            <button type="button" class="w-full bg-slate-900 text-white font-black py-3 rounded-xl text-xs uppercase"><?php echo $isHausa ? 'ADANA' : 'ENREGISTRER'; ?></button>
        </form>

        <a href="privacy.php" class="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl group transition-all hover:bg-slate-100">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 shadow-sm"><i class="fas fa-file-shield"></i></div>
                <span class="ml-4 text-sm font-bold text-slate-700">Privacy Policy</span>
            </div>
            <i class="fas fa-chevron-right text-slate-300 text-xs"></i>
        </a>
    </div>

    <a href="../logout.php" class="block w-full text-center py-4 text-red-500 font-black text-xs uppercase tracking-[0.2em]">
        <i class="fas fa-power-off mr-2"></i> <?php echo $isHausa ? 'Fita daga nan' : 'Se déconnecter'; ?>
    </a>
</div>

<script>
function togglePinForm() {
    const form = document.getElementById('pinForm');
    form.classList.toggle('hidden');
}
</script>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>