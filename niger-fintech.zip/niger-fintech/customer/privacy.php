<?php
/**
 * NigerPay - Customer Privacy & Security Hub
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

// Security Gate
requireRole('customer');

$currentUser = getCurrentUser();
$isHausa = (($_SESSION['lang'] ?? 'ha') === 'ha');
$message = '';
$error = '';

// Handle PIN Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_pin'])) {
    if (validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $oldPin = $_POST['old_pin'];
        $newPin = $_POST['new_pin'];
        $confirmPin = $_POST['confirm_pin'];

        if (!verifyPIN($oldPin, $currentUser['pin_hash'])) {
            $error = $isHausa ? "Tsohon PIN ba daidai ba." : "L'ancien PIN est incorrect.";
        } elseif ($newPin !== $confirmPin) {
            $error = $isHausa ? "Sabon PIN bai dace ba." : "Le nouveau PIN ne correspond pas.";
        } else {
            $db = getDB();
            $stmt = $db->prepare("UPDATE users SET pin_hash = ? WHERE id = ?");
            $stmt->execute([hashPIN($newPin), $currentUser['id']]);
            
            logActivity('users', $currentUser['id'], 'PIN_CHANGE_SUCCESS');
            $message = $isHausa ? "An canza PIN cikin nasara!" : "PIN modifié avec succès !";
        }
    }
}

$pageTitle = $isHausa ? 'Sirri da Tsaro' : 'Confidentialité et Sécurité';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto space-y-8 pb-24">
    <div class="px-4">
        <h1 class="text-2xl font-black text-slate-900 tracking-tight"><?php echo $pageTitle; ?></h1>
        <p class="text-slate-500 text-sm font-medium"><?php echo $isHausa ? 'Kula da tsaron asusunku' : 'Gérez la sécurité de votre compte'; ?></p>
    </div>

    <?php if($message): ?>
        <div class="mx-4 p-4 bg-green-50 text-green-700 rounded-2xl font-bold text-xs flex items-center">
            <i class="fas fa-check-circle mr-2"></i> <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="mx-4 p-4 bg-red-50 text-red-700 rounded-2xl font-bold text-xs flex items-center">
            <i class="fas fa-exclamation-triangle mr-2"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-8 space-y-8">
        <div>
            <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">
                <i class="fas fa-lock-keyhole mr-2"></i> <?php echo $isHausa ? 'Canza PIN' : 'Changer le PIN'; ?>
            </h3>
            
            <form method="POST" class="space-y-4">
                <?php csrfField(); ?>
                <input type="password" name="old_pin" maxlength="4" placeholder="<?php echo $isHausa ? 'Tsohon PIN' : 'Ancien PIN'; ?>" required 
                       class="w-full px-6 py-4 bg-slate-50 border-0 rounded-2xl text-center font-bold tracking-[0.5em]">
                
                <input type="password" name="new_pin" maxlength="4" placeholder="<?php echo $isHausa ? 'Sabon PIN' : 'Nouveau PIN'; ?>" required 
                       class="w-full px-6 py-4 bg-slate-50 border-0 rounded-2xl text-center font-bold tracking-[0.5em]">
                
                <input type="password" name="confirm_pin" maxlength="4" placeholder="<?php echo $isHausa ? 'Tabbatar da PIN' : 'Confirmer PIN'; ?>" required 
                       class="w-full px-6 py-4 bg-slate-50 border-0 rounded-2xl text-center font-bold tracking-[0.5em]">
                
                <button type="submit" name="change_pin" class="w-full bg-slate-900 text-white font-black py-4 rounded-2xl uppercase tracking-widest text-[10px] shadow-xl">
                    <?php echo $isHausa ? 'Ajiye Canji' : 'Enregistrer'; ?>
                </button>
            </form>
        </div>

        <div class="pt-8 border-t border-slate-50">
            <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">
                <i class="fas fa-shield-halved mr-2"></i> <?php echo $isHausa ? 'Bayanan Sirri' : 'Données Personnelles'; ?>
            </h3>
            
            <div class="space-y-4">
                <div class="flex justify-between items-center p-4 bg-slate-50 rounded-2xl">
                    <span class="text-xs font-bold text-slate-600">KYC Status</span>
                    <span class="text-[10px] font-black bg-primary-100 text-primary-700 px-3 py-1 rounded-full uppercase">Tier <?php echo $currentUser['kyc_tier']; ?></span>
                </div>
                
                <div class="flex justify-between items-center p-4 bg-slate-50 rounded-2xl">
                    <span class="text-xs font-bold text-slate-600">Biometric Login</span>
                    <div class="w-10 h-5 bg-slate-200 rounded-full relative">
                        <div class="w-4 h-4 bg-white rounded-full absolute left-0.5 top-0.5 shadow-sm"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-indigo-900 rounded-[2.5rem] p-8 text-white shadow-xl relative overflow-hidden">
        <div class="absolute -right-4 -bottom-4 text-white/5 text-7xl"><i class="fas fa-user-shield"></i></div>
        <h4 class="text-xs font-black uppercase tracking-widest text-indigo-300 mb-4">NigerPay Privacy Promise</h4>
        <p class="text-[11px] leading-relaxed opacity-80">
            <?php echo $isHausa 
                ? 'Mun himmatu wajen kiyaye bayanan ku. Ba ma taba sayar da bayanan asusun ku ga wasu kamfanoni ba.' 
                : 'Nous nous engageons à protéger vos données. Nous ne vendons jamais vos informations bancaires à des tiers.'; ?>
        </p>
    </div>
</div>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>