<?php
/**
 * NigerPay - Customer Transaction History
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'customer') {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$userId = $currentUser['id'];
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$db = getDB();

// Fetch Transactions (Sent & Received)
$stmt = $db->prepare("
    SELECT t.*, 
           sender.first_name as s_fname, sender.phone_number as s_phone,
           receiver.first_name as r_fname, receiver.phone_number as r_phone
    FROM transactions t
    LEFT JOIN users sender ON t.sender_user_id = sender.id
    LEFT JOIN users receiver ON t.receiver_user_id = receiver.id
    WHERE t.sender_user_id = ? OR t.receiver_user_id = ?
    ORDER BY t.created_at DESC 
    LIMIT 50
");
$stmt->execute([$userId, $userId]);
$transactions = $stmt->fetchAll();

$pageTitle = $isHausa ? 'Tarihin Ma\'amala' : 'Mon Historique';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-2xl mx-auto pb-24">
    <div class="mb-8 px-2">
        <h1 class="text-2xl font-black text-slate-900"><?php echo $isHausa ? 'Tarihin Kuɗi' : 'Activités'; ?></h1>
        <div class="mt-4 flex gap-2 overflow-x-auto no-scrollbar pb-2">
            <button class="px-4 py-2 bg-primary-600 text-white rounded-full text-xs font-bold whitespace-nowrap">All</button>
            <button class="px-4 py-2 bg-white text-slate-500 border border-slate-100 rounded-full text-xs font-bold whitespace-nowrap">Sent</button>
            <button class="px-4 py-2 bg-white text-slate-500 border border-slate-100 rounded-full text-xs font-bold whitespace-nowrap">Received</button>
            <button class="px-4 py-2 bg-white text-slate-500 border border-slate-100 rounded-full text-xs font-bold whitespace-nowrap">Bills</button>
        </div>
    </div>

    <div class="space-y-3">
        <?php foreach ($transactions as $tx): ?>
            <?php 
                $isSent = ($tx['sender_user_id'] == $userId); 
                $statusColor = $tx['status'] === 'completed' ? 'text-green-500' : 'text-orange-500';
            ?>
            <div onclick="window.location.href='../admin/receipt.php?id=<?php echo $tx['transaction_id']; ?>'" 
                 class="bg-white rounded-3xl p-5 shadow-soft border border-slate-100 flex items-center justify-between cursor-pointer hover:scale-[1.02] transition-all active:scale-95">
                
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-lg <?php echo $isSent ? 'bg-red-50 text-red-500' : 'bg-green-50 text-green-500'; ?>">
                        <i class="fas <?php 
                            if($tx['transaction_type'] === 'bill_payment') echo 'fa-file-invoice-dollar';
                            elseif($tx['transaction_type'] === 'airtime') echo 'fa-mobile-screen';
                            else echo ($isSent ? 'fa-arrow-up-right' : 'fa-arrow-down-left'); 
                        ?>"></i>
                    </div>

                    <div class="ml-4">
                        <p class="text-sm font-black text-slate-900 leading-tight">
                            <?php 
                            if ($isSent) {
                                echo ($isHausa ? 'Ka tura ma ' : 'Envoyé à ') . ($tx['r_fname'] ?: $tx['r_phone']);
                            } else {
                                echo ($isHausa ? 'Ka karɓa daga ' : 'Reçu de ') . ($tx['s_fname'] ?: $tx['s_phone']);
                            }
                            ?>
                        </p>
                        <div class="flex items-center mt-1">
                            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                                <?php echo date('d M Y • H:i', strtotime($tx['created_at'])); ?>
                            </span>
                            <span class="mx-1.5 text-slate-200">•</span>
                            <span class="text-[10px] font-black uppercase <?php echo $statusColor; ?>">
                                <?php echo $tx['status']; ?>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="text-right">
                    <p class="text-sm font-black <?php echo $isSent ? 'text-slate-900' : 'text-green-600'; ?>">
                        <?php echo $isSent ? '-' : '+'; ?><?php echo number_format($tx['amount'], 0, ',', ' '); ?>
                    </p>
                    <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest">XOF</p>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (empty($transactions)): ?>
            <div class="py-20 text-center">
                <div class="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-receipt text-slate-200 text-3xl"></i>
                </div>
                <h3 class="text-slate-900 font-black"><?php echo $isHausa ? 'Babu wani aiki' : 'Aucun historique'; ?></h3>
                <p class="text-slate-400 text-xs mt-1 font-medium"><?php echo $isHausa ? 'Da zarar ka fara kashe kuɗi za su fito a nan.' : 'Vos transactions apparaîtront ici dès que vous commencerez.'; ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    /* Hide scrollbar for Chrome, Safari and Opera */
    .no-scrollbar::-webkit-scrollbar { display: none; }
    /* Hide scrollbar for IE, Edge and Firefox */
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
</style>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>