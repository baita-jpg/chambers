<?php
/**
 * NigerPay - Nigelec & SEEN Bill Payment
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'customer') {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$balance = getAccountBalance($currentUser['id'], 'primary')['available_balance'] ?? 0;

$pageTitle = $isHausa ? 'Biyan Kuɗin Lantarki/Ruwa' : 'Paiement de Factures';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto pb-20">
    <div class="mb-8 px-2 text-center">
        <h1 class="text-2xl font-black text-slate-900"><?php echo $isHausa ? 'Biyan Kuɗi' : 'Services Publics'; ?></h1>
        <p class="text-slate-500 text-sm"><?php echo $isHausa ? 'Biya kuɗin Nigelec ko SEEN cikin sauƙi' : 'Payez Nigelec ou SEEN instantanément'; ?></p>
    </div>

    
    <div class="grid grid-cols-2 gap-4 mb-8">
        <button onclick="selectService('nigelec', '#ffcc00')" class="service-btn group bg-white border-2 border-slate-50 p-6 rounded-[2rem] shadow-soft transition-all hover:border-yellow-400 text-center">
            <div class="w-14 h-14 bg-yellow-50 text-yellow-600 rounded-2xl flex items-center justify-center text-2xl mx-auto mb-3"><i class="fas fa-bolt"></i></div>
            <span class="text-xs font-black uppercase tracking-widest text-slate-900">Nigelec</span>
        </button>
        <button onclick="selectService('seen', '#0099ff')" class="service-btn group bg-white border-2 border-slate-50 p-6 rounded-[2rem] shadow-soft transition-all hover:border-blue-400 text-center">
            <div class="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-2xl mx-auto mb-3"><i class="fas fa-faucet-drop"></i></div>
            <span class="text-xs font-black uppercase tracking-widest text-slate-900">SEEN</span>
        </button>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-8">
        <form id="billForm" class="space-y-6">
            <?php csrfField(); ?>
            <input type="hidden" id="selected_service" name="service" value="">

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2" id="refLabel">
                    <?php echo $isHausa ? 'Lambar Mita / Rasit' : 'Référence / Compteur'; ?>
                </label>
                <div class="relative">
                    <input type="text" id="bill_ref" name="reference" placeholder="0000 0000" 
                           class="w-full px-6 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-bold text-xl uppercase">
                    <button type="button" class="absolute inset-y-0 right-0 pr-4 flex items-center text-primary-600">
                        <i class="fas fa-qrcode"></i>
                    </button>
                </div>
                <div id="verifyBox" class="hidden p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
                    <div>
                        <p class="text-[9px] font-black text-slate-400 uppercase"><?php echo $isHausa ? 'Sunan Mai Gida' : 'Abonné'; ?></p>
                        <p id="ownerName" class="text-sm font-black text-slate-900 uppercase">---</p>
                    </div>
                    <i class="fas fa-check-circle text-green-500"></i>
                </div>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2"><?php echo $isHausa ? 'Adadin Kuɗi' : 'Montant à payer'; ?></label>
                <div class="relative">
                    <input type="number" id="bill_amount" name="amount" placeholder="0" 
                           class="w-full px-6 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-black text-3xl">
                    <span class="absolute inset-y-0 right-0 pr-6 flex items-center text-slate-400 font-black">XOF</span>
                </div>
            </div>

            <div class="bg-primary-50 rounded-2xl p-5 border border-primary-100 space-y-2">
                <div class="flex justify-between items-center text-xs">
                    <span class="font-bold text-primary-700 uppercase"><?php echo $isHausa ? 'Ragowar Kuɗi' : 'Votre solde'; ?></span>
                    <span class="font-black text-primary-900"><?php echo number_format($balance, 0, ',', ' '); ?> XOF</span>
                </div>
                <div class="flex justify-between items-center text-xs border-t border-primary-200 pt-2">
                    <span class="font-bold text-primary-700 uppercase"><?php echo $isHausa ? 'Kuɗin Sabis' : 'Frais'; ?></span>
                    <span class="font-black text-primary-900">100 XOF</span>
                </div>
            </div>

            <button type="button" onclick="processPayment()" 
                    class="w-full bg-slate-900 text-white font-black py-5 rounded-3xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-3">
                <i class="fas fa-shield-check opacity-50"></i>
                <span><?php echo $isHausa ? 'BIYA YANZU' : 'PAYER LA FACTURE'; ?></span>
            </button>
        </form>
    </div>
    
    <div class="mt-8 bg-blue-900 rounded-[2rem] p-6 text-white shadow-xl flex items-center">
        <div class="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mr-4">
            <i class="fas fa-lightbulb"></i>
        </div>
        <p class="text-[11px] font-medium leading-relaxed italic opacity-80">
            <?php echo $isHausa 
                ? 'Lura: Tabbatar lambar mita daidai take domin guje wa kuskure.' 
                : 'Note: Vérifiez bien le numéro du compteur pour éviter les erreurs de paiement.'; ?>
        </p>
    </div>
</div>

<script>
function selectService(type, color) {
    document.getElementById('selected_service').value = type;
    document.querySelectorAll('.service-btn').forEach(btn => btn.style.borderColor = '#f1f5f9');
    event.currentTarget.style.borderColor = color;
    
    // Change label context
    document.getElementById('refLabel').innerText = type === 'nigelec' 
        ? "<?php echo $isHausa ? 'Lambar Mita (Meter Number)' : 'Numéro du Compteur'; ?>"
        : "<?php echo $isHausa ? 'Lambar Rasit (Invoice ID)' : 'Référence Facture'; ?>";
}

// Simulated verification logic
document.getElementById('bill_ref').addEventListener('input', function(e) {
    if(e.target.value.length >= 6) {
        document.getElementById('verifyBox').classList.remove('hidden');
        document.getElementById('ownerName').innerText = "Mahamadou Issoufou"; // Simulate fetch
    } else {
        document.getElementById('verifyBox').classList.add('hidden');
    }
});

function processPayment() {
    const service = document.getElementById('selected_service').value;
    const ref = document.getElementById('bill_ref').value;
    const amount = document.getElementById('bill_amount').value;
    
    if(!service) {
        alert("Zaɓi Service tukunna / Sélectionnez un service");
        return;
    }
    if(!ref || !amount) {
        alert("Cika bayanan duka / Veuillez remplir tous les champs");
        return;
    }

    // Process logic here
    alert(`Payment for ${service.toUpperCase()} processed!`);
    window.location.href = 'dashboard.php';
}
</script>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>