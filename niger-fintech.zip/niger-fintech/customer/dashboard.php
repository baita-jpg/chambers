<?php
/**
 * NigerPay - Premium Customer Dashboard & Withdrawal Hub
 */

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/auth.php';
requireRole('customer');
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn()) { header('Location: /login.php'); exit; }

$currentUser = getCurrentUser();
$userId = $currentUser['id'];
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Data Fetching
$balanceData = getAccountBalance($userId, 'primary');
$balance = $balanceData['available_balance'] ?? 0;

// Check for any active/pending withdrawal tokens
$db = getDB();
$stmt = $db->prepare("SELECT transaction_id, amount FROM transactions WHERE sender_user_id = ? AND transaction_type = 'withdrawal' AND status = 'pending' LIMIT 1");
$stmt->execute([$userId]);
$activeWithdrawal = $stmt->fetch();

$pageTitle = $isHausa ? 'Asusu na' : 'Mon Portefeuille';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto space-y-8 pb-24">

    <div class="bg-slate-900 rounded-[3rem] p-8 text-white shadow-2xl relative overflow-hidden">
        <div class="absolute -right-10 -top-10 w-40 h-40 bg-primary-500/20 rounded-full blur-3xl"></div>
        
        <div class="relative z-10">
            <div class="flex justify-between items-center mb-4">
                <span class="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400"><?php echo $isHausa ? 'Jimillar Kuɗi' : 'Solde Disponible'; ?></span>
                <button onclick="toggleBalance()" class="text-slate-400 hover:text-white transition-colors">
                    <i id="eye-icon" class="fas fa-eye"></i>
                </button>
            </div>
            
            <div class="flex items-baseline space-x-2">
                <h2 id="balance-text" class="text-4xl font-black tracking-tighter">
                    <?php echo number_format($balance, 0, ',', ' '); ?>
                </h2>
                <span class="text-primary-500 font-bold text-lg">XOF</span>
            </div>

            <div class="mt-8 grid grid-cols-2 gap-3">
                <a href="transfer.php" class="bg-primary-600 hover:bg-primary-700 text-white py-3 rounded-2xl flex items-center justify-center font-black text-[10px] uppercase tracking-widest shadow-lg shadow-primary-900/20 transition-transform active:scale-95">
                    <i class="fas fa-paper-plane mr-2"></i> <?php echo $isHausa ? 'Tura' : 'Envoyer'; ?>
                </a>
                <button onclick="window.location.href='withdraw.php'" class="bg-white/10 hover:bg-white/20 text-white py-3 rounded-2xl flex items-center justify-center font-black text-[10px] uppercase tracking-widest border border-white/10 transition-transform active:scale-95">
                    <i class="fas fa-hand-holding-dollar mr-2 text-primary-400"></i> <?php echo $isHausa ? 'Cirewa' : 'Retrait'; ?>
                </button>
            </div>
        </div>
    </div>

    <?php if ($activeWithdrawal): ?>
    
    <div class="bg-orange-50 border-2 border-orange-100 rounded-[2rem] p-6 animate-pulse">
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-orange-500 text-white rounded-xl flex items-center justify-center mr-4">
                    <i class="fas fa-key"></i>
                </div>
                <div>
                    <p class="text-[10px] font-black text-orange-800 uppercase tracking-widest"><?php echo $isHausa ? 'Lambar Cire Kudi' : 'Retrait en cours'; ?></p>
                    <p class="text-sm font-bold text-orange-900"><?php echo number_format($activeWithdrawal['amount']); ?> XOF</p>
                </div>
            </div>
            <a href="withdraw.php" class="bg-orange-900 text-white text-[10px] font-black px-4 py-2 rounded-lg uppercase tracking-tight">Duba Code</a>
        </div>
    </div>
    <?php endif; ?>

    <div class="grid grid-cols-4 gap-4 px-2">
        <a href="airtime.php" class="flex flex-col items-center group">
            <div class="w-14 h-14 bg-white rounded-2xl shadow-soft flex items-center justify-center text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-all duration-300">
                <i class="fas fa-mobile-screen text-xl"></i>
            </div>
            <span class="text-[9px] font-black uppercase text-slate-400 mt-3 tracking-tighter">Airtime</span>
        </a>
        <a href="bill-pay.php" class="flex flex-col items-center group">
            <div class="w-14 h-14 bg-white rounded-2xl shadow-soft flex items-center justify-center text-yellow-500 group-hover:bg-yellow-500 group-hover:text-white transition-all duration-300">
                <i class="fas fa-bolt text-xl"></i>
            </div>
            <span class="text-[9px] font-black uppercase text-slate-400 mt-3 tracking-tighter">Nigelec</span>
        </a>
        <a href="qr-pay.php" class="flex flex-col items-center group">
            <div class="w-14 h-14 bg-white rounded-2xl shadow-soft flex items-center justify-center text-primary-500 group-hover:bg-primary-500 group-hover:text-white transition-all duration-300">
                <i class="fas fa-expand text-xl"></i>
            </div>
            <span class="text-[9px] font-black uppercase text-slate-400 mt-3 tracking-tighter">QR Pay</span>
        </a>
        <a href="history.php" class="flex flex-col items-center group">
            <div class="w-14 h-14 bg-white rounded-2xl shadow-soft flex items-center justify-center text-slate-400 group-hover:bg-slate-900 group-hover:text-white transition-all duration-300">
                <i class="fas fa-grid-2 text-xl"></i>
            </div>
            <span class="text-[9px] font-black uppercase text-slate-400 mt-3 tracking-tighter">More</span>
        </a>
    </div>

    <div class="space-y-4">
        <div class="flex justify-between items-center px-4">
            <h3 class="text-sm font-black text-slate-900 uppercase tracking-widest"><?php echo $isHausa ? 'Ayyuka' : 'Activités'; ?></h3>
            <a href="history.php" class="text-[10px] font-black text-primary-600 uppercase tracking-widest"><?php echo $isHausa ? 'Duka' : 'Voir tout'; ?></a>
        </div>
        
        <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden divide-y divide-slate-50">
            <div class="p-6 flex items-center justify-between">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center"><i class="fas fa-receipt"></i></div>
                    <div class="ml-4">
                        <p class="text-sm font-black text-slate-900">Transfer Received</p>
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Aujourd'hui, 14:20</p>
                    </div>
                </div>
                <p class="text-sm font-black text-green-600">+1 000</p>
            </div>
        </div>
    </div>
</div>

<script>
let hidden = false;
const originalBalance = "<?php echo number_format($balance, 0, ',', ' '); ?>";

function toggleBalance() {
    hidden = !hidden;
    const btn = document.getElementById('balance-text');
    const icon = document.getElementById('eye-icon');
    
    if(hidden) {
        btn.innerText = "••••••";
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        btn.innerText = originalBalance;
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}
</script>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>