<?php
/**
 * NigerPay - KYC Upgrade Request
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) { header('Location: /login.php'); exit; }

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$currentTier = $currentUser['kyc_tier'] ?? 1;

$pageTitle = $isHausa ? 'Ƙara Matayin Asusu' : 'Mise à niveau KYC';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto pb-24">
    <div class="text-center mb-8 px-4">
        <h1 class="text-2xl font-black text-slate-900"><?php echo $isHausa ? 'Inganta Asusu' : 'Augmenter mes Limites'; ?></h1>
        <p class="text-slate-500 text-sm mt-2"><?php echo $isHausa ? 'Zaɓi matakin da kake so ka koma' : 'Passez au niveau supérieur pour plus de liberté'; ?></p>
    </div>

    <div class="space-y-4 mb-10">
        <div class="bg-white rounded-[2rem] p-6 shadow-soft border-2 <?php echo $currentTier == 1 ? 'border-primary-500' : 'border-slate-50 opacity-60'; ?> relative">
            <?php if($currentTier == 1): ?><span class="absolute -top-3 right-8 bg-primary-600 text-white text-[9px] font-black px-3 py-1 rounded-full uppercase">Next Level</span><?php endif; ?>
            <div class="flex justify-between items-center mb-4">
                <div>
                    <h3 class="font-black text-slate-900 uppercase tracking-tight">Level 2 (Standard)</h3>
                    <p class="text-xs text-slate-500">ID Verification required</p>
                </div>
                <div class="text-right">
                    <p class="text-lg font-black text-primary-600">1,000,000</p>
                    <p class="text-[9px] font-bold text-slate-400 uppercase">Limit XOF</p>
                </div>
            </div>
        </div>

        <div class="bg-slate-900 rounded-[2rem] p-6 shadow-xl relative overflow-hidden">
            <div class="absolute -right-4 -bottom-4 text-white/5 text-6xl"><i class="fas fa-crown"></i></div>
            <div class="flex justify-between items-center mb-4 relative z-10">
                <div>
                    <h3 class="font-black text-white uppercase tracking-tight">Level 3 (Premium)</h3>
                    <p class="text-xs text-slate-400 italic">Proof of Residence required</p>
                </div>
                <div class="text-right">
                    <p class="text-lg font-black text-yellow-400">UNLIMITED</p>
                    <p class="text-[9px] font-bold text-slate-500 uppercase">Limit XOF</p>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100">
        <form class="space-y-6">
            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2"><?php echo $isHausa ? 'Nau\'in Shaidar ID' : 'Type de pièce ID'; ?></label>
                <select class="w-full px-4 py-4 bg-slate-50 border-none rounded-2xl font-bold text-sm">
                    <option>NINA Card</option>
                    <option>Passeport</option>
                    <option>Permis de conduire</option>
                </select>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2"><?php echo $isHausa ? 'Loda Hoton ID' : 'Photo de la pièce'; ?></label>
                <label class="w-full h-32 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-100 transition-all">
                    <i class="fas fa-camera text-slate-300 text-2xl mb-2"></i>
                    <span class="text-[10px] font-bold text-slate-400 uppercase">Upload ID Front</span>
                    <input type="file" class="hidden">
                </label>
            </div>

            <button type="button" onclick="alert('Verification submitted!')" class="w-full bg-primary-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-primary-100 uppercase tracking-widest text-xs">
                <?php echo $isHausa ? 'AIKA DA SHAIDU' : 'SOUMETTRE LES DOCUMENTS'; ?>
            </button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>