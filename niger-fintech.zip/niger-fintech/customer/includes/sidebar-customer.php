<?php
/**
 * NigerPay - Premium Customer Sidebar
 */
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$currentPath = basename($_SERVER['PHP_SELF']);
$currentUser = getCurrentUser();

function getActiveNav($page, $currentPath) {
    return ($page === $currentPath) 
        ? 'bg-primary-600 text-white shadow-lg shadow-primary-200 scale-[1.02]' 
        : 'text-slate-500 hover:bg-slate-50 hover:text-primary-600';
}
?>
<aside id="sidebar" class="bg-white w-80 flex-shrink-0 hidden lg:flex flex-col border-r border-slate-100 transition-all duration-300 z-30">
    
    <div class="h-24 flex items-center px-10">
        <div class="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center shadow-lg shadow-primary-200">
            <i class="fas fa-wallet text-white text-xl"></i>
        </div>
        <span class="ml-4 text-slate-900 font-black text-2xl tracking-tighter uppercase">Niger<span class="text-primary-600">Pay</span></span>
    </div>

    <nav class="flex-1 px-6 space-y-2 overflow-y-auto">
        <div class="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-4 mt-4 mb-4">Main Menu</div>

        <a href="dashboard.php" class="flex items-center px-5 py-3.5 rounded-2xl transition-all duration-300 group <?php echo getActiveNav('dashboard.php', $currentPath); ?>">
            <i class="fas fa-house-chimney text-lg w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Babban Shafi' : 'Tableau de bord'; ?></span>
        </a>

        <a href="transfer.php" class="flex items-center px-5 py-3.5 rounded-2xl transition-all duration-300 group <?php echo getActiveNav('transfer.php', $currentPath); ?>">
            <i class="fas fa-paper-plane text-lg w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Tura Kuɗi' : 'Envoyer Argent'; ?></span>
        </a>

        <a href="history.php" class="flex items-center px-5 py-3.5 rounded-2xl transition-all duration-300 group <?php echo getActiveNav('history.php', $currentPath); ?>">
            <i class="fas fa-clock-rotate-left text-lg w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Tarihin Kuɗi' : 'Historique'; ?></span>
        </a>

        <div class="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-4 mt-10 mb-4">Account & Safety</div>

        <a href="profile.php" class="flex items-center px-5 py-3.5 rounded-2xl transition-all duration-300 group <?php echo getActiveNav('profile.php', $currentPath); ?>">
            <i class="fas fa-user-gear text-lg w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Saituna' : 'Paramètres'; ?></span>
        </a>

        <div class="mt-10 p-5 bg-slate-50 rounded-[2rem] border border-slate-100">
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">KYC Verification</p>
            <div class="flex justify-between items-center mb-2">
                <span class="text-xs font-black text-slate-900">Level <?php echo $currentUser['kyc_tier']; ?></span>
                <span class="text-[10px] font-bold text-primary-600">75%</span>
            </div>
            <div class="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                <div class="bg-primary-500 h-full w-3/4"></div>
            </div>
            <a href="upgrade.php" class="block text-center mt-4 text-[10px] font-black text-primary-600 uppercase hover:underline">Upgrade Now</a>
        </div>
    </nav>

    <div class="p-6">
        <a href="../logout.php" class="flex items-center justify-center space-x-3 px-6 py-4 bg-red-50 text-red-600 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-100 transition-all">
            <i class="fas fa-power-off"></i>
            <span><?php echo $isHausa ? 'Fita' : 'Déconnexion'; ?></span>
        </a>
    </div>
</aside>