</main>
        
        <nav class="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-3 flex justify-between items-center z-50">
            <a href="dashboard.php" class="flex flex-col items-center <?php echo ($currentPath === 'dashboard.php') ? 'text-primary-600' : 'text-gray-400'; ?>">
                <i class="fas fa-house-user text-xl"></i>
                <span class="text-[10px] font-bold mt-1 uppercase">Home</span>
            </a>
            <a href="transfer.php" class="flex flex-col items-center <?php echo ($currentPath === 'transfer.php') ? 'text-primary-600' : 'text-gray-400'; ?>">
                <i class="fas fa-paper-plane text-xl"></i>
                <span class="text-[10px] font-bold mt-1 uppercase">Send</span>
            </a>
            <div class="relative -top-8">
                <a href="qr-pay.php" class="w-14 h-14 bg-primary-600 rounded-full flex items-center justify-center text-white shadow-xl shadow-primary-200 border-4 border-gray-50">
                    <i class="fas fa-expand text-xl"></i>
                </a>
            </div>
            <a href="history.php" class="flex flex-col items-center <?php echo ($currentPath === 'history.php') ? 'text-primary-600' : 'text-gray-400'; ?>">
                <i class="fas fa-history text-xl"></i>
                <span class="text-[10px] font-bold mt-1 uppercase">History</span>
            </a>
            <a href="profile.php" class="flex flex-col items-center <?php echo ($currentPath === 'profile.php') ? 'text-primary-600' : 'text-gray-400'; ?>">
                <i class="fas fa-user-circle text-xl"></i>
                <span class="text-[10px] font-bold mt-1 uppercase">Profile</span>
            </a>
        </nav>
    </div>
</body>
</html>