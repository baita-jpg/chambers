<?php
$lang = $_SESSION['lang'] ?? 'ha';
$isHausa = ($lang === 'ha');
$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $pageTitle ?? 'NigerPay'; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: { 50: '#f0fdf4', 500: '#22c55e', 600: '#16a34a', 700: '#15803d', 800: '#166534', 900: '#14532d' }
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; -webkit-tap-highlight-color: transparent; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
    </style>
</head>
<body class="bg-gray-50 text-slate-900 flex h-screen overflow-hidden">
    <?php include __DIR__ . '/sidebar-customer.php'; ?>
    <div class="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
        <header class="bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-40 px-6 py-4 flex items-center justify-between">
            <div class="flex items-center">
                <button id="mobileMenu" class="lg:hidden p-2 -ml-2 text-gray-400"><i class="fas fa-bars-staggered text-xl"></i></button>
                <h1 class="ml-2 lg:ml-0 font-black text-xl tracking-tight text-primary-600">NigerPay</h1>
            </div>
            <div class="flex items-center space-x-4">
                <a href="qr-scan.php" class="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-600"><i class="fas fa-qrcode"></i></a>
                <div class="w-10 h-10 rounded-full bg-primary-600 text-white flex items-center justify-center font-black shadow-lg shadow-primary-200">
                    <?php echo strtoupper(substr($currentUser['first_name'],0,1)); ?>
                </div>
            </div>
        </header>
        <main class="p-4 md:p-8 pb-24 lg:pb-8">