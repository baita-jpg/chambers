<?php
/**
 * Niger Fintech System - QR Scanner
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'customer') {
    header('Location: /login.php'); exit;
}

$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$pageTitle = $isHausa ? 'Duba QR Code' : 'Scanner QR Code';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto">
    <div class="text-center mb-8">
        <h1 class="text-2xl font-black text-slate-900"><?php echo $isHausa ? 'Bincika & Biya' : 'Scanner & Payer'; ?></h1>
        <p class="text-slate-500 text-sm"><?php echo $isHausa ? 'Nuna kyamararka akan lambar QR' : 'Pointez votre caméra vers le code QR'; ?></p>
    </div>

    <div class="relative bg-black rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white aspect-square mb-8">
        <div id="reader" class="w-full h-full"></div>
        
        <div class="absolute inset-0 pointer-events-none border-[40px] border-black/20"></div>
        <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
             <div class="w-64 h-64 border-2 border-primary-500 rounded-3xl animate-pulse relative">
                 <div class="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary-500 -mt-1 -ml-1 rounded-tl-lg"></div>
                 <div class="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary-500 -mt-1 -mr-1 rounded-tr-lg"></div>
                 <div class="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary-500 -mb-1 -ml-1 rounded-bl-lg"></div>
                 <div class="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary-500 -mb-1 -mr-1 rounded-br-lg"></div>
             </div>
        </div>
    </div>

    <div class="flex justify-center gap-4">
        <button id="torchBtn" class="w-14 h-14 bg-white rounded-2xl shadow-lg flex items-center justify-center text-slate-400 hover:text-yellow-500 transition-all">
            <i class="fas fa-lightbulb"></i>
        </button>
        <button onclick="location.reload()" class="w-14 h-14 bg-white rounded-2xl shadow-lg flex items-center justify-center text-slate-400 hover:text-primary-600 transition-all">
            <i class="fas fa-sync"></i>
        </button>
    </div>

    <div class="mt-10 bg-white rounded-3xl p-6 border border-slate-100 flex items-center">
        <div class="w-10 h-10 bg-primary-50 text-primary-600 rounded-full flex items-center justify-center mr-4">
            <i class="fas fa-info-circle"></i>
        </div>
        <p class="text-xs text-slate-500 font-medium leading-relaxed">
            <?php echo $isHausa 
                ? 'Za ka iya biyan kuɗi a shaguna ko tura ma abokinka ta hanyar amfani da NigerPay QR.' 
                : 'Vous pouvez payer chez les commerçants ou envoyer à un ami via le QR NigerPay.'; ?>
        </p>
    </div>
</div>

<script src="https://unpkg.com/html5-qrcode"></script>

<script>
    function onScanSuccess(decodedText, decodedResult) {
        // Stop scanning after success
        html5QrcodeScanner.clear();
        
        // Visual haptic feedback (vibration) if supported
        if ("vibrate" in navigator) navigator.vibrate(100);

        // Process the data: 
        // We expect format: nigerpay:PHONE_NUMBER or nigerpay:MERCHANT_ID
        if (decodedText.startsWith("nigerpay:")) {
            const data = decodedText.split(":")[1];
            // Redirect to the transfer page with the scanned target
            window.location.href = `transfer.php?target=${data}&method=qr`;
        } else {
            alert("<?php echo $isHausa ? 'Wannan lambar QR ba ta NigerPay ba ce.' : 'Code QR NigerPay non valide.'; ?>");
            location.reload();
        }
    }

    function onScanFailure(error) {
        // Silently ignore failures to keep scanning
    }

    let html5QrcodeScanner = new Html5QrcodeScanner(
        "reader", 
        { fps: 15, qrbox: {width: 250, height: 250}, aspectRatio: 1.0 },
        /* verbose= */ false
    );
    
    html5QrcodeScanner.render(onScanSuccess, onScanFailure);

    // Styling the library generated elements via JS
    setTimeout(() => {
        const btn = document.querySelector("#reader button");
        if(btn) {
            btn.className = "bg-primary-600 text-white px-6 py-3 rounded-xl font-black uppercase text-xs tracking-widest shadow-lg mb-4";
            btn.innerHTML = "<?php echo $isHausa ? 'Bude Kamara' : 'Activer Caméra'; ?>";
        }
    }, 500);
</script>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>