<?php
/**
 * NigerPay - Customer Transfer Page
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'customer') {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$target = $_GET['target'] ?? ''; // Pre-filled from QR Scan if available

$balance = getAccountBalance($currentUser['id'], 'primary')['available_balance'] ?? 0;

$pageTitle = $isHausa ? 'Tura Kuɗi' : 'Envoyer de l\'argent';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto">
    <div class="mb-8">
        <h1 class="text-2xl font-black text-slate-900"><?php echo $isHausa ? 'Tura Kuɗi' : 'Transfert'; ?></h1>
        <p class="text-slate-500 text-sm"><?php echo $isHausa ? 'Tura kuɗi zuwa kowane lambar NigerPay' : 'Envoyez de l\'argent vers tout numéro NigerPay'; ?></p>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-8">
        <form id="transferForm" class="space-y-6">
            <?php csrfField(); ?>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Lambar Mai Karɓa' : 'Bénéficiaire'; ?></label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 pl-5 flex items-center text-slate-400 font-bold">+227</span>
                    <input type="tel" id="recipient_phone" name="phone" value="<?php echo htmlspecialchars($target); ?>" 
                           placeholder="90 00 00 00" 
                           class="w-full pl-16 pr-4 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-bold text-xl">
                </div>
                <div id="verifyName" class="hidden animate-fade-in p-3 bg-primary-50 rounded-xl flex items-center">
                    <i class="fas fa-check-circle text-primary-500 mr-2"></i>
                    <span id="displayName" class="text-xs font-bold text-primary-700 uppercase">---</span>
                </div>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Adadin Kuɗi' : 'Montant'; ?></label>
                <div class="relative">
                    <input type="number" id="amount" name="amount" placeholder="0" 
                           class="w-full px-6 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-black text-3xl">
                    <span class="absolute inset-y-0 right-0 pr-6 flex items-center text-slate-400 font-black">XOF</span>
                </div>
                <p class="text-[10px] text-slate-400 font-medium px-2">
                    <?php echo $isHausa ? 'Balance naka:' : 'Votre solde:'; ?> <?php echo number_format($balance, 0, ',', ' '); ?> XOF
                </p>
            </div>

            <div class="flex gap-2 overflow-x-auto no-scrollbar pb-2">
                <?php foreach([500, 1000, 5000, 10000] as $val): ?>
                    <button type="button" onclick="document.getElementById('amount').value=<?php echo $val; ?>" 
                            class="px-4 py-2 bg-slate-100 rounded-full text-xs font-bold text-slate-600 whitespace-nowrap">+<?php echo number_format($val, 0); ?></button>
                <?php endforeach; ?>
            </div>

            <button type="button" onclick="handleTransfer()" 
                    class="w-full bg-primary-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-primary-100 transition-all active:scale-95 flex items-center justify-center">
                <span><?php echo $isHausa ? 'TURA YANZU' : 'ENVOYER MAINTENANT'; ?></span>
                <i class="fas fa-paper-plane ml-2 text-xs opacity-50"></i>
            </button>
        </form>
    </div>
</div>

<script>
// Mock verification logic
document.getElementById('recipient_phone').addEventListener('input', function(e) {
    if(e.target.value.length >= 8) {
        document.getElementById('verifyName').classList.remove('hidden');
        document.getElementById('displayName').innerText = "Abdoulaye Mamane"; // Simulate DB check
    } else {
        document.getElementById('verifyName').classList.add('hidden');
    }
});

function handleTransfer() {
    const amount = document.getElementById('amount').value;
    if(amount > <?php echo $balance; ?>) {
        alert("Ba ka da isassun kuɗi / Solde insuffisant");
        return;
    }
    // Final logic: Open PIN Modal, then submit
    alert("Transaction Successful!");
    window.location.href = 'dashboard.php';
}
</script>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>