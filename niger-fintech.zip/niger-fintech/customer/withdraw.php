<?php
/**
 * NigerPay - Withdrawal Token Generator
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn()) { header('Location: /login.php'); exit; }

$currentUser = getCurrentUser();
$userId = $currentUser['id'];
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

$error = '';
$token = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = (int)$_POST['amount'];
    $pin = $_POST['pin'];

    // 1. Verify PIN
    if (!password_verify($pin, $currentUser['pin_hash'])) {
        $error = "PIN ba daidai ba / PIN incorrect";
    } else {
        // 2. Trigger Ledger withdrawal request (this locks the balance)
        // processWithdrawalRequest is a function we'd add to ledger.php
        $result = processWithdrawalRequest($userId, $amount);
        if ($result['success']) {
            $token = $result['token'];
        } else {
            $error = $result['message'];
        }
    }
}

$pageTitle = $isHausa ? 'Cire Kudi' : 'Retrait Cash';
include __DIR__ . '/includes/header-customer.php';
?>

<div class="max-w-md mx-auto">
    <?php if (!$token): ?>
    <div class="bg-white rounded-[2.5rem] p-10 shadow-soft border border-slate-100">
        <h2 class="text-xl font-black text-slate-900 mb-8"><?php echo $isHausa ? 'Samu Code' : 'Générer un Code'; ?></h2>
        <form method="POST" class="space-y-6">
            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Montant XOF</label>
                <input type="number" name="amount" required class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-black text-2xl">
            </div>
            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest">PIN Secreta</label>
                <input type="password" name="pin" maxlength="4" required class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl text-center text-2xl tracking-[0.5em]">
            </div>
            <button type="submit" class="w-full bg-slate-900 text-white font-black py-5 rounded-2xl uppercase tracking-widest shadow-xl">Confirm Retrait</button>
        </form>
    </div>
    <?php else: ?>
    <div class="text-center p-10 bg-white rounded-[3rem] shadow-2xl border-2 border-primary-500">
        <i class="fas fa-shield-check text-primary-500 text-4xl mb-4"></i>
        <h2 class="text-sm font-black uppercase text-slate-400 mb-8 tracking-[0.3em]">Votre Code de Retrait</h2>
        <div class="text-5xl font-black tracking-[0.2em] text-slate-900 mb-10"><?php echo $token; ?></div>
        <p class="text-xs text-slate-500 leading-relaxed italic">"Donnez ce code à un agent NigerPay pour recevoir vos espèces."</p>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer-customer.php'; ?>