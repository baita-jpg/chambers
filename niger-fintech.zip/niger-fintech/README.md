# NigerPay - Système Financier Mobile

Un système financier mobile complet conçu pour le Niger, optimisé pour les environnements à faible connectivité et conforme aux réglementations BCEAO/UEMOA.

## 🏗️ Architecture du Système

### N-Tier Layered Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  Agent App   │  │Customer App  │  │Admin Dashboard│      │
│  │  (Mobile)    │  │(USSD + Web)  │  │   (Web)      │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                      LOGIC LAYER                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  IAM Module  │  │Ledger Engine │  │Notification │      │
│  │(Auth/PIN)    │  │(Double-Entry)│  │   Engine     │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                   INTEGRATION LAYER                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │Orange Money  │  │Airtel Money  │  │  GIM-UEMOA   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────┐
│                     DATA LAYER                               │
│                    MySQL 8.0 (InnoDB)                        │
└─────────────────────────────────────────────────────────────┘
```

## 📋 Prérequis

- **PHP**: 8.0 ou supérieur
- **MySQL**: 8.0 ou supérieur (InnoDB engine)
- **Serveur Web**: Apache 2.4+ avec mod_rewrite
- **Extensions PHP**: PDO, PDO_MySQL, mbstring, json, curl, openssl

## 🚀 Installation

### 1. Cloner le projet

```bash
cd /var/www/html
git clone https://github.com/votre-org/nigerpay.git
cd nigerpay
```

### 2. Configurer la base de données

```bash
# Se connecter à MySQL
mysql -u root -p

# Créer la base de données
source database/schema.sql
```

### 3. Configurer l'environnement

```bash
# Copier le fichier d'exemple
cp .env.example .env

# Éditer les variables
nano .env
```

Variables requises:
```env
DB_HOST=localhost
DB_NAME=niger_fintech
DB_USER=root
DB_PASS=votre_mot_de_passe

# Clés API (optionnel pour développement)
ORANGE_MONEY_CLIENT_ID=votre_id
ORANGE_MONEY_CLIENT_SECRET=votre_secret
AIRTEL_MONEY_CLIENT_ID=votre_id
AIRTEL_MONEY_CLIENT_SECRET=votre_secret
```

### 4. Configurer Apache

```apache
<VirtualHost *:80>
    ServerName nigerpay.local
    DocumentRoot /var/www/html/nigerpay
    
    <Directory /var/www/html/nigerpay>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/nigerpay-error.log
    CustomLog ${APACHE_LOG_DIR}/nigerpay-access.log combined
</VirtualHost>
```

Activer le module rewrite:
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

### 5. Permissions

```bash
# Définir les permissions
chmod -R 755 /var/www/html/nigerpay
chmod -R 775 /var/www/html/nigerpay/assets/uploads
chown -R www-data:www-data /var/www/html/nigerpay
```

## 🔐 Identifiants de démonstration

| Rôle | Téléphone | Mot de passe |
|------|-----------|--------------|
| Admin | +22700000000 | password |
| Super Agent | +22700000001 | password |

## 📁 Structure du projet

```
nigerpay/
├── admin/                  # Interface administrateur
│   ├── dashboard.php      # Tableau de bord
│   ├── users.php          # Gestion utilisateurs
│   ├── agents.php         # Gestion agents
│   ├── transactions.php   # Historique transactions
│   └── ...
├── agent/                  # Interface agent
│   ├── dashboard.php      # Tableau de bord agent
│   ├── cash-in.php        # Dépôt (Cash-In)
│   ├── cash-out.php       # Retrait (Cash-Out)
│   ├── kyc.php            # Enregistrement client
│   └── liquidity.php      # Gestion liquidité
├── customer/               # Interface client
│   ├── dashboard.php      # Compte client
│   ├── transfer.php       # Transfert P2P
│   └── history.php        # Historique
├── api/                    # API endpoints
│   └── ussd.php           # Handler USSD
├── includes/               # Fichiers core
│   ├── functions.php      # Fonctions utilitaires
│   ├── auth.php           # Authentification
│   ├── ledger.php         # Moteur comptable
│   └── integrations.php   # Intégrations externes
├── config/                 # Configuration
│   └── database.php       # Connexion DB
├── database/               # Schémas SQL
│   └── schema.sql         # Structure complète
├── assets/                 # Ressources statiques
│   ├── css/               # Styles
│   ├── js/                # Scripts
│   └── uploads/           # Uploads (KYC)
├── .htaccess              # Configuration Apache
├── index.php              # Page d'accueil
├── login.php              # Connexion
└── logout.php             # Déconnexion
```

## 💰 Cercles de Transaction

### Cercle 1: Onboarding (KYC)

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  Capture │ -> │Validation│ -> │  Tiering │ -> │Activation│
└──────────┘    └──────────┘    └──────────┘    └──────────┘
     │               │               │               │
   Scan NINA     Vérif téléphone   KYC Tier 1    SMS PIN
   Photo selfie  Vérif doublon     Limite 200K   Admin approve
```

### Cercle 2: Transaction Atomique

```
┌──────────┐    ┌──────────────┐    ┌──────────┐    ┌──────────┐
│  Request │ -> │Authorization │ -> │  Lock    │ -> │ Movement │
└──────────┘    └──────────────┘    └──────────┘    └──────────┘
     │               │                  │               │
   Agent           Client PIN       Verrouillage    Double-Entry
   saisit          confirmation     des fonds       Debit/Credit
   montant                                          + Commission
```

### Cercle 3: Liquidité (Rebalancing)

```
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│Super-Agent   │ -> │Admin Push    │ -> │Downstreaming │
│Dépôt banque  │    │Wallet funding│    │Sub-agents    │
└──────────────┘    └──────────────┘    └──────────────┘
     │                   │                   │
   5M FCFA           Digital float       Achat float
   Reçu banque       Crédit wallet       Commission
```

## 🔒 Sécurité

### ACID Compliance
Toutes les transactions utilisent des blocs `START TRANSACTION` / `COMMIT` pour garantir l'atomicité.

### Immutable Logs
La table `transactions` est en **INSERT-ONLY**. Aucune mise à jour ou suppression n'est autorisée. Les erreurs sont corrigées par des transactions de reversal.

### Protection CSRF
Tous les formulaires incluent un token CSRF:
```php
csrfField(); // Génère <input type="hidden" name="csrf_token" value="...">
```

### Encryption PIN
Les PINs sont hashés avec bcrypt (coût 12):
```php
$hash = password_hash($pin, PASSWORD_BCRYPT, ['cost' => 12]);
```

### Sessions sécurisées
- HttpOnly cookies
- SameSite=Strict
- Régénération d'ID périodique
- Timeout après 30 minutes d'inactivité

## 📱 USSD

Code court: `*123#`

### Menu principal
```
Bienvenue sur NigerPay
1. Consulter solde
2. Envoyer argent
3. Retirer argent
4. Dernières transactions
5. Aide
```

## 🔌 Intégrations

### Orange Money
```php
$om = new OrangeMoneyAPI();
$result = $om->initiatePayment([
    'order_id' => 'ORDER-123',
    'amount' => 10000,
    'reference' => 'Paiement facture'
]);
```

### Airtel Money
```php
$am = new AirtelMoneyAPI();
$result = $am->collect([
    'phone' => 'XXXXXXXX',
    'amount' => 10000,
    'reference' => 'REF-123'
]);
```

### GIM-UEMOA
```php
$gim = new GIMUEMOA_API();
$result = $gim->initiateTransfer([
    'sender_account' => '...',
    'receiver_account' => '...',
    'receiver_bank_code' => '...',
    'amount' => 1000000
]);
```

## 📊 Limites KYC (BCEAO)

| Tier | Nom | Solde Max | Journalier | Mensuel |
|------|-----|-----------|------------|---------|
| 1 | Basic | 200 000 FCFA | 50 000 FCFA | 500 000 FCFA |
| 2 | Standard | 1 000 000 FCFA | 200 000 FCFA | 2 000 000 FCFA |
| 3 | Premium | 5 000 000 FCFA | 1 000 000 FCFA | 10 000 000 FCFA |
| 4 | Business | 50 000 000 FCFA | 10 000 000 FCFA | 100 000 000 FCFA |

## 🧪 Tests

```bash
# Exécuter les tests
php vendor/bin/phpunit

# Tests spécifiques
php vendor/bin/phpunit tests/LedgerTest.php
php vendor/bin/phpunit tests/AuthTest.php
```

## 📈 Monitoring

### Logs
- `/var/log/niger-fintech/errors.log` - Erreurs PHP
- `/var/log/niger-fintech/transactions.log` - Transactions
- `/var/log/niger-fintech/audit.log` - Audit trail

### Métriques clés
- Nombre de transactions/jour
- Volume total
- Taux d'échec
- Temps de réponse moyen

## 🚀 Déploiement production

### Checklist
- [ ] Changer tous les mots de passe par défaut
- [ ] Activer HTTPS
- [ ] Configurer les vraies clés API
- [ ] Désactiver l'affichage des erreurs PHP
- [ ] Configurer les backups automatiques
- [ ] Mettre en place la surveillance
- [ ] Tester le failover

### Commandes de déploiement
```bash
# Backup base de données
mysqldump -u root -p niger_fintech > backup_$(date +%Y%m%d).sql

# Déployer les fichiers
git pull origin main

# Vider le cache
rm -rf /tmp/nigerpay-cache/*

# Vérifier les permissions
chown -R www-data:www-data /var/www/html/nigerpay
```

## 📞 Support

- **Email**: support@nigerpay.ne
- **Téléphone**: +227 XX XX XX XX
- **Adresse**: Niamey, Niger

## 📄 Licence

Ce projet est sous licence propriétaire. Tous droits réservés © NigerPay.

---

**Conforme aux réglementations BCEAO et UEMOA**
