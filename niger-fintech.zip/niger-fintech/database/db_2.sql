-- =====================================================
-- NIGER FINTECH SYSTEM - DATABASE SCHEMA
-- For High-Trust, Low-Connectivity Environments
-- Currency: CFA Franc (XOF)
-- =====================================================

-- Create Database
CREATE DATABASE IF NOT EXISTS niger_fintech 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE niger_fintech;

-- =====================================================
-- CORE TABLES
-- =====================================================

-- Users Table (Base for all user types)
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    phone_number VARCHAR(20) NOT NULL UNIQUE,
    pin_hash VARCHAR(255) NOT NULL,
    user_type ENUM('customer', 'agent', 'super_agent', 'admin', 'staff') NOT NULL DEFAULT 'customer',
    kyc_tier TINYINT UNSIGNED NOT NULL DEFAULT 1,
    kyc_status ENUM('pending', 'approved', 'rejected', 'suspended') NOT NULL DEFAULT 'pending',
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE,
    date_of_birth DATE,
    gender ENUM('M', 'F'),
    nationality VARCHAR(3) DEFAULT 'NER',
    nina_number VARCHAR(50),
    id_document_type ENUM('nina', 'passport', 'driver_license', 'voter_card'),
    id_document_number VARCHAR(50) UNIQUE,
    id_document_expiry DATE,
    address TEXT,
    city VARCHAR(100),
    region VARCHAR(100),
    country VARCHAR(3) DEFAULT 'NER',
    gps_coordinates VARCHAR(50),
    profile_photo_url VARCHAR(255),
    id_document_front_url VARCHAR(255),
    id_document_back_url VARCHAR(255),
    selfie_url VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    is_blocked BOOLEAN DEFAULT FALSE,
    block_reason TEXT,
    failed_pin_attempts TINYINT UNSIGNED DEFAULT 0,
    last_login_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by BIGINT UNSIGNED,
    approved_by BIGINT UNSIGNED,
    approved_at TIMESTAMP NULL,
    
    INDEX idx_phone (phone_number),
    INDEX idx_kyc_status (kyc_status),
    INDEX idx_user_type (user_type),
    INDEX idx_name (last_name, first_name),
    
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Wallet Accounts Table (Double-Entry Bookkeeping)
CREATE TABLE wallet_accounts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    account_type ENUM('primary', 'commission', 'float', 'savings', 'locked') NOT NULL DEFAULT 'primary',
    account_number VARCHAR(50) NOT NULL UNIQUE,
    balance BIGINT UNSIGNED NOT NULL DEFAULT 0,
    available_balance BIGINT UNSIGNED NOT NULL DEFAULT 0,
    locked_amount BIGINT UNSIGNED NOT NULL DEFAULT 0,
    currency VARCHAR(3) DEFAULT 'XOF',
    daily_limit BIGINT UNSIGNED,
    monthly_limit BIGINT UNSIGNED,
    tier_limit BIGINT UNSIGNED NOT NULL DEFAULT 200000,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_user (user_id),
    INDEX idx_account_type (account_type),
    INDEX idx_account_number (account_number),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Transactions Table (IMMUTABLE - Insert Only)
CREATE TABLE transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(50) NOT NULL UNIQUE,
    transaction_type ENUM('cash_in', 'cash_out', 'transfer', 'payment', 'commission', 'fee', 'reversal', 'liquidity_deposit', 'liquidity_withdrawal', 'airtime', 'bill_payment') NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'failed', 'reversed') NOT NULL DEFAULT 'pending',
    
    -- Double-Entry Bookkeeping
    debit_account_id BIGINT UNSIGNED,
    credit_account_id BIGINT UNSIGNED,
    
    amount BIGINT UNSIGNED NOT NULL,
    fee_amount BIGINT UNSIGNED DEFAULT 0,
    commission_amount BIGINT UNSIGNED DEFAULT 0,
    total_amount BIGINT UNSIGNED NOT NULL,
    
    -- Currency
    currency VARCHAR(3) DEFAULT 'XOF',
    exchange_rate DECIMAL(10,6) DEFAULT 1.000000,
    
    -- Parties
    sender_user_id BIGINT UNSIGNED,
    receiver_user_id BIGINT UNSIGNED,
    sender_phone VARCHAR(20),
    receiver_phone VARCHAR(20),
    
    -- Agent Information
    agent_id BIGINT UNSIGNED,
    super_agent_id BIGINT UNSIGNED,
    
    -- External References
    external_reference VARCHAR(100),
    external_provider ENUM('orange_money', 'airtel_money', 'moov_money', 'gim_uemoa', 'bank_transfer'),
    
    -- Description & Metadata
    description TEXT,
    metadata JSON,
    
    -- Location (for fraud detection)
    gps_lat DECIMAL(10, 8),
    gps_lng DECIMAL(11, 8),
    ip_address VARCHAR(45),
    device_id VARCHAR(100),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    reversed_at TIMESTAMP NULL,
    
    -- Reversal Information
    is_reversal BOOLEAN DEFAULT FALSE,
    original_transaction_id VARCHAR(50),
    reversal_reason TEXT,
    
    -- Authorization
    authorized_by BIGINT UNSIGNED,
    authorization_code VARCHAR(100),
    
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_sender (sender_user_id),
    INDEX idx_receiver (receiver_user_id),
    INDEX idx_debit_account (debit_account_id),
    INDEX idx_credit_account (credit_account_id),
    INDEX idx_status (status),
    INDEX idx_type (transaction_type),
    INDEX idx_created (created_at),
    INDEX idx_external_ref (external_reference),
    INDEX idx_agent_status_date (agent_id, status, created_at),
    INDEX idx_sender_phone (sender_phone),
    INDEX idx_receiver_phone (receiver_phone),
    
    FOREIGN KEY (debit_account_id) REFERENCES wallet_accounts(id) ON DELETE SET NULL,
    FOREIGN KEY (credit_account_id) REFERENCES wallet_accounts(id) ON DELETE SET NULL,
    FOREIGN KEY (sender_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (receiver_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (agent_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (super_agent_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (authorized_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Transaction Log (Audit Trail)
CREATE TABLE transaction_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(50) NOT NULL,
    log_type ENUM('created', 'processing', 'completed', 'failed', 'reversed', 'locked', 'unlocked') NOT NULL,
    old_status VARCHAR(50),
    new_status VARCHAR(50),
    details JSON,
    created_by BIGINT UNSIGNED,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_transaction (transaction_id),
    INDEX idx_log_type (log_type),
    INDEX idx_created (created_at),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Ledger Entries (Double-Entry Bookkeeping Detail)
CREATE TABLE ledger_entries (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(50) NOT NULL,
    account_id BIGINT UNSIGNED NOT NULL,
    entry_type ENUM('debit', 'credit') NOT NULL,
    amount BIGINT UNSIGNED NOT NULL,
    balance_after BIGINT UNSIGNED NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_transaction (transaction_id),
    INDEX idx_account (account_id),
    INDEX idx_entry_type (entry_type),
    FOREIGN KEY (account_id) REFERENCES wallet_accounts(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- AGENT & LIQUIDITY MANAGEMENT
-- =====================================================

-- Agent Details
CREATE TABLE agent_details (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    agent_code VARCHAR(20) NOT NULL UNIQUE,
    super_agent_id BIGINT UNSIGNED,
    business_name VARCHAR(200),
    business_type ENUM('individual', 'partnership', 'company') DEFAULT 'individual',
    business_registration VARCHAR(100),
    tax_id VARCHAR(50),
    shop_address TEXT,
    shop_gps VARCHAR(50),
    operating_hours VARCHAR(100),
    commission_rate DECIMAL(5,4) DEFAULT 0.0100,
    float_minimum BIGINT UNSIGNED DEFAULT 50000,
    float_maximum BIGINT UNSIGNED DEFAULT 5000000,
    daily_transaction_limit BIGINT UNSIGNED DEFAULT 10000000,
    territory VARCHAR(100),
    performance_score DECIMAL(5,2) DEFAULT 5.00,
    last_liquidity_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_agent_code (agent_code),
    INDEX idx_super_agent (super_agent_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (super_agent_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Liquidity Movements (Float Management)
CREATE TABLE liquidity_movements (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    movement_type ENUM('deposit', 'withdrawal', 'transfer', 'rebalancing') NOT NULL,
    from_user_id BIGINT UNSIGNED,
    to_user_id BIGINT UNSIGNED NOT NULL,
    from_account_id BIGINT UNSIGNED,
    to_account_id BIGINT UNSIGNED,
    amount BIGINT UNSIGNED NOT NULL,
    reference_number VARCHAR(100),
    bank_name VARCHAR(100),
    bank_account VARCHAR(100),
    deposit_slip_url VARCHAR(255),
    status ENUM('pending', 'verified', 'rejected', 'completed') DEFAULT 'pending',
    verified_by BIGINT UNSIGNED,
    verified_at TIMESTAMP NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_from_user (from_user_id),
    INDEX idx_to_user (to_user_id),
    INDEX idx_status (status),
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================
-- KYC & COMPLIANCE
-- =====================================================

-- KYC Documents
CREATE TABLE kyc_documents (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    document_type ENUM('id_front', 'id_back', 'selfie', 'proof_of_address', 'business_registration', 'tax_certificate') NOT NULL,
    file_url VARCHAR(255) NOT NULL,
    file_hash VARCHAR(64),
    verification_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    rejection_reason TEXT,
    verified_by BIGINT UNSIGNED,
    verified_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_user (user_id),
    INDEX idx_status (verification_status),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- KYC Tier Limits (BCEAO Compliance)
CREATE TABLE kyc_tier_limits (
    id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tier_level TINYINT UNSIGNED NOT NULL UNIQUE,
    tier_name VARCHAR(50) NOT NULL,
    max_balance BIGINT UNSIGNED NOT NULL,
    daily_limit BIGINT UNSIGNED NOT NULL,
    monthly_limit BIGINT UNSIGNED NOT NULL,
    annual_limit BIGINT UNSIGNED NOT NULL,
    requires_id BOOLEAN DEFAULT TRUE,
    requires_address BOOLEAN DEFAULT FALSE,
    requires_selfie BOOLEAN DEFAULT FALSE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert BCEAO Standard Tier Limits
INSERT INTO kyc_tier_limits (tier_level, tier_name, max_balance, daily_limit, monthly_limit, annual_limit, requires_id, requires_address, requires_selfie, description) VALUES
(1, 'Basic', 200000, 50000, 500000, 2000000, TRUE, FALSE, FALSE, 'Basic tier with NINA card only'),
(2, 'Standard', 1000000, 200000, 2000000, 10000000, TRUE, TRUE, TRUE, 'Standard tier with address verification'),
(3, 'Premium', 5000000, 1000000, 10000000, 50000000, TRUE, TRUE, TRUE, 'Premium tier with full KYC'),
(4, 'Business', 50000000, 10000000, 100000000, 500000000, TRUE, TRUE, TRUE, 'Business/Agent tier');

-- =====================================================
-- NOTIFICATIONS & MESSAGING
-- =====================================================

-- SMS Notifications
CREATE TABLE sms_notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    phone_number VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    message_type ENUM('transaction', 'otp', 'kyc', 'marketing', 'alert', 'system') NOT NULL,
    status ENUM('pending', 'sent', 'failed', 'delivered') DEFAULT 'pending',
    provider VARCHAR(50),
    provider_message_id VARCHAR(100),
    sent_at TIMESTAMP NULL,
    delivered_at TIMESTAMP NULL,
    error_message TEXT,
    retry_count TINYINT UNSIGNED DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_phone (phone_number),
    INDEX idx_status (status),
    INDEX idx_type (message_type),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- Notification Templates
CREATE TABLE notification_templates (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    template_code VARCHAR(50) NOT NULL UNIQUE,
    template_name VARCHAR(100) NOT NULL,
    sms_template TEXT,
    email_subject VARCHAR(200),
    email_template TEXT,
    push_template TEXT,
    language VARCHAR(5) DEFAULT 'fr',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert default SMS templates (French)
INSERT INTO notification_templates (template_code, template_name, sms_template, language) VALUES
('WELCOME', 'Welcome Message', 'Bienvenue sur [PLATFORM_NAME]! Votre compte a ete cree avec succes. Composez *123# pour commencer.', 'fr'),
('CASH_IN', 'Cash In Receipt', 'Transfert recu: [AMOUNT] FCFA de [SENDER]. ID: [TRANSACTION_ID]. Solde: [BALANCE] FCFA', 'fr'),
('CASH_OUT', 'Cash Out Receipt', 'Retrait effectue: [AMOUNT] FCFA vers [RECEIVER]. ID: [TRANSACTION_ID]. Solde: [BALANCE] FCFA', 'fr'),
('TRANSFER', 'Transfer Receipt', 'Transfert envoye: [AMOUNT] FCFA a [RECEIVER]. ID: [TRANSACTION_ID]. Solde: [BALANCE] FCFA', 'fr'),
('COMMISSION', 'Commission Credit', 'Commission recue: [AMOUNT] FCFA. ID: [TRANSACTION_ID]. Solde commission: [BALANCE] FCFA', 'fr'),
('OTP', 'One Time PIN', 'Votre code de verification est: [CODE]. Ne partagez ce code avec personne.', 'fr'),
('KYC_APPROVED', 'KYC Approved', 'Felicitations! Votre compte a ete verifie. Votre limite est maintenant de [LIMIT] FCFA.', 'fr'),
('LIQUIDITY_LOW', 'Low Liquidity Alert', 'Alerte: Votre solde de float est faible ([BALANCE] FCFA). Veuillez recharger.', 'fr'),
('PIN_RESET', 'PIN Reset', 'Votre code PIN a ete reinitialise avec succes. Si vous n\'etes pas a l\'origine de cette action, contactez-nous immediatement.', 'fr');

-- =====================================================
-- FRAUD & SECURITY
-- =====================================================

-- Fraud Rules
CREATE TABLE fraud_rules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    rule_type ENUM('velocity', 'amount', 'location', 'device', 'pattern') NOT NULL,
    rule_condition TEXT NOT NULL,
    action ENUM('block', 'flag', 'review', 'notify') NOT NULL DEFAULT 'flag',
    is_active BOOLEAN DEFAULT TRUE,
    priority TINYINT UNSIGNED DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Fraud Alerts
CREATE TABLE fraud_alerts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED,
    transaction_id VARCHAR(50),
    rule_id INT UNSIGNED,
    alert_type VARCHAR(50),
    severity ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    description TEXT,
    status ENUM('open', 'investigating', 'resolved', 'false_positive') DEFAULT 'open',
    resolved_by BIGINT UNSIGNED,
    resolved_at TIMESTAMP NULL,
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_user (user_id),
    INDEX idx_transaction (transaction_id),
    INDEX idx_status (status),
    INDEX idx_severity (severity),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (rule_id) REFERENCES fraud_rules(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Session Management
CREATE TABLE user_sessions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    session_token VARCHAR(255) NOT NULL UNIQUE,
    device_info TEXT,
    ip_address VARCHAR(45),
    gps_location VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_user (user_id),
    INDEX idx_token (session_token),
    INDEX idx_expires (expires_at),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- AUDIT & CONFIGURATION
-- =====================================================

-- Audit Log
CREATE TABLE audit_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL,
    record_id BIGINT UNSIGNED NOT NULL,
    action ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    old_values JSON,
    new_values JSON,
    performed_by BIGINT UNSIGNED,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_table (table_name),
    INDEX idx_record (record_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at),
    FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- System Configuration
CREATE TABLE system_config (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) NOT NULL UNIQUE,
    config_value TEXT,
    config_group VARCHAR(50),
    description TEXT,
    is_editable BOOLEAN DEFAULT TRUE,
    updated_by BIGINT UNSIGNED,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Insert default configuration
INSERT INTO system_config (config_key, config_value, config_group, description) VALUES
('platform_name', 'NigerPay', 'general', 'Platform display name'),
('platform_currency', 'XOF', 'general', 'Default currency code'),
('cash_in_fee_percent', '0', 'fees', 'Cash-in fee percentage'),
('cash_out_fee_percent', '1.5', 'fees', 'Cash-out fee percentage'),
('transfer_fee_percent', '0.5', 'fees', 'P2P transfer fee percentage'),
('agent_commission_rate', '1.0', 'commissions', 'Default agent commission rate'),
('super_agent_commission_rate', '0.3', 'commissions', 'Super agent override commission'),
('min_transaction_amount', '100', 'limits', 'Minimum transaction amount'),
('max_transaction_amount', '1000000', 'limits', 'Maximum transaction amount'),
('session_timeout', '1800', 'security', 'Session timeout in seconds'),
('pin_max_attempts', '3', 'security', 'Maximum PIN attempts before lockout'),
('sms_provider', 'twilio', 'integrations', 'SMS gateway provider'),
('ussd_code', '*123#', 'general', 'USSD short code');

-- =====================================================
-- VIEWS FOR REPORTING
-- =====================================================

-- Daily Transaction Summary View
CREATE VIEW vw_daily_transactions AS
SELECT 
    DATE(created_at) as transaction_date,
    transaction_type,
    COUNT(*) as transaction_count,
    SUM(amount) as total_amount,
    SUM(fee_amount) as total_fees,
    SUM(commission_amount) as total_commissions,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as successful_count,
    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count
FROM transactions
GROUP BY DATE(created_at), transaction_type;

-- Agent Performance View
CREATE VIEW vw_agent_performance AS
SELECT 
    u.id as agent_id,
    u.first_name,
    u.last_name,
    ad.agent_code,
    ad.business_name,
    wa.balance as current_float,
    COUNT(t.id) as monthly_transactions,
    SUM(t.commission_amount) as monthly_commission,
    SUM(CASE WHEN t.transaction_type = 'cash_in' THEN t.amount ELSE 0 END) as total_cash_in,
    SUM(CASE WHEN t.transaction_type = 'cash_out' THEN t.amount ELSE 0 END) as total_cash_out
FROM users u
JOIN agent_details ad ON u.id = ad.user_id
JOIN wallet_accounts wa ON u.id = wa.user_id AND wa.account_type = 'float'
LEFT JOIN transactions t ON u.id = t.agent_id 
    AND t.status = 'completed' 
    AND t.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
WHERE u.user_type = 'agent'
GROUP BY u.id, u.first_name, u.last_name, ad.agent_code, ad.business_name, wa.balance;

-- =====================================================
-- STORED PROCEDURES
-- =====================================================

DELIMITER //

-- Procedure: Process Atomic Transaction
CREATE PROCEDURE sp_process_transaction(
    IN p_transaction_id VARCHAR(50),
    IN p_transaction_type VARCHAR(50),
    IN p_sender_phone VARCHAR(20),
    IN p_receiver_phone VARCHAR(20),
    IN p_amount BIGINT UNSIGNED,
    IN p_fee_amount BIGINT UNSIGNED,
    IN p_agent_id BIGINT UNSIGNED,
    IN p_description TEXT
)
BEGIN
    DECLARE v_sender_account_id BIGINT UNSIGNED;
    DECLARE v_receiver_account_id BIGINT UNSIGNED;
    DECLARE v_agent_commission_account BIGINT UNSIGNED;
    DECLARE v_sender_balance BIGINT UNSIGNED;
    DECLARE v_receiver_balance BIGINT UNSIGNED;
    DECLARE v_sender_user_id BIGINT UNSIGNED;
    DECLARE v_receiver_user_id BIGINT UNSIGNED;
    DECLARE v_total_amount BIGINT UNSIGNED;
    DECLARE v_commission_amount BIGINT UNSIGNED;
    
    -- Start Transaction
    START TRANSACTION;
    
    -- Calculate total
    -- Note: Fee and commission logic should be more dynamic in a real app
    SET v_total_amount = p_amount + p_fee_amount; -- Total amount debited from sender
    SET v_commission_amount = FLOOR(p_amount * 0.01); -- Example commission
    
    -- Get sender account (lock for update)
    SELECT wa.id, wa.user_id, wa.available_balance 
    INTO v_sender_account_id, v_sender_user_id, v_sender_balance
    FROM wallet_accounts wa
    JOIN users u ON wa.user_id = u.id
    WHERE u.phone_number = p_sender_phone AND wa.account_type = 'primary'
    FOR UPDATE;
    
    -- Validate sender has sufficient balance
    IF v_sender_balance < v_total_amount THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient balance';
    END IF;
    
    -- Get receiver account (lock for update)
    SELECT wa.id, wa.user_id, wa.available_balance 
    INTO v_receiver_account_id, v_receiver_user_id, v_receiver_balance
    FROM wallet_accounts wa
    JOIN users u ON wa.user_id = u.id
    WHERE u.phone_number = p_receiver_phone AND wa.account_type = 'primary'
    FOR UPDATE;
    
    -- Deduct from sender
    UPDATE wallet_accounts 
    SET balance = balance - v_total_amount,
        available_balance = available_balance - v_total_amount
    WHERE id = v_sender_account_id;
    
    -- Credit receiver
    UPDATE wallet_accounts 
    SET balance = balance + p_amount,
        available_balance = available_balance + p_amount
    WHERE id = v_receiver_account_id;
    
    -- Credit agent commission (if applicable)
    IF p_agent_id IS NOT NULL THEN
        SELECT wa.id INTO v_agent_commission_account
        FROM wallet_accounts wa
        WHERE wa.user_id = p_agent_id AND wa.account_type = 'commission';
        
        IF v_agent_commission_account IS NOT NULL THEN
            UPDATE wallet_accounts 
            SET balance = balance + v_commission_amount,
                available_balance = available_balance + v_commission_amount
            WHERE id = v_agent_commission_account;
        END IF;
    END IF;
    
    -- Insert transaction record
    INSERT INTO transactions (
        transaction_id, transaction_type, status,
        debit_account_id, credit_account_id,
        amount, fee_amount, commission_amount, total_amount, currency,
        sender_user_id, receiver_user_id,
        sender_phone, receiver_phone,
        agent_id, description, completed_at, created_at
    ) VALUES (
        p_transaction_id, p_transaction_type, 'completed',
        v_sender_account_id, v_receiver_account_id,
        p_amount, p_fee_amount, v_commission_amount, v_total_amount, 'XOF',
        v_sender_user_id, v_receiver_user_id,
        p_sender_phone, p_receiver_phone,
        p_agent_id, p_description, NOW(), NOW()
    );
    
    -- Insert ledger entries
    INSERT INTO ledger_entries (transaction_id, account_id, entry_type, amount, balance_after, description)
    VALUES (p_transaction_id, v_sender_account_id, 'debit', v_total_amount, v_sender_balance - v_total_amount, 'Transaction debit');
    
    INSERT INTO ledger_entries (transaction_id, account_id, entry_type, amount, balance_after, description)
    VALUES (p_transaction_id, v_receiver_account_id, 'credit', p_amount, v_receiver_balance + p_amount, 'Transaction credit');
    
    -- Commit
    COMMIT;
    
END //

-- Procedure: Reverse Transaction
CREATE PROCEDURE sp_reverse_transaction(
    IN p_original_transaction_id VARCHAR(50),
    IN p_reversal_reason TEXT
)
BEGIN
    DECLARE v_original_tx_id BIGINT UNSIGNED;
    DECLARE v_sender_account_id BIGINT UNSIGNED;
    DECLARE v_receiver_account_id BIGINT UNSIGNED;
    DECLARE v_amount BIGINT UNSIGNED;
    DECLARE v_fee_amount BIGINT UNSIGNED;
    DECLARE v_new_transaction_id VARCHAR(50);
    
    START TRANSACTION;
    
    -- Get original transaction
    SELECT id, debit_account_id, credit_account_id, amount, fee_amount
    INTO v_original_tx_id, v_sender_account_id, v_receiver_account_id, v_amount, v_fee_amount
    FROM transactions
    WHERE transaction_id = p_original_transaction_id;
    
    IF v_original_tx_id IS NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Original transaction not found';
    END IF;
    
    -- Generate new transaction ID
    SET v_new_transaction_id = CONCAT('REV-', p_original_transaction_id);
    
    -- Reverse the transaction (credit sender, debit receiver)
    UPDATE wallet_accounts 
    SET balance = balance + v_amount + v_fee_amount,
        available_balance = available_balance + v_amount + v_fee_amount
    WHERE id = v_sender_account_id;
    
    UPDATE wallet_accounts 
    SET balance = balance - v_amount,
        available_balance = available_balance - v_amount
    WHERE id = v_receiver_account_id;
    
    -- Mark original as reversed
    UPDATE transactions 
    SET status = 'reversed', reversed_at = NOW()
    WHERE id = v_original_tx_id;
    
    -- Insert reversal transaction
    INSERT INTO transactions (
        transaction_id, transaction_type, status,
        debit_account_id, credit_account_id,
        amount, description,
        is_reversal, original_transaction_id, reversal_reason,
        created_at
    ) VALUES (
        v_new_transaction_id, 'reversal', 'completed',
        v_receiver_account_id, v_sender_account_id,
        v_amount, CONCAT('Reversal of ', p_original_transaction_id),
        TRUE, p_original_transaction_id, p_reversal_reason,
        NOW()
    );
    
    COMMIT;
    
END //

DELIMITER ;

-- =====================================================
-- TRIGGERS FOR AUDIT
-- =====================================================

DELIMITER //

-- Trigger: Audit users table
CREATE TRIGGER trg_users_audit_update
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, old_values, new_values, performed_by, created_at)
    VALUES ('users', NEW.id, 'UPDATE', 
            JSON_OBJECT('is_active', OLD.is_active, 'is_blocked', OLD.is_blocked, 'kyc_status', OLD.kyc_status),
            JSON_OBJECT('is_active', NEW.is_active, 'is_blocked', NEW.is_blocked, 'kyc_status', NEW.kyc_status),
            NULL, NOW());
END //

-- Trigger: Prevent transaction deletion
CREATE TRIGGER trg_transactions_prevent_delete
BEFORE DELETE ON transactions
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transaction records cannot be deleted. Use reversal instead.';
END //

-- Trigger: Update wallet timestamp
CREATE TRIGGER trg_wallet_update_timestamp
BEFORE UPDATE ON wallet_accounts
FOR EACH ROW
BEGIN
    SET NEW.updated_at = NOW();
END //

DELIMITER ;

-- =====================================================
-- INITIAL DATA
-- =====================================================

-- Create default admin user (password: Admin@123 - change in production!)
INSERT INTO users (
    phone_number, pin_hash, user_type, kyc_tier, kyc_status,
    first_name, last_name, email, is_active, approved_at, created_at
) VALUES (
    '+22700000000',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- hashed 'password'
    'admin',
    4,
    'approved',
    'System',
    'Administrator',
    'admin@nigerfintech.com',
    TRUE,
    NOW(),
    NOW()
);

-- Create admin wallet
SET @admin_id = LAST_INSERT_ID();

INSERT INTO wallet_accounts (user_id, account_type, account_number, balance, available_balance, tier_limit)
VALUES (@admin_id, 'primary', 'ADM000000001', 0, 0, 999999999999);

-- Create default super agent
INSERT INTO users (
    phone_number, pin_hash, user_type, kyc_tier, kyc_status,
    first_name, last_name, email, is_active, approved_at, created_at
) VALUES (
    '+22700000001',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'super_agent',
    4,
    'approved',
    'Default',
    'Super Agent',
    'superagent@nigerfintech.com',
    TRUE,
    NOW(),
    NOW()
);

SET @super_agent_id = LAST_INSERT_ID();

INSERT INTO wallet_accounts (user_id, account_type, account_number, balance, available_balance, tier_limit)
VALUES 
    (@super_agent_id, 'primary', 'SUP000000001', 0, 0, 999999999999),
    (@super_agent_id, 'float', 'SUP000000001-F', 0, 0, 999999999999),
    (@super_agent_id, 'commission', 'SUP000000001-C', 0, 0, 999999999999);

INSERT INTO agent_details (user_id, agent_code, business_name, commission_rate, territory)
VALUES (@super_agent_id, 'SUPER001', 'Super Agent Principal', 0.3, 'Niamey');
