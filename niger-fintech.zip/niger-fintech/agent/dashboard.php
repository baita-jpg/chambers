<?php
/**
 * NigerPay - High-Performance Agent Dashboard
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn()) { header('Location: /login.php'); exit; }

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Fetch Totals for the day
$db = getDB();
$todayVolume = $db->prepare("SELECT SUM(amount) FROM transactions WHERE agent_id = ? AND DATE(created_at) = CURDATE() AND status = 'completed'");
$todayVolume->execute([$currentUser['id']]);
$totalDay = $todayVolume->fetchColumn() ?: 0;


$pageTitle = $isHausa ? 'Gidan Wakili' : 'Tableau de Bord Agent';
include __DIR__ . '/includes/header-agent.php';
?>

<div class="max-w-5xl mx-auto space-y-8 pb-12">
    
    <div class="flex justify-between items-end">
        <div>
            <h1 class="text-3xl font-black text-slate-900 tracking-tight uppercase"><?php echo $isHausa ? 'Sannu,' : 'Bonjour,'; ?> <?php echo $currentUser['first_name']; ?>!</h1>
            <p class="text-slate-500 font-medium">Agent ID: <span class="text-primary-600 font-bold"><?php echo $currentUser['agent_code'] ?? 'NP-'.str_pad($currentUser['id'], 4, '0', STR_PAD_LEFT); ?></span></p>
        </div>
        <div class="text-right">
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ayyukan Yau / Volume du jour</p>
            <p class="text-2xl font-black text-slate-900"><?php echo number_format($totalDay); ?> <span class="text-sm">XOF</span></p>
        </div>
    </div>

    <?php
// Fetch active broadcast
$broadcast = $db->query("SELECT * FROM global_notifications WHERE is_active = 1 ORDER BY created_at DESC LIMIT 1")->fetch();

if ($broadcast): 
    $colorClass = match($broadcast['severity']) {
        'danger'  => 'bg-red-50 border-red-100 text-red-700',
        'warning' => 'bg-orange-50 border-orange-100 text-orange-700',
        default   => 'bg-blue-50 border-blue-100 text-blue-700',
    };
    $icon = match($broadcast['severity']) {
        'danger'  => 'fa-circle-exclamation',
        'warning' => 'fa-triangle-exclamation',
        default   => 'fa-circle-info',
    };
?>
<div class="mb-8 p-6 rounded-[2rem] border-2 <?php echo $colorClass; ?> flex items-start animate-in slide-in-from-top duration-500">
    <div class="mr-4 mt-1 text-xl">
        <i class="fas <?php echo $icon; ?>"></i>
    </div>
    <div>
        <h4 class="font-black text-sm uppercase tracking-tight"><?php echo $broadcast['title']; ?></h4>
        <p class="text-xs font-medium opacity-80 mt-1"><?php echo $broadcast['message']; ?></p>
        <p class="text-[9px] font-black uppercase tracking-widest mt-3 opacity-50">Sent: <?php echo date('H:i', strtotime($broadcast['created_at'])); ?></p>
    </div>
</div>
<?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <a href="cash-in.php" class="bg-white group p-8 rounded-[2.5rem] shadow-soft border border-slate-100 flex items-center justify-between transition-all hover:border-primary-500 hover:shadow-xl hover:scale-[1.01]">
            <div class="flex items-center">
                <div class="w-16 h-16 bg-primary-50 text-primary-600 rounded-3xl flex items-center justify-center text-2xl group-hover:bg-primary-600 group-hover:text-white transition-all">
                    <i class="fas fa-plus"></i>
                </div>
                <div class="ml-6">
                    <h3 class="text-xl font-black text-slate-900 uppercase tracking-tight"><?php echo $isHausa ? 'Saka Kuɗi' : 'Dépôt Cash'; ?></h3>
                    <p class="text-xs text-slate-400 font-medium"><?php echo $isHausa ? 'Tura kuɗi zuwa asusun abokin ciniki' : 'Envoyer de l\'argent vers un client'; ?></p>
                </div>
            </div>
            <i class="fas fa-chevron-right text-slate-200 group-hover:text-primary-500 group-hover:translate-x-1 transition-all"></i>
        </a>

        <a href="withdraw-verify.php" class="bg-white group p-8 rounded-[2.5rem] shadow-soft border border-slate-100 flex items-center justify-between transition-all hover:border-orange-500 hover:shadow-xl hover:scale-[1.01]">
            <div class="flex items-center">
                <div class="w-16 h-16 bg-orange-50 text-orange-600 rounded-3xl flex items-center justify-center text-2xl group-hover:bg-orange-600 group-hover:text-white transition-all">
                    <i class="fas fa-minus"></i>
                </div>
                <div class="ml-6">
                    <h3 class="text-xl font-black text-slate-900 uppercase tracking-tight"><?php echo $isHausa ? 'Cire Kuɗi' : 'Retrait Cash'; ?></h3>
                    <p class="text-xs text-slate-400 font-medium"><?php echo $isHausa ? 'Biya abokin ciniki tsabar kuɗi' : 'Remettre des espèces au client via code'; ?></p>
                </div>
            </div>
            <i class="fas fa-chevron-right text-slate-200 group-hover:text-orange-500 group-hover:translate-x-1 transition-all"></i>
        </a>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
        <div class="px-8 py-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/30">
            <h3 class="text-sm font-black text-slate-900 uppercase tracking-widest"><?php echo $isHausa ? 'Ayyukan Baya' : 'Activités Récentes'; ?></h3>
            <a href="history.php" class="text-xs font-bold text-primary-600 hover:underline"><?php echo $isHausa ? 'Duba Duka' : 'Voir tout'; ?></a>
        </div>
        
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                    <tr>
                        <th class="px-8 py-4">Time</th>
                        <th class="px-8 py-4">Customer</th>
                        <th class="px-8 py-4">Type</th>
                        <th class="px-8 py-4 text-right">Amount (XOF)</th>
                        <th class="px-8 py-4 text-center">Receipt</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <tr class="hover:bg-slate-50/50 transition-colors group">
                        <td class="px-8 py-5 text-xs font-bold text-slate-500">14:20</td>
                        <td class="px-8 py-5 text-sm font-black text-slate-900">+227 90 00 00 00</td>
                        <td class="px-8 py-5">
                            <span class="bg-green-100 text-green-700 text-[9px] font-black px-2 py-0.5 rounded uppercase">Cash-In</span>
                        </td>
                        <td class="px-8 py-5 text-right font-black text-slate-900">10,000</td>
                        <td class="px-8 py-5 text-center">
                            <button onclick="printReceipt('TXN001')" class="text-slate-400 hover:text-primary-600 transition-colors"><i class="fas fa-print"></i></button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer-agent.php'; ?>