<?php
/**
 * NigerPay - Admin Bulk Activity Reports
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'admin') {
    header('Location: /login.php'); exit;
}

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Fetch Agents for the dropdown
$agents = $db->query("
    SELECT u.id, u.first_name, ad.agent_code, ad.branch_location 
    FROM users u 
    JOIN agent_details ad ON u.id = ad.user_id 
    WHERE u.user_type = 'agent'
")->fetchAll();

$pageTitle = $isHausa ? 'Buga Rahotanni' : 'Rapports Groupés';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-4xl mx-auto pb-20">
    <div class="mb-8">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $isHausa ? 'Rahoton Ma\'amala' : 'Rapports d\'Activité'; ?></h1>
        <p class="text-slate-500 font-medium"><?php echo $isHausa ? 'Zabakwani wakili ko reshe domin buga takarda.' : 'Générez des rapports groupés par agent ou par branche.'; ?></p>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-10">
        <form action="print-bulk.php" method="GET" target="_blank" class="space-y-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Wakili (Agent)</label>
                    <select name="agent_id" class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-bold focus:border-primary-500 transition-all">
                        <option value="all">-- All Agents --</option>
                        <?php foreach($agents as $agent): ?>
                            <option value="<?php echo $agent['id']; ?>">
                                <?php echo $agent['agent_code']; ?> - <?php echo $agent['first_name']; ?> (<?php echo $agent['branch_location']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Rana (Date)</label>
                    <input type="date" name="report_date" value="<?php echo date('Y-m-d'); ?>" 
                           class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-bold focus:border-primary-500 transition-all">
                </div>
            </div>

            <div class="bg-primary-50 rounded-2xl p-6 border border-primary-100 flex items-start">
                <i class="fas fa-circle-info text-primary-600 mt-1 mr-4"></i>
                <p class="text-xs text-primary-800 leading-relaxed">
                    <?php echo $isHausa 
                        ? 'Wannan zai samar da takardar PDF da ke dauke da dukkan ma\'amalolin da aka yi a ranar da aka zaba.' 
                        : 'Ceci générera un document optimisé contenant toutes les transactions effectuées pour la période sélectionnée.'; ?>
                </p>
            </div>

            <button type="submit" class="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-xl hover:scale-[1.01] transition-all uppercase tracking-widest flex items-center justify-center gap-3">
                <i class="fas fa-print opacity-50"></i>
                <span><?php echo $isHausa ? 'BUGA RAHOTON' : 'GÉNÉRER LE RAPPORT'; ?></span>
            </button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>