<?php
/**
 * NigerPay - Agent Cash-Out Validation
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['agent', 'super_agent'])) {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$error = '';
$txData = null;

// Handle code verification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_code'])) {
    $token = sanitizeInput($_POST['token']);
    
    // We use the function we created in ledger.php
    $result = completeWithdrawalWithToken($currentUser['id'], $token);
    
    if ($result['success']) {
        $txData = $result;
    } else {
        $error = $result['message'];
    }
}

$pageTitle = $isHausa ? 'Tabbatar da Cire Kudi' : 'Valider un Retrait';
include __DIR__ . '/includes/header-agent.php';
?>

<div class="max-w-xl mx-auto pb-20">
    <div class="mb-8 text-center">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $isHausa ? 'Biyan Abokin Ciniki' : 'Paiement Client'; ?></h1>
        <p class="text-slate-500 font-medium"><?php echo $isHausa ? 'Saka lambar sirrin da abokin ciniki ya baka' : 'Entrez le code de retrait fourni par le client'; ?></p>
    </div>

    <?php if (!$txData): ?>
    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-10">
        <?php if($error): ?>
            <div class="bg-red-50 text-red-600 p-4 rounded-2xl mb-6 text-sm font-bold flex items-center">
                <i class="fas fa-exclamation-circle mr-3"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-8">
            <?php csrfField(); ?>
            <div class="space-y-4">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] text-center">
                    <?php echo $isHausa ? 'Lambar Sirri (6-Digits)' : 'Code de Retrait (6 chiffres)'; ?>
                </label>
                
                <div class="flex justify-center">
                    <input type="text" name="token" maxlength="6" required placeholder="000000"
                           class="w-full max-w-[280px] text-center py-6 bg-slate-50 border-2 border-slate-100 rounded-3xl text-4xl font-black tracking-[0.5em] focus:border-primary-500 focus:bg-white transition-all outline-none">
                </div>
            </div>

            <button type="submit" name="verify_code" 
                    class="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-xl hover:scale-[1.02] active:scale-95 transition-all uppercase tracking-widest flex items-center justify-center gap-3">
                <i class="fas fa-shield-check opacity-50"></i>
                <span><?php echo $isHausa ? 'DUBA LAMBA' : 'VÉRIFIER LE CODE'; ?></span>
            </button>
        </form>
    </div>
    
    <?php else: ?>
    
    <div class="bg-white rounded-[3rem] shadow-2xl border-t-8 border-green-500 p-10 text-center animate-[pop_0.4s_ease-out]">
        <div class="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-3xl mx-auto mb-6">
            <i class="fas fa-check-double"></i>
        </div>
        
        <h2 class="text-2xl font-black text-slate-900 mb-2"><?php echo $isHausa ? 'An Yi Nasara!' : 'Succès !'; ?></h2>
        <p class="text-slate-400 text-sm mb-8 font-medium"><?php echo $isHausa ? 'Yanzu za ka iya baiwa abokin ciniki tsabar kudi.' : 'Vous pouvez maintenant remettre les espèces au client.'; ?></p>

        <div class="bg-slate-50 rounded-3xl p-8 mb-8 space-y-4">
            <div class="flex justify-between items-center border-b border-slate-200 pb-4">
                <span class="text-[10px] font-black text-slate-400 uppercase"><?php echo $isHausa ? 'Jimillar Kudi' : 'Montant à payer'; ?></span>
                <span class="text-2xl font-black text-slate-900"><?php echo number_format($txData['amount']); ?> <span class="text-xs">XOF</span></span>
            </div>
            <p class="text-[10px] font-bold text-primary-600 italic">
                <?php echo $isHausa ? 'An riga an tura maka digital float dinka.' : 'Votre float a été crédité automatiquement.'; ?>
            </p>
        </div>

        <a href="dashboard.php" class="block w-full bg-slate-100 text-slate-900 font-black py-4 rounded-2xl uppercase text-xs tracking-widest hover:bg-slate-200 transition-all">
            <?php echo $isHausa ? 'Koma Gida' : 'Retour au Tableau de Bord'; ?>
        </a>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer-agent.php'; ?>