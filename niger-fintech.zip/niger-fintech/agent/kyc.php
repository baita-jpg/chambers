<?php
/**
 * Niger Fintech System - Agent KYC Registration
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

// Require agent authentication
if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['agent', 'super_agent'])) {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRFToken($_POST['csrf_token'] ?? '')) {
    $userData = [
        'phone_number'  => sanitizeInput($_POST['phone_number'] ?? ''),
        'pin'           => $_POST['pin'] ?? '',
        'first_name'    => sanitizeInput($_POST['first_name'] ?? ''),
        'last_name'     => sanitizeInput($_POST['last_name'] ?? ''),
        'email'         => sanitizeInput($_POST['email'] ?? ''),
        'date_of_birth' => $_POST['date_of_birth'] ?? null,
        'gender'        => $_POST['gender'] ?? null,
        'nina_number'   => sanitizeInput($_POST['nina_number'] ?? ''),
        'address'       => sanitizeInput($_POST['address'] ?? ''),
        'city'          => sanitizeInput($_POST['city'] ?? ''),
        'region'        => sanitizeInput($_POST['region'] ?? ''),
        'user_type'     => 'customer',
        'kyc_tier'      => 1
    ];

    if (empty($userData['phone_number']) || empty($userData['first_name']) || empty($userData['pin'])) {
        $error = $isHausa ? 'Da fatan za a cika duk wuraren da ake buƙata.' : 'Veuillez remplir tous les champs obligatoires.';
    } else {
        $db = getDB();
        $formattedPhone = formatPhoneNumber($userData['phone_number']);
        $stmt = $db->prepare("SELECT id FROM users WHERE phone_number = ?");
        $stmt->execute([$formattedPhone]);

        if ($stmt->fetch()) {
            $error = $isHausa ? 'Wannan lambar wayar tana riga da rajista.' : 'Ce numéro de téléphone est déjà enregistré.';
        } else {
            // Logic to register user (Assuming registerUser is in functions.php)
            // For now, we simulate success
            $success = $isHausa ? 'An yi nasarar yiwa abokin ciniki rajista!' : 'Client enregistré avec succès !';
        }
    }
}

$pageTitle = $isHausa ? 'Rajistar Abokin Ciniki' : 'Enregistrement Client (KYC)';
include __DIR__ . '/includes/header-agent.php';
?>

<div class="max-w-4xl mx-auto pb-12">
    <nav class="flex mb-6 text-sm">
        <a href="dashboard.php" class="text-gray-400 hover:text-primary-600 transition"><?php echo $isHausa ? 'Babban Shafi' : 'Tableau de bord'; ?></a>
        <span class="mx-2 text-gray-300">/</span>
        <span class="text-gray-900 font-bold"><?php echo $isHausa ? 'Sabuwar Rajista' : 'Nouveau KYC'; ?></span>
    </nav>

    <div class="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
        <div class="bg-gray-50 px-8 py-6 border-b border-gray-100 flex justify-between items-center">
            <div class="flex items-center space-x-4">
                <div class="w-10 h-10 bg-primary-600 text-white rounded-full flex items-center justify-center font-bold">1</div>
                <div>
                    <h2 class="text-lg font-black text-gray-900 leading-tight"><?php echo $isHausa ? 'Bayanan Abokin Ciniki' : 'Détails du Client'; ?></h2>
                    <p class="text-xs text-gray-500 uppercase tracking-widest font-bold"><?php echo $isHausa ? 'Mataki na ɗaya' : 'Étape 1 sur 2'; ?></p>
                </div>
            </div>
            <i class="fas fa-id-card text-3xl text-gray-200"></i>
        </div>

        <div class="p-8">
            <?php if ($success): ?>
                <div class="bg-green-50 border-2 border-green-100 rounded-2xl p-6 text-center mb-6">
                    <div class="w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                        <i class="fas fa-check text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-black text-green-900"><?php echo $success; ?></h3>
                    <a href="dashboard.php" class="mt-4 inline-block bg-green-600 text-white px-8 py-3 rounded-xl font-bold transition hover:bg-green-700">OK</a>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 flex items-center">
                    <i class="fas fa-exclamation-triangle text-red-500 mr-3"></i>
                    <p class="text-sm text-red-700 font-bold"><?php echo $error; ?></p>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="space-y-8" id="kycForm">
                <?php csrfField(); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-2">
                        <label class="block text-xs font-black text-gray-400 uppercase tracking-widest"><?php echo $isHausa ? 'Lambar Waya' : 'Numéro de Téléphone'; ?> *</label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-gray-400 font-bold">+227</span>
                            <input type="tel" name="phone_number" required placeholder="90 00 00 00" 
                                   class="w-full pl-16 pr-4 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-primary-500 focus:ring-0 transition-all font-bold text-lg">
                        </div>
                    </div>

                    <div class="space-y-2">
                        <label class="block text-xs font-black text-gray-400 uppercase tracking-widest">Secret PIN *</label>
                        <input type="password" name="pin" maxlength="6" inputmode="numeric" required placeholder="••••••"
                               class="w-full px-4 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-primary-500 focus:ring-0 transition-all font-bold text-lg">
                    </div>

                    <div class="space-y-2">
                        <label class="block text-xs font-black text-gray-400 uppercase tracking-widest"><?php echo $isHausa ? 'Suna (First Name)' : 'Prénom'; ?> *</label>
                        <input type="text" name="first_name" required class="w-full px-4 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-primary-500 transition-all font-bold">
                    </div>

                    <div class="space-y-2">
                        <label class="block text-xs font-black text-gray-400 uppercase tracking-widest"><?php echo $isHausa ? 'Sunan Uba (Last Name)' : 'Nom de famille'; ?> *</label>
                        <input type="text" name="last_name" required class="w-full px-4 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-primary-500 transition-all font-bold">
                    </div>
                </div>

                <hr class="border-gray-100">

                <div class="space-y-6">
                    <h3 class="text-sm font-black text-gray-900 uppercase tracking-widest flex items-center">
                        <i class="fas fa-address-card mr-2 text-primary-500"></i> <?php echo $isHausa ? 'Shaidun Shaida' : 'Identification & Documents'; ?>
                    </h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label class="block text-xs font-black text-gray-400 uppercase tracking-widest">NINA Number</label>
                            <input type="text" name="nina_number" placeholder="1 2345 6789 0123 4"
                                   class="w-full px-4 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-primary-500 transition-all font-mono font-bold uppercase">
                        </div>

                        <div class="space-y-2">
                            <label class="block text-xs font-black text-gray-400 uppercase tracking-widest"><?php echo $isHausa ? 'Hoton Shaidar Zama Dan Kasa' : 'Photo de la Pièce ID'; ?></label>
                            <label class="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-200 border-dashed rounded-2xl cursor-pointer bg-gray-50 hover:bg-gray-100 transition-all">
                                <div class="flex flex-col items-center justify-center pt-5 pb-6">
                                    <i class="fas fa-camera text-gray-400 text-2xl mb-2"></i>
                                    <p class="text-xs text-gray-500 font-bold"><?php echo $isHausa ? 'Loda hoto ko danna nan' : 'Cliquez pour uploader'; ?></p>
                                </div>
                                <input type="file" name="id_document" class="hidden" accept="image/*" />
                            </label>
                        </div>
                    </div>
                </div>

                
                <div class="bg-primary-50 rounded-2xl p-5 border border-primary-100 flex items-start">
                    <i class="fas fa-shield-check text-primary-600 mt-1 mr-4"></i>
                    <div>
                        <h4 class="text-sm font-black text-primary-900 uppercase tracking-tight"><?php echo $isHausa ? 'Iyakokin KYC Matsaki na 1' : 'Limites KYC Niveau 1'; ?></h4>
                        <p class="text-xs text-primary-700 mt-1 leading-relaxed">
                            <?php echo $isHausa 
                                ? 'Abokin ciniki zai iya ajiye har 200,000 FCFA kuma ya cire 50,000 FCFA a kowace rana.' 
                                : 'Le client pourra garder jusqu\'à 200 000 FCFA et retirer 50 000 FCFA par jour.'; ?>
                        </p>
                    </div>
                </div>

                <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-primary-100 transition-all transform hover:scale-[1.01] active:scale-[0.98] flex items-center justify-center">
                    <i class="fas fa-user-check mr-2"></i>
                    <span><?php echo $isHausa ? 'ADANA ABOKIN CINIKI' : 'ENREGISTRER LE CLIENT'; ?></span>
                </button>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer-agent.php'; ?>