<?php
$lang = $_SESSION['lang'] ?? 'ha';
$isHausa = ($lang === 'ha');
$currentUser = getCurrentUser();

// Get Agent Code for the header display
$db = getDB();
$stmt = $db->prepare("SELECT agent_code FROM agent_details WHERE user_id = ?");
$stmt->execute([$currentUser['id']]);
$agentCode = $stmt->fetchColumn() ?: 'AG-000';
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'NigerPay Agent'; ?></title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['"Plus Jakarta Sans"', 'sans-serif'] },
                    colors: {
                        primary: { 50: '#f0fdfa', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e', 800: '#115e59', 900: '#134e4a' },
                        secondary: { 500: '#6366f1', 600: '#4f46e5', 700: '#4338ca' }
                    },
                    boxShadow: {
                        'soft': '0 2px 15px -3px rgba(0, 0, 0, 0.07), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
                    }
                }
            }
        }
    </script>
    
    <style>
        /* Modern UI Tweaks */
        body { background-color: #f8fafc; }
        .sidebar-collapsed { width: 90px !important; }
        .sidebar-collapsed .menu-text, 
        .sidebar-collapsed .sidebar-section-title,
        .sidebar-collapsed .agent-badge { display: none; }
        .nav-item-active { background: linear-gradient(to right, #14b8a6, #0d9488); color: white !important; }
        
        /* Smooth transition for sidebar */
        #sidebar { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        
        /* Header Search Glow */
        .header-search:focus-within { ring: 2px solid #14b8a6; box-shadow: 0 0 15px rgba(20, 184, 166, 0.15); }
    </style>
</head>
<body class="text-slate-900 flex h-screen overflow-hidden">

    <?php include __DIR__ . '/sidebar-agent.php'; ?>

    <div class="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
        
        <header class="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40 transition-all">
            <div class="flex items-center justify-between px-6 lg:px-10 py-3">
                
                <div class="flex items-center space-x-4">
                    <button id="toggleSidebar" class="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-50 text-slate-500 hover:bg-primary-50 hover:text-primary-600 transition-all border border-slate-200">
                        <i class="fas fa-indent text-lg"></i>
                    </button>
                    
                    <div class="hidden md:block">
                        <h2 class="text-sm font-extrabold text-slate-800 uppercase tracking-tight">
                            <?php echo $isHausa ? 'Ofishin Wakili' : 'Espace Agent'; ?>
                        </h2>
                        <p class="text-[11px] text-primary-600 font-bold flex items-center">
                            <span class="w-1.5 h-1.5 rounded-full bg-primary-500 mr-1.5 animate-pulse"></span>
                            ID: <?php echo $agentCode; ?>
                        </p>
                    </div>
                </div>

                <div class="hidden lg:flex flex-1 max-w-md mx-8">
                    <div class="w-full relative group header-search rounded-2xl transition-all">
                        <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-slate-400 group-focus-within:text-primary-500">
                            <i class="fas fa-magnifying-glass text-sm"></i>
                        </span>
                        <input type="text" 
                               placeholder="<?php echo $isHausa ? 'Bincika abokin ciniki ko lamba...' : 'Chercher un client ou transaction...'; ?>" 
                               class="w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:outline-none transition-all placeholder:text-slate-400 font-medium">
                    </div>
                </div>

                <div class="flex items-center space-x-3 md:space-x-5">
                    
                    <button class="relative w-10 h-10 flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-50 transition-colors">
                        <i class="far fa-bell text-xl"></i>
                        <span class="absolute top-2 right-2.5 w-2 h-2 bg-red-500 border-2 border-white rounded-full"></span>
                    </button>

                    <div class="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
                        <a href="?lang=ha" class="px-3 py-1 text-[10px] font-extrabold rounded-lg transition-all <?php echo $isHausa ? 'bg-white text-primary-700 shadow-sm' : 'text-slate-400 hover:text-slate-600'; ?>">HA</a>
                        <a href="?lang=fr" class="px-3 py-1 text-[10px] font-extrabold rounded-lg transition-all <?php echo !$isHausa ? 'bg-white text-primary-700 shadow-sm' : 'text-slate-400 hover:text-slate-600'; ?>">FR</a>
                    </div>

                    <div class="flex items-center pl-4 border-l border-slate-200">
                        <div class="text-right mr-3 hidden lg:block">
                            <p class="text-sm font-bold text-slate-900 leading-none"><?php echo $currentUser['first_name']; ?></p>
                            <p class="text-[10px] font-bold text-slate-400 uppercase mt-1"><?php echo $isHausa ? 'Wakili' : 'Agent'; ?></p>
                        </div>
                        
                        <button class="relative group">
                            <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-primary-600 to-primary-400 p-0.5 shadow-lg shadow-primary-200 transition-transform hover:scale-105 active:scale-95">
                                <div class="w-full h-full rounded-[14px] bg-white flex items-center justify-center font-black text-primary-700">
                                    <?php echo strtoupper(substr($currentUser['first_name'],0,1)); ?>
                                </div>
                            </div>
                        </button>
                    </div>

                </div>
            </div>
        </header>

        <main class="p-6 lg:p-10 animate-[fadeIn_0.4s_ease-out]">