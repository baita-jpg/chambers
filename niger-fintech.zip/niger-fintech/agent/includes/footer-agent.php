</main>
        <footer class="bg-white border-t border-gray-100 py-6 px-8 mt-auto">
            <div class="flex flex-col md:flex-row justify-between items-center text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">
                <p>&copy; 2026 NIGERPAY FINTECH. ALL RIGHTS RESERVED.</p>
                <p>BCEAO LICENSE #NER-AG-2026-004</p>
            </div>
        </footer>
    </div>
    <script>
        document.getElementById('toggleSidebar').addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('sidebar-collapsed');
        });
    </script>
</body>
</html>