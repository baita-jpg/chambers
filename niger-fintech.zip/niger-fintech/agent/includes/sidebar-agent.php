<?php
/**
 * NigerPay - Premium Agent Sidebar
 */
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$currentPath = basename($_SERVER['PHP_SELF']);
$currentUser = getCurrentUser();

// Fetch Agent specific balances
$float = getAccountBalance($currentUser['id'], 'float')['available_balance'] ?? 0;
$comm  = getAccountBalance($currentUser['id'], 'commission')['available_balance'] ?? 0;

function getActiveNav($page, $currentPath) {
    return ($page === $currentPath) 
        ? 'bg-primary-600 text-white shadow-lg shadow-primary-200' 
        : 'text-slate-500 hover:bg-slate-50 hover:text-primary-600';
}
?>
<aside id="sidebar" class="bg-white w-72 flex-shrink-0 hidden lg:flex flex-col border-r border-slate-100 transition-all duration-300 z-30">
    
    <div class="h-24 flex items-center px-8">
        <div class="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center shadow-lg">
            <i class="fas fa-store text-white text-sm"></i>
        </div>
        <span class="ml-3 text-slate-900 font-black text-xl tracking-tighter uppercase">Niger<span class="text-primary-600">Pay</span> <span class="text-[10px] bg-slate-100 px-2 py-0.5 rounded ml-1 text-slate-500">AGENT</span></span>
    </div>

    <div class="px-6 mb-6">
        <div class="bg-slate-900 rounded-3xl p-5 text-white shadow-xl">
            <p class="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Available Float</p>
            <h4 class="text-lg font-black"><?php echo number_format($float); ?> <span class="text-[10px] text-primary-500">XOF</span></h4>
            <div class="mt-4 pt-4 border-t border-white/5 flex justify-between items-center">
                <div>
                    <p class="text-[8px] font-black text-slate-500 uppercase">Commission</p>
                    <p class="text-xs font-bold text-green-400">+<?php echo number_format($comm); ?></p>
                </div>
                <i class="fas fa-chart-line text-slate-700"></i>
            </div>
        </div>
    </div>

    <nav class="flex-1 px-4 space-y-1.5 overflow-y-auto">
        <a href="dashboard.php" class="flex items-center px-4 py-3 rounded-xl transition-all <?php echo getActiveNav('dashboard.php', $currentPath); ?>">
            <i class="fas fa-grid-2 text-sm w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Babban Shafi' : 'Tableau de bord'; ?></span>
        </a>

        <div class="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-4 mt-6 mb-2">Operations</div>

        <a href="cash-in.php" class="flex items-center px-4 py-3 rounded-xl transition-all <?php echo getActiveNav('cash-in.php', $currentPath); ?>">
            <i class="fas fa-money-bill-transfer text-sm w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Saka Kuɗi' : 'Dépôt (Cash-In)'; ?></span>
        </a>

        <a href="withdraw-verify.php" class="flex items-center px-4 py-3 rounded-xl transition-all <?php echo getActiveNav('withdraw-verify.php', $currentPath); ?>">
            <i class="fas fa-money-check-pen text-sm w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Cire Kuɗi' : 'Retrait (Cash-Out)'; ?></span>
        </a>

        <a href="history.php" class="flex items-center px-4 py-3 rounded-xl transition-all <?php echo getActiveNav('history.php', $currentPath); ?>">
            <i class="fas fa-list-check text-sm w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Ayyuka' : 'Historique'; ?></span>
        </a>

        <div class="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-4 mt-6 mb-2">Support</div>
        
        <a href="liquidity-request.php" class="flex items-center px-4 py-3 rounded-xl transition-all <?php echo getActiveNav('liquidity-request.php', $currentPath); ?>">
            <i class="fas fa-plus-minus text-sm w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Nemi Float' : 'Demander Float'; ?></span>
        </a>
    </nav>

    <div class="p-4">
        <a href="../logout.php" class="flex items-center justify-center p-3 bg-red-50 text-red-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-100">
            <i class="fas fa-power-off mr-2"></i> <?php echo $isHausa ? 'Fita' : 'Déconnexion'; ?>
        </a>
    </div>
</aside>