<?php
/**
 * Niger Fintech System - Secure Logout (Fixed)
 */

// Enable error reporting to catch issues
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/auth.php';

// Ensure session is active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    $db = getDB();
    
    if (isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];
        $token = $_SESSION['session_token'] ?? null;

        // Invalidate Database Session
        if ($token) {
            $stmt = $db->prepare("UPDATE user_sessions SET is_active = FALSE WHERE session_token = ?");
            $stmt->execute([$token]);
        }

        // Clean up Remember Me
        $stmt = $db->prepare("DELETE FROM user_remember_me_tokens WHERE user_id = ?");
        $stmt->execute([$userId]);
        
        logActivity('users', $userId, 'LOGOUT');
    }
} catch (Exception $e) {
    // If DB fails, we still want to clear the browser session
    error_log("Logout Error: " . $e->getMessage());
}

// Clear Session Data
$_SESSION = array();
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
}

// Clear Remember Me Cookie
setcookie('remember_me', '', time() - 3600, '/', '', false, true);

session_destroy();

// Redirect with status
header("Location: ./login.php?status=logged_out");
exit;