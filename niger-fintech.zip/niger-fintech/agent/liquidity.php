<?php
/**
 * Niger Fintech System - Agent Float Request
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['agent', 'super_agent'])) {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRFToken($_POST['csrf_token'] ?? '')) {
    $amount = (int)$_POST['amount'];
    $bank = sanitizeInput($_POST['bank_name']);
    $ref = sanitizeInput($_POST['reference']);
    
    // logic to handle file upload would go here
    // For now, we simulate the DB insertion
    $success = $isHausa ? "An aika da buƙatar ku. Jira tantancewa." : "Demande envoyée. En attente de vérification.";
}

$pageTitle = $isHausa ? 'Neman Jari (Float)' : 'Gestion de Liquidité';
include __DIR__ . '/includes/header-agent.php';
?>

<div class="max-w-4xl mx-auto pb-20">
    <div class="mb-8">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $isHausa ? 'Neman Jari' : 'Réapprovisionnement'; ?></h1>
        <p class="text-slate-500 font-medium"><?php echo $isHausa ? 'Tura hoton rasit din banki domin a ƙara maka jari.' : 'Envoyez votre bordereau de dépôt pour créditer votre compte.'; ?></p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div class="lg:col-span-2">
            <?php if($success): ?>
                <div class="bg-green-50 border-2 border-green-100 rounded-3xl p-6 text-center mb-6">
                    <i class="fas fa-paper-plane text-green-500 text-3xl mb-3"></i>
                    <p class="text-green-800 font-bold"><?php echo $success; ?></p>
                </div>
            <?php endif; ?>

            <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-8">
                <form method="POST" enctype="multipart/form-data" class="space-y-6">
                    <?php csrfField(); ?>
                    
                    <div class="space-y-2">
                        <label class="block text-xs font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Yawan Kuɗi' : 'Montant Déposé'; ?></label>
                        <input type="number" name="amount" required class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-black text-2xl">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div class="space-y-2">
                            <label class="block text-xs font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Sunan Banki' : 'Banque'; ?></label>
                            <select name="bank_name" class="w-full px-4 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-bold">
                                <option>BIA Niger</option>
                                <option>SONIBANK</option>
                                <option>BOA</option>
                                <option>Ecobank</option>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-xs font-black text-slate-400 uppercase tracking-widest">Reference #</label>
                            <input type="text" name="reference" placeholder="REF-123..." class="w-full px-4 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-bold">
                        </div>
                    </div>

                    <div class="space-y-2">
                        <label class="block text-xs font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Hoton Rasit' : 'Photo du Bordereau'; ?></label>
                        <label class="flex flex-col items-center justify-center w-full h-40 border-2 border-slate-200 border-dashed rounded-3xl cursor-pointer bg-slate-50 hover:bg-slate-100 transition-all">
                            <i class="fas fa-cloud-upload-alt text-slate-400 text-3xl mb-2"></i>
                            <span class="text-xs font-bold text-slate-500">Click to upload slip</span>
                            <input type="file" name="slip" class="hidden" accept="image/*" />
                        </label>
                    </div>

                    <button type="submit" class="w-full bg-primary-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-primary-100 uppercase tracking-widest">
                        <?php echo $isHausa ? 'AIKA DA BUƘATA' : 'ENVOYER LA DEMANDE'; ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="space-y-6">
            <div class="bg-slate-900 rounded-[2rem] p-6 text-white shadow-xl">
                <h3 class="font-black text-xs uppercase tracking-[0.2em] text-primary-400 mb-4">Instructions</h3>
                <p class="text-xs leading-relaxed text-slate-400">
                    <?php echo $isHausa 
                        ? '1. Je banki ka saka kuɗi.<br>2. Ɗauki hoton rasit ɗin.<br>3. Loda shi anan domin a ƙara maka jari.' 
                        : '1. Effectuez le dépôt à la banque.<br>2. Prenez une photo nette du reçu.<br>3. Téléchargez-la ici pour validation.'; ?>
                </p>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer-agent.php'; ?>