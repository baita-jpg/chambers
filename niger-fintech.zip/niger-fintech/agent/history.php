<?php
/**
 * Niger Fintech System - Agent Transaction History
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['agent', 'super_agent'])) {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$db = getDB();

// Fetch all transactions handled by this agent
$stmt = $db->prepare("
    SELECT t.*, 
           sender.phone_number as s_phone, 
           receiver.phone_number as r_phone
    FROM transactions t
    LEFT JOIN users sender ON t.sender_user_id = sender.id
    LEFT JOIN users receiver ON t.receiver_user_id = receiver.id
    WHERE t.agent_id = ?
    ORDER BY t.created_at DESC LIMIT 50
");
$stmt->execute([$currentUser['id']]);
$transactions = $stmt->fetchAll();

$pageTitle = $isHausa ? 'Tarihin Ma\'amala' : 'Historique des Transactions';
include __DIR__ . '/includes/header-agent.php';
?>

<div class="max-w-6xl mx-auto pb-20">
    <div class="flex justify-between items-end mb-8">
        <div>
            <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $isHausa ? 'Tarihin Kuɗi' : 'Historique'; ?></h1>
            <p class="text-slate-500 font-medium"><?php echo $isHausa ? 'Duba duk ayyukan da ka gudanar.' : 'Consultez vos dernières opérations.'; ?></p>
        </div>
        <div class="flex bg-white p-2 rounded-2xl shadow-sm border border-slate-100">
            <input type="text" placeholder="Search ID..." class="bg-transparent border-none focus:ring-0 text-sm font-bold px-4">
            <button class="bg-slate-900 text-white p-3 rounded-xl"><i class="fas fa-search"></i></button>
        </div>
    </div>

    

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-slate-50/50 border-b border-slate-100">
                    <tr class="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                        <th class="px-8 py-5">Date & ID</th>
                        <th class="px-8 py-5">Type</th>
                        <th class="px-8 py-5">Customer</th>
                        <th class="px-8 py-5 text-right">Amount</th>
                        <th class="px-8 py-5 text-center">Receipt</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php foreach($transactions as $tx): ?>
                    <tr class="hover:bg-slate-50/50 transition-all group">
                        <td class="px-8 py-5">
                            <p class="text-xs font-black text-slate-900"><?php echo date('d M, H:i', strtotime($tx['created_at'])); ?></p>
                            <p class="text-[10px] font-mono text-slate-400 mt-0.5">#<?php echo substr($tx['transaction_id'], 0, 12); ?></p>
                        </td>
                        <td class="px-8 py-5">
                            <?php 
                                $isCashIn = $tx['transaction_type'] === 'cash_in';
                                $color = $isCashIn ? 'text-green-600 bg-green-50' : 'text-red-600 bg-red-50';
                            ?>
                            <span class="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter <?php echo $color; ?>">
                                <?php echo str_replace('_', ' ', $tx['transaction_type']); ?>
                            </span>
                        </td>
                        <td class="px-8 py-5">
                            <p class="text-sm font-bold text-slate-700"><?php echo $tx['r_phone'] ?: $tx['s_phone']; ?></p>
                        </td>
                        <td class="px-8 py-5 text-right font-black text-slate-900">
                            <?php echo number_format($tx['amount'], 0, ',', ' '); ?> <span class="text-[10px] text-slate-400">XOF</span>
                        </td>
                        <td class="px-8 py-5 text-center">
                            <a href="receipt.php?id=<?php echo $tx['transaction_id']; ?>" target="_blank" 
                               class="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-slate-50 text-slate-400 group-hover:bg-primary-600 group-hover:text-white transition-all shadow-sm">
                                <i class="fas fa-file-invoice"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer-agent.php'; ?>