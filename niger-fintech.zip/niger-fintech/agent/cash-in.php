<?php
/**
 * Niger Fintech System - Advanced Cash-In (Deposit)
 */
require_once __DIR__ . '/../includes/auth.php';
requireRole(['agent', 'super_agent']); 
// Allows both standard and super agents

if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['agent', 'super_agent'])) {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Fetch Agent Float Balance for real-time validation
$db = getDB();
$stmt = $db->prepare("SELECT balance FROM wallet_accounts WHERE user_id = ? AND account_type = 'float'");
$stmt->execute([$currentUser['id']]);
$floatBalance = $stmt->fetchColumn() ?: 0;

$pageTitle = $isHausa ? 'Saka Kuɗi (Cash-In)' : 'Dépôt d\'argent (Cash-In)';
include __DIR__ . '/includes/header-agent.php';
?>

<div class="max-w-4xl mx-auto pb-20">
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
            <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $isHausa ? 'Saka Kuɗi' : 'Dépôt Cash-In'; ?></h1>
            <p class="text-slate-500 font-medium"><?php echo $isHausa ? 'Tura kuɗi daga jarin ka zuwa asusun abokin ciniki' : 'Transférer du float vers le compte d\'un client'; ?></p>
        </div>
        <div class="bg-primary-600 px-6 py-3 rounded-2xl shadow-lg shadow-primary-200 text-white">
            <p class="text-[10px] font-black uppercase tracking-widest opacity-80"><?php echo $isHausa ? 'Jarin Ka' : 'Votre Float'; ?></p>
            <p class="text-xl font-black"><?php echo number_format($floatBalance, 0, ',', ' '); ?> <span class="text-xs">XOF</span></p>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div class="lg:col-span-2">
            <div class="bg-white rounded-3xl shadow-soft border border-slate-100 p-8">
                <form id="cashInForm" class="space-y-6">
                    <?php csrfField(); ?>

                    <div class="space-y-2">
                        <label class="block text-xs font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Lambar Wayar Abokin Ciniki' : 'Numéro du Client'; ?></label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 pl-5 flex items-center text-slate-400 font-bold">+227</span>
                            <input type="tel" id="customer_phone" name="phone" required placeholder="90 00 00 00" 
                                   class="w-full pl-16 pr-12 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white focus:ring-0 transition-all font-bold text-xl tracking-wider">
                            <div id="verifySpinner" class="hidden absolute inset-y-0 right-0 pr-4 flex items-center">
                                <i class="fas fa-circle-notch fa-spin text-primary-500"></i>
                            </div>
                        </div>
                        <div id="customerPreview" class="hidden animate-[fadeIn_0.3s_ease-out] flex items-center p-3 bg-green-50 border border-green-100 rounded-xl">
                            <div class="w-8 h-8 bg-green-500 text-white rounded-lg flex items-center justify-center text-xs mr-3"><i class="fas fa-user-check"></i></div>
                            <span id="customerName" class="text-sm font-bold text-green-700 uppercase tracking-tight">---</span>
                        </div>
                    </div>

                    <div class="space-y-4">
                        <div class="space-y-2">
                            <label class="block text-xs font-black text-slate-400 uppercase tracking-widest"><?php echo $isHausa ? 'Yawan Kuɗi' : 'Montant à déposer'; ?></label>
                            <div class="relative">
                                <input type="number" id="amount" name="amount" required placeholder="0" 
                                       class="w-full px-6 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white focus:ring-0 transition-all font-black text-3xl">
                                <span class="absolute inset-y-0 right-0 pr-6 flex items-center text-slate-400 font-black">XOF</span>
                            </div>
                        </div>

                        <div class="grid grid-cols-4 gap-2">
                            <?php foreach([1000, 2000, 5000, 10000] as $preset): ?>
                                <button type="button" onclick="setAmount(<?php echo $preset; ?>)" 
                                        class="py-2 bg-slate-50 hover:bg-primary-50 hover:text-primary-600 border border-slate-100 rounded-xl text-xs font-bold text-slate-500 transition-all">
                                    +<?php echo number_format($preset/1000, 0); ?>k
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <button type="button" onclick="openConfirmation()" id="reviewBtn"
                            class="w-full bg-slate-900 hover:bg-black text-white font-black py-5 rounded-2xl shadow-xl transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center space-x-2">
                        <span><?php echo $isHausa ? 'DUBA MA\'AMALA' : 'VÉRIFIER LE DÉPÔT'; ?></span>
                        <i class="fas fa-chevron-right text-xs opacity-50"></i>
                    </button>
                </form>
            </div>
        </div>

        <div class="space-y-6">
            <div class="bg-indigo-900 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
                <div class="absolute -right-4 -bottom-4 opacity-10"><i class="fas fa-shield-halved text-8xl"></i></div>
                <h3 class="font-black text-sm uppercase tracking-widest mb-4 flex items-center">
                    <i class="fas fa-fingerprint mr-2 text-indigo-400"></i> <?php echo $isHausa ? 'Tsaro' : 'Sécurité'; ?>
                </h3>
                <ul class="space-y-4 text-xs font-bold text-indigo-100">
                    <li class="flex items-start"><i class="fas fa-check-circle text-green-400 mt-0.5 mr-2"></i> <?php echo $isHausa ? 'Tabbatar da sunan abokin ciniki kafin turawa.' : 'Vérifiez le nom du client avant de valider.'; ?></li>
                    <li class="flex items-start"><i class="fas fa-check-circle text-green-400 mt-0.5 mr-2"></i> <?php echo $isHausa ? 'Kada ka bada tsabar kuɗi har sai tsarin ya ce "Success".' : 'Ne remettez pas de reçu avant la confirmation.'; ?></li>
                </ul>
            </div>
            
            <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-soft">
                <h4 class="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3"><?php echo $isHausa ? 'Taimako' : 'Support'; ?></h4>
                <p class="text-xs text-slate-600 leading-relaxed font-medium">
                    <?php echo $isHausa ? 'Idan kuskure ya faru, tuntuɓi babban ofis nan take domin yin "Reversal".' : 'En cas d\'erreur, contactez le support immédiatement pour un remboursement.'; ?>
                </p>
            </div>
        </div>
    </div>
</div>

<div id="confirmModal" class="hidden fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
    <div class="bg-white rounded-[40px] shadow-2xl max-w-sm w-full p-10 text-center animate-[pop_0.3s_ease-out]">
        <div class="w-20 h-20 bg-primary-100 text-primary-600 rounded-3xl flex items-center justify-center text-3xl mx-auto mb-6 shadow-inner">
            <i class="fas fa-paper-plane"></i>
        </div>
        <h3 class="text-2xl font-black text-slate-900 mb-2"><?php echo $isHausa ? 'Tabbatar da Saka Kuɗi' : 'Confirmer le Dépôt'; ?></h3>
        <p class="text-slate-500 text-sm font-medium mb-8"><?php echo $isHausa ? 'Shin kana son tura wannan adadin?' : 'Voulez-vous confirmer cette transaction ?'; ?></p>
        
        <div class="bg-slate-50 rounded-3xl p-6 mb-8 space-y-3">
            <div class="flex justify-between text-xs font-bold uppercase tracking-widest text-slate-400">
                <span>Total Amount</span>
                <span id="confirmAmount" class="text-slate-900 text-lg font-black">0 XOF</span>
            </div>
            <div class="flex justify-between text-xs font-bold uppercase tracking-widest text-slate-400 border-t border-slate-200 pt-3">
                <span>Receiver</span>
                <span id="confirmPhone" class="text-primary-600">---</span>
            </div>
        </div>

        <div class="flex flex-col gap-3">
            <button onclick="submitCashIn()" class="w-full bg-primary-600 text-white font-black py-4 rounded-2xl shadow-lg shadow-primary-200">
                <?php echo $isHausa ? 'HAKAN NE, TURA' : 'OUI, ENVOYER'; ?>
            </button>
            <button onclick="closeModal()" class="text-slate-400 text-xs font-black uppercase tracking-widest py-2">
                <?php echo $isHausa ? 'Soke' : 'Annuler'; ?>
            </button>
        </div>
    </div>
</div>

<script>
function setAmount(val) {
    document.getElementById('amount').value = val;
}

function closeModal() {
    document.getElementById('confirmModal').classList.add('hidden');
}

function openConfirmation() {
    const phone = document.getElementById('customer_phone').value;
    const amount = document.getElementById('amount').value;
    
    if(!phone || !amount) {
        alert("Please fill all fields");
        return;
    }
    
    document.getElementById('confirmAmount').innerText = new Intl.NumberFormat('fr-FR').format(amount) + ' XOF';
    document.getElementById('confirmPhone').innerText = '+227 ' + phone;
    document.getElementById('confirmModal').classList.remove('hidden');
}

// Logic for Real-time Verification
document.getElementById('customer_phone').addEventListener('input', function(e) {
    const val = e.target.value.replace(/\s/g, '');
    if (val.length === 8) {
        document.getElementById('verifySpinner').classList.remove('hidden');
        // Simulated AJAX delay
        setTimeout(() => {
            document.getElementById('verifySpinner').classList.add('hidden');
            document.getElementById('customerPreview').classList.remove('hidden');
            document.getElementById('customerName').innerText = "Moussa Ibrahim"; // Mocked
        }, 800);
    } else {
        document.getElementById('customerPreview').classList.add('hidden');
    }
});

function submitCashIn() {
    // Here you would trigger an actual fetch() to your backend transaction-processor
    alert("Transaction Processed Successfully!");
    window.location.href = 'dashboard.php';
}
</script>

<?php include __DIR__ . '/includes/footer-agent.php'; ?>