<?php
/**
 * NigerPay - High-Density Bulk Print with Fraud Detection
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'admin') { die("Unauthorized."); }

$db = getDB();
$agentId = $_GET['agent_id'] ?? 'all';
$reportDate = $_GET['report_date'] ?? date('Y-m-d');

// Fetch the fraud threshold from system_config (default to 500,000 if not set)
$fraudThreshold = (float)getConfig('fraud_alert_limit', 500000);

// SQL Logic... (Same as previous)
// [Data fetching logic remains the same]
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        /* Existing styles... */
        .fraud-alert { background-color: #fee2e2 !important; color: #b91c1c !important; }
        .fraud-tag { font-size: 8px; font-weight: black; background: #b91c1c; color: #fff; padding: 2px 4px; border-radius: 3px; margin-left: 5px; }
        @media print { .fraud-alert { -webkit-print-color-adjust: exact; } }
    </style>
</head>
<body onload="window.print()">
    <table>
        <thead>
            <tr>
                <th>Time</th>
                <th>Transaction ID</th>
                <th>Type</th>
                <th>Agent / Branch</th>
                <th>Customer</th>
                <th>Amount (XOF)</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $totalVolume = 0;
            $flaggedCount = 0;
            foreach($results as $row): 
                $totalVolume += $row['amount'];
                $isSuspicious = ($row['amount'] >= $fraudThreshold);
                if($isSuspicious) $flaggedCount++;
            ?>
            <tr class="<?php echo $isSuspicious ? 'fraud-alert' : ''; ?>">
                <td><?php echo date('H:i:s', strtotime($row['created_at'])); ?></td>
                <td style="font-family: monospace;">
                    <?php echo $row['transaction_id']; ?>
                </td>
                <td style="font-weight: bold;"><?php echo strtoupper($row['transaction_type']); ?></td>
                <td><?php echo $row['agent_name']; ?> (<?php echo $row['agent_code']; ?>)</td>
                <td><?php echo $row['cust_name'] ?: 'N/A'; ?></td>
                <td class="amount">
                    <?php echo number_format($row['amount']); ?>
                    <?php if($isSuspicious): ?>
                        <span class="fraud-tag">HIGH VALUE</span>
                    <?php endif; ?>
                </td>
                <td style="font-weight: bold;"><?php echo strtoupper($row['status']); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="footer">
        <div style="margin-bottom: 5px;">TOTAL TRANSACTIONS: <?php echo count($results); ?></div>
        <div style="color: #b91c1c; margin-bottom: 5px;">FLAGGED FOR REVIEW: <?php echo $flaggedCount; ?></div>
        <div style="font-size: 16px;">TOTAL VOLUME: <?php echo number_format($totalVolume); ?> XOF</div>
    </div>
    
    </body>
</html>