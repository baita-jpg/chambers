<?php
/**
 * Niger Fintech System - Advanced Cash-Out (Withdrawal)
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['agent', 'super_agent'])) {
    header('Location: /login.php'); exit;
}

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Fetch current fee configuration from system_config (e.g., 1.5%)

$db = getDB();
// New dynamic way:
$feePercent = getConfig('cash_out_fee_percent', 1.5);

$pageTitle = $isHausa ? 'Cire Kuɗi (Cash-Out)' : 'Retrait d\'argent (Cash-Out)';
include __DIR__ . '/includes/header-agent.php';
?>

<div class="max-w-4xl mx-auto pb-20">
    <div class="mb-8">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $isHausa ? 'Cire Kuɗi' : 'Retrait Cash-Out'; ?></h1>
        <p class="text-slate-500 font-medium"><?php echo $isHausa ? 'Karɓi kuɗi daga asusun abokin ciniki ka ba shi tsaba' : 'Débiter le client pour lui remettre des espèces'; ?></p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div class="lg:col-span-2">
            <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-8 md:p-10">
                <form id="cashOutForm" class="space-y-8">
                    <?php csrfField(); ?>

                    <div class="space-y-4">
                        <label class="block text-xs font-black text-slate-400 uppercase tracking-[0.2em]"><?php echo $isHausa ? 'Lambar Wayar Abokin Ciniki' : 'Identification du Client'; ?></label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 pl-5 flex items-center text-slate-400 font-bold">+227</span>
                            <input type="tel" id="cust_phone" required placeholder="90 00 00 00" 
                                   class="w-full pl-16 pr-12 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-red-500 focus:bg-white focus:ring-0 transition-all font-bold text-xl tracking-wider">
                        </div>
                    </div>

                    <div class="space-y-4">
                        <div class="flex justify-between items-end">
                            <label class="block text-xs font-black text-slate-400 uppercase tracking-[0.2em]"><?php echo $isHausa ? 'Yawan Kuɗi' : 'Montant du retrait'; ?></label>
                            <span class="text-[10px] font-bold text-red-500 bg-red-50 px-2 py-1 rounded-md uppercase tracking-tighter">
                                Fees: <?php echo $feePercent; ?>%
                            </span>
                        </div>
                        
                        <div class="relative">
                            <input type="number" id="cash_amount" oninput="calculateTotal()" required placeholder="0" 
                                   class="w-full px-6 py-5 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-red-500 focus:bg-white focus:ring-0 transition-all font-black text-4xl">
                            <span class="absolute inset-y-0 right-0 pr-6 flex items-center text-slate-400 font-black">XOF</span>
                        </div>

                        
                        <div class="bg-slate-50 rounded-2xl p-5 space-y-2 border border-slate-100">
                            <div class="flex justify-between text-sm font-medium text-slate-500">
                                <span><?php echo $isHausa ? 'Kuɗin Sabis' : 'Frais de service'; ?></span>
                                <span id="fee_display">0 XOF</span>
                            </div>
                            <div class="flex justify-between text-lg font-black text-slate-900 pt-2 border-t border-slate-200">
                                <span><?php echo $isHausa ? 'Jimillar da za a cire' : 'Total à déduire'; ?></span>
                                <span id="total_deduct">0 XOF</span>
                            </div>
                        </div>
                    </div>

                    <div class="space-y-4">
                        <label class="block text-xs font-black text-slate-400 uppercase tracking-[0.2em]"><?php echo $isHausa ? 'Lambar Sirri (Token)' : 'Code de Retrait (OTP)'; ?></label>
                        <div class="flex gap-3">
                            <?php for($i=0; $i<6; $i++): ?>
                                <input type="text" maxlength="1" 
                                       class="otp-input w-full h-14 text-center bg-slate-50 border-2 border-slate-50 rounded-xl focus:border-red-500 focus:bg-white focus:ring-0 transition-all font-black text-2xl">
                            <?php endfor; ?>
                        </div>
                        <p class="text-[10px] text-gray-400 font-bold italic"><?php echo $isHausa ? 'Abokin ciniki zai sami wannan lambar ta SMS' : 'Le client doit vous donner le code reçu par SMS'; ?></p>
                    </div>

                    <button type="button" onclick="confirmCashOut()" 
                            class="w-full bg-red-600 hover:bg-red-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-red-100 transition-all transform hover:scale-[1.01] active:scale-[0.98] flex items-center justify-center space-x-3 uppercase">
                        <i class="fas fa-hand-holding-dollar text-xl"></i>
                        <span><?php echo $isHausa ? 'BAYAR DA TSABAR KUƊI' : 'VALIDER LE RETRAIT'; ?></span>
                    </button>
                </form>
            </div>
        </div>

        <div class="space-y-6">
            <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-soft">
                <h3 class="font-black text-sm uppercase tracking-widest text-slate-900 mb-4"><?php echo $isHausa ? 'Tsanaki' : 'Sécurité Retrait'; ?></h3>
                <div class="space-y-4">
                    <div class="flex items-start">
                        <div class="w-8 h-8 bg-red-50 text-red-500 rounded-lg flex items-center justify-center shrink-0 mr-3"><i class="fas fa-eye"></i></div>
                        <p class="text-xs font-medium text-slate-600 leading-relaxed"><?php echo $isHausa ? 'Tabbatar kana da isassun tsabar kuɗi kafin ka cire daga asusunsa.' : 'Assurez-vous d\'avoir les espèces en main avant de valider.'; ?></p>
                    </div>
                    <div class="flex items-start">
                        <div class="w-8 h-8 bg-red-50 text-red-500 rounded-lg flex items-center justify-center shrink-0 mr-3"><i class="fas fa-lock"></i></div>
                        <p class="text-xs font-medium text-slate-600 leading-relaxed"><?php echo $isHausa ? 'Kada ka taba raba lambar sirrin abokin ciniki.' : 'Ne partagez jamais le code secret du client avec un tiers.'; ?></p>
                    </div>
                </div>
            </div>

            
            <div class="bg-slate-900 rounded-3xl p-6 text-white shadow-xl">
                <h4 class="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Cashier Assistant</h4>
                <div id="denom_helper" class="space-y-2 opacity-60">
                    <p class="text-[10px] font-bold italic">Enter amount to see required notes...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const feeRate = <?php echo $feePercent / 100; ?>;

function calculateTotal() {
    const amount = parseFloat(document.getElementById('cash_amount').value) || 0;
    const fee = Math.ceil(amount * feeRate);
    const total = amount + fee;

    document.getElementById('fee_display').innerText = new Intl.NumberFormat('fr-FR').format(fee) + ' XOF';
    document.getElementById('total_deduct').innerText = new Intl.NumberFormat('fr-FR').format(total) + ' XOF';
    
    updateDenominations(amount);
}

function updateDenominations(amount) {
    const helper = document.getElementById('denom_helper');
    if (amount <= 0) {
        helper.innerHTML = '<p class="text-[10px] font-bold italic">Enter amount to see required notes...</p>';
        return;
    }

    const denoms = [10000, 5000, 2000, 1000];
    let remaining = amount;
    let html = '<div class="space-y-1">';
    
    denoms.forEach(d => {
        let count = Math.floor(remaining / d);
        if(count > 0) {
            html += `<div class="flex justify-between text-xs font-bold">
                        <span class="text-slate-400">${d.toLocaleString()} XOF</span>
                        <span class="text-primary-400">x${count}</span>
                     </div>`;
        }
        remaining %= d;
    });
    
    if(remaining > 0) html += `<div class="text-[10px] text-yellow-400 pt-1">+ ${remaining} XOF (Coins)</div>`;
    html += '</div>';
    helper.innerHTML = html;
    helper.classList.remove('opacity-60');
}

// Auto-focus logic for OTP inputs
const inputs = document.querySelectorAll('.otp-input');
inputs.forEach((input, index) => {
    input.addEventListener('input', (e) => {
        if (e.target.value.length === 1 && index < inputs.length - 1) {
            inputs[index + 1].focus();
        }
    });
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && index > 0 && e.target.value.length === 0) {
            inputs[index - 1].focus();
        }
    });
});

function confirmCashOut() {
    const amount = document.getElementById('cash_amount').value;
    if(!amount || amount < 100) {
        alert("Minimum withdrawal is 100 XOF");
        return;
    }
    // Final logic would be an AJAX call here
    alert("Withdrawal Successful! You can now hand over the cash.");
    window.location.href = 'dashboard.php';
}
</script>

<?php include __DIR__ . '/includes/footer-agent.php'; ?>