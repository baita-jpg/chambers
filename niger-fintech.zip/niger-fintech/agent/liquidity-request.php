<?php
/**
 * NigerPay - Agent Float/Liquidity Request
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

if (!isLoggedIn()) { header('Location: /login.php'); exit; }

$currentUser = getCurrentUser();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRFToken($_POST['csrf_token'] ?? '')) {
    $amount = (float)$_POST['amount'];
    $method = sanitizeInput($_POST['payment_method']);
    
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO liquidity_movements (agent_id, amount, method, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
    $stmt->execute([$currentUser['id'], $amount, $method]);
    
    $message = $isHausa ? "An tura bukatar ku. Tuntuɓi Admin don amincewa." : "Demande envoyée. Contactez l'admin pour validation.";
}

include __DIR__ . '/includes/header-agent.php';
?>

<div class="max-w-md mx-auto pb-20">
    <div class="mb-8 px-4">
        <h1 class="text-2xl font-black text-slate-900"><?php echo $isHausa ? 'Nemi Float' : 'Réapprovisionnement'; ?></h1>
        <p class="text-slate-500 text-sm"><?php echo $isHausa ? 'Saka adadin kuɗin da kake bukata' : 'Demandez du crédit float à l\'administration'; ?></p>
    </div>

    <div class="bg-white rounded-[2.5rem] p-8 shadow-soft border border-slate-100">
        <?php if($message): ?>
            <div class="mb-6 p-4 bg-green-50 text-green-700 rounded-2xl font-bold text-xs flex items-center">
                <i class="fas fa-check-circle mr-2"></i> <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <?php csrfField(); ?>
            
            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Montant (XOF)</label>
                <input type="number" name="amount" placeholder="500000" required 
                       class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-black text-xl focus:border-primary-500 transition-all">
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Hanyar Biya (Méthode)</label>
                <select name="payment_method" class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-bold">
                    <option value="cash">Cash to Office</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="check">Chèque</option>
                </select>
            </div>

            <button type="submit" class="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-xl transition-all active:scale-95">
                <?php echo $isHausa ? 'AIKA DA BUKATA' : 'ENVOYER LA DEMANDE'; ?>
            </button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer-agent.php'; ?>