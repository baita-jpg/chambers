<?php
/**
 * NigerPay - Thermal Receipt Generator
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

$txId = $_GET['id'] ?? null;
$db = getDB();
$stmt = $db->prepare("
    SELECT t.*, u.first_name as customer_name, u.phone_number as customer_phone,
           a.first_name as agent_name, ad.agent_code
    FROM transactions t
    LEFT JOIN users u ON t.sender_user_id = u.id
    LEFT JOIN users a ON t.agent_id = a.id
    LEFT JOIN agent_details ad ON a.id = ad.user_id
    WHERE t.transaction_id = ?
");
$stmt->execute([$txId]);
$tx = $stmt->fetch();

if (!$tx) { die("Transaction introuvable."); }

$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Receipt_<?php echo $txId; ?></title>
    <style>
        @media print { @page { margin: 0; } body { margin: 0.5cm; } }
        body { 
            font-family: 'Courier New', Courier, monospace; 
            width: 300px; /* Standard 58mm width */
            font-size: 12px;
            color: #000;
        }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        .line { border-top: 1px dashed #000; margin: 10px 0; }
        .flex { display: flex; justify-content: space-between; }
        .qr-placeholder { background: #eee; width: 100px; height: 100px; margin: 10px auto; }
        button { background: #000; color: #fff; padding: 10px; width: 100%; border: none; margin-top: 20px; cursor: pointer; }
        @media print { button { display: none; } }
    </style>
</head>
<body onload="window.print()">

    <div class="center">
        <h2 style="margin-bottom: 5px;">NIGERPAY</h2>
        <p><?php echo $isHausa ? 'RASIT DIN MA\'AMALA' : 'REÇU DE TRANSACTION'; ?></p>
        <p class="bold"><?php echo strtoupper($tx['transaction_type']); ?></p>
    </div>

    <div class="line"></div>

    <div class="flex">
        <span>ID:</span>
        <span class="bold"><?php echo $tx['transaction_id']; ?></span>
    </div>
    <div class="flex">
        <span>Date:</span>
        <span><?php echo date('d/m/Y H:i', strtotime($tx['created_at'])); ?></span>
    </div>
    
    <div class="line"></div>

    <div class="flex">
        <span><?php echo $isHausa ? 'Abokin Ciniki' : 'Client'; ?>:</span>
        <span><?php echo $tx['customer_name']; ?></span>
    </div>
    <div class="flex">
        <span>Tel:</span>
        <span><?php echo $tx['customer_phone']; ?></span>
    </div>

    <div class="line"></div>

    <div class="center" style="font-size: 18px; margin: 10px 0;">
        <span class="bold"><?php echo number_format($tx['amount']); ?> XOF</span>
    </div>

    <div class="line"></div>

    <div class="flex">
        <span><?php echo $isHausa ? 'Wakili' : 'Agent'; ?>:</span>
        <span><?php echo $tx['agent_name']; ?> (<?php echo $tx['agent_code']; ?>)</span>
    </div>

    <div class="line"></div>

    
    <div class="center">
        <p style="font-size: 9px;"><?php echo $isHausa ? 'Lambar tabbatarwa' : 'Scannez pour vérifier'; ?></p>
        <div class="qr-placeholder">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=<?php echo $tx['transaction_id']; ?>" alt="QR">
        </div>
        <p class="bold">MERCI / MUN GODE</p>
    </div>

    <button onclick="window.print()"><?php echo $isHausa ? 'Buga Rasit' : 'Imprimer le reçu'; ?></button>

</body>
</html>