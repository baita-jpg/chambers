<?php
/**
 * Niger Fintech System - External Integrations
 * 
 * Integration Layer for:
 * - Orange Money
 * - Airtel Money
 * - Moov Money
 * - GIM-UEMOA (Interbank switch)
 * - SMS Gateways
 */

require_once __DIR__ . '/functions.php';

// =====================================================
// ORANGE MONEY INTEGRATION
// =====================================================

/**
 * Orange Money API Client
 */
class OrangeMoneyAPI {
    private $baseUrl;
    private $clientId;
    private $clientSecret;
    private $merchantId;
    private $accessToken;
    
    public function __construct() {
        // Load configuration from environment or database
        $this->baseUrl = $_ENV['ORANGE_MONEY_URL'] ?? 'https://api.orange.com/orange-money-webpay/dev/v1';
        $this->clientId = $_ENV['ORANGE_MONEY_CLIENT_ID'] ?? '';
        $this->clientSecret = $_ENV['ORANGE_MONEY_CLIENT_SECRET'] ?? '';
        $this->merchantId = $_ENV['ORANGE_MONEY_MERCHANT_ID'] ?? '';
    }
    
    /**
     * Get access token
     * @return string|null Access token
     */
    private function getAccessToken() {
        if ($this->accessToken) {
            return $this->accessToken;
        }
        
        $url = 'https://api.orange.com/oauth/v3/token';
        $credentials = base64_encode($this->clientId . ':' . $this->clientSecret);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Basic ' . $credentials,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        $this->accessToken = $data['access_token'] ?? null;
        
        return $this->accessToken;
    }
    
    /**
     * Initiate payment
     * @param array $params Payment parameters
     * @return array Result
     */
    public function initiatePayment($params) {
        $token = $this->getAccessToken();
        
        if (!$token) {
            return ['success' => false, 'message' => 'Failed to authenticate with Orange Money'];
        }
        
        $url = $this->baseUrl . '/payment';
        
        $payload = [
            'merchant_key' => $this->merchantId,
            'currency' => 'OUV',
            'order_id' => $params['order_id'],
            'amount' => $params['amount'],
            'return_url' => $params['return_url'],
            'cancel_url' => $params['cancel_url'],
            'notif_url' => $params['notif_url'],
            'lang' => 'fr',
            'reference' => $params['reference']
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        if (isset($data['payment_url'])) {
            return [
                'success' => true,
                'payment_url' => $data['payment_url'],
                'payment_token' => $data['payment_token'],
                'order_id' => $params['order_id']
            ];
        }
        
        return [
            'success' => false,
            'message' => $data['message'] ?? 'Payment initiation failed',
            'error' => $data
        ];
    }
    
    /**
     * Check transaction status
     * @param string $orderId Order ID
     * @param string $paymentToken Payment token
     * @return array Status
     */
    public function checkStatus($orderId, $paymentToken) {
        $token = $this->getAccessToken();
        
        if (!$token) {
            return ['success' => false, 'message' => 'Authentication failed'];
        }
        
        $url = $this->baseUrl . '/payment/status/' . $orderId;
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        return [
            'success' => true,
            'status' => $data['status'] ?? 'unknown',
            'data' => $data
        ];
    }
}

// =====================================================
// AIRTEL MONEY INTEGRATION
// =====================================================

/**
 * Airtel Money API Client
 */
class AirtelMoneyAPI {
    private $baseUrl;
    private $clientId;
    private $clientSecret;
    private $accessToken;
    
    public function __construct() {
        $this->baseUrl = $_ENV['AIRTEL_MONEY_URL'] ?? 'https://openapi.airtel.africa';
        $this->clientId = $_ENV['AIRTEL_MONEY_CLIENT_ID'] ?? '';
        $this->clientSecret = $_ENV['AIRTEL_MONEY_CLIENT_SECRET'] ?? '';
    }
    
    /**
     * Get access token
     * @return string|null Access token
     */
    private function getAccessToken() {
        if ($this->accessToken) {
            return $this->accessToken;
        }
        
        $url = $this->baseUrl . '/auth/oauth2/token';
        
        $payload = [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'grant_type' => 'client_credentials'
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        $this->accessToken = $data['access_token'] ?? null;
        
        return $this->accessToken;
    }
    
    /**
     * Collect money from customer
     * @param array $params Collection parameters
     * @return array Result
     */
    public function collect($params) {
        $token = $this->getAccessToken();
        
        if (!$token) {
            return ['success' => false, 'message' => 'Authentication failed'];
        }
        
        $url = $this->baseUrl . '/merchant/v1/payments/';
        
        $payload = [
            'reference' => $params['reference'],
            'subscriber' => [
                'country' => 'NE',
                'currency' => 'XOF',
                'msisdn' => $params['phone']
            ],
            'transaction' => [
                'amount' => $params['amount'],
                'country' => 'NE',
                'currency' => 'XOF',
                'id' => $params['transaction_id']
            ]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'X-Country: NE',
            'X-Currency: XOF'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        if (isset($data['status']) && $data['status'] === 'SUCCESS') {
            return [
                'success' => true,
                'transaction_id' => $data['transaction']['id'],
                'status' => $data['transaction']['status']
            ];
        }
        
        return [
            'success' => false,
            'message' => $data['errorMessage'] ?? 'Collection failed',
            'data' => $data
        ];
    }
    
    /**
     * Transfer money to customer
     * @param array $params Transfer parameters
     * @return array Result
     */
    public function transfer($params) {
        $token = $this->getAccessToken();
        
        if (!$token) {
            return ['success' => false, 'message' => 'Authentication failed'];
        }
        
        $url = $this->baseUrl . '/standard/v1/disbursements/';
        
        $payload = [
            'payee' => [
                'msisdn' => $params['phone']
            ],
            'reference' => $params['reference'],
            'pin' => $params['pin'],
            'transaction' => [
                'amount' => $params['amount'],
                'id' => $params['transaction_id']
            ]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
            'X-Country: NE',
            'X-Currency: XOF'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        if (isset($data['status']) && $data['status'] === 'SUCCESS') {
            return [
                'success' => true,
                'transaction_id' => $data['transaction']['id'],
                'status' => $data['transaction']['status']
            ];
        }
        
        return [
            'success' => false,
            'message' => $data['errorMessage'] ?? 'Transfer failed',
            'data' => $data
        ];
    }
}

// =====================================================
// GIM-UEMOA INTEGRATION (Interbank)
// =====================================================

/**
 * GIM-UEMOA API Client
 */
class GIMUEMOA_API {
    private $baseUrl;
    private $apiKey;
    private $apiSecret;
    
    public function __construct() {
        $this->baseUrl = $_ENV['GIM_UEMOA_URL'] ?? 'https://api.gim-uemoa.org/v1';
        $this->apiKey = $_ENV['GIM_UEMOA_API_KEY'] ?? '';
        $this->apiSecret = $_ENV['GIM_UEMOA_API_SECRET'] ?? '';
    }
    
    /**
     * Generate API signature
     * @param string $payload Request payload
     * @param string $timestamp Timestamp
     * @return string Signature
     */
    private function generateSignature($payload, $timestamp) {
        return hash_hmac('sha256', $payload . $timestamp, $this->apiSecret);
    }
    
    /**
     * Initiate interbank transfer
     * @param array $params Transfer parameters
     * @return array Result
     */
    public function initiateTransfer($params) {
        $url = $this->baseUrl . '/transfers';
        $timestamp = time();
        
        $payload = [
            'reference' => $params['reference'],
            'amount' => $params['amount'],
            'currency' => 'XOF',
            'sender_account' => $params['sender_account'],
            'receiver_account' => $params['receiver_account'],
            'receiver_bank_code' => $params['receiver_bank_code'],
            'description' => $params['description'],
            'timestamp' => $timestamp
        ];
        
        $signature = $this->generateSignature(json_encode($payload), $timestamp);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->apiKey,
            'X-Signature: ' . $signature,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        if (isset($data['transaction_id'])) {
            return [
                'success' => true,
                'transaction_id' => $data['transaction_id'],
                'status' => $data['status']
            ];
        }
        
        return [
            'success' => false,
            'message' => $data['error'] ?? 'Transfer initiation failed',
            'data' => $data
        ];
    }
    
    /**
     * Check transfer status
     * @param string $transactionId Transaction ID
     * @return array Status
     */
    public function checkTransferStatus($transactionId) {
        $url = $this->baseUrl . '/transfers/' . $transactionId;
        $timestamp = time();
        
        $signature = $this->generateSignature($transactionId, $timestamp);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->apiKey,
            'X-Signature: ' . $signature,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        return [
            'success' => true,
            'status' => $data['status'] ?? 'unknown',
            'data' => $data
        ];
    }
    
    /**
     * Get bank list
     * @return array List of banks
     */
    public function getBankList() {
        $url = $this->baseUrl . '/banks';
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        return $data['banks'] ?? [];
    }
}

// =====================================================
// SMS GATEWAY INTEGRATION
// =====================================================

/**
 * SMS Gateway for notifications
 */
class SMSGateway {
    private $provider;
    private $config;
    
    public function __construct($provider = null) {
        $this->provider = $provider ?? getConfig('sms_provider', 'twilio');
        $this->loadConfig();
    }
    
    /**
     * Load provider configuration
     */
    private function loadConfig() {
        $this->config = [
            'twilio' => [
                'account_sid' => $_ENV['TWILIO_ACCOUNT_SID'] ?? '',
                'auth_token' => $_ENV['TWILIO_AUTH_TOKEN'] ?? '',
                'from_number' => $_ENV['TWILIO_FROM_NUMBER'] ?? ''
            ],
            'africas_talking' => [
                'username' => $_ENV['AT_USERNAME'] ?? '',
                'api_key' => $_ENV['AT_API_KEY'] ?? '',
                'from' => $_ENV['AT_FROM'] ?? ''
            ],
            'orange_sms' => [
                'client_id' => $_ENV['ORANGE_SMS_CLIENT_ID'] ?? '',
                'client_secret' => $_ENV['ORANGE_SMS_CLIENT_SECRET'] ?? ''
            ]
        ];
    }
    
    /**
     * Send SMS
     * @param string $to Phone number
     * @param string $message Message text
     * @return array Result
     */
    public function send($to, $message) {
        switch ($this->provider) {
            case 'twilio':
                return $this->sendTwilio($to, $message);
            case 'africas_talking':
                return $this->sendAfricaTalking($to, $message);
            case 'orange_sms':
                return $this->sendOrangeSMS($to, $message);
            default:
                return ['success' => false, 'message' => 'Unknown SMS provider'];
        }
    }
    
    /**
     * Send via Twilio
     */
    private function sendTwilio($to, $message) {
        $url = 'https://api.twilio.com/2010-04-01/Accounts/' . $this->config['twilio']['account_sid'] . '/Messages.json';
        
        $data = [
            'To' => $to,
            'From' => $this->config['twilio']['from_number'],
            'Body' => $message
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_USERPWD, $this->config['twilio']['account_sid'] . ':' . $this->config['twilio']['auth_token']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 201) {
            $data = json_decode($response, true);
            return [
                'success' => true,
                'message_id' => $data['sid']
            ];
        }
        
        return [
            'success' => false,
            'message' => 'SMS sending failed',
            'error' => json_decode($response, true)
        ];
    }
    
    /**
     * Send via Africa's Talking
     */
    private function sendAfricaTalking($to, $message) {
        $url = 'https://api.africastalking.com/version1/messaging';
        
        $data = [
            'username' => $this->config['africas_talking']['username'],
            'to' => $to,
            'message' => $message,
            'from' => $this->config['africas_talking']['from']
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'apikey: ' . $this->config['africas_talking']['api_key']
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $data = json_decode($response, true);
        
        if (isset($data['SMSMessageData']['Recipients'][0]['status']) && 
            $data['SMSMessageData']['Recipients'][0]['status'] === 'Success') {
            return [
                'success' => true,
                'message_id' => $data['SMSMessageData']['Recipients'][0]['messageId']
            ];
        }
        
        return [
            'success' => false,
            'message' => 'SMS sending failed',
            'error' => $data
        ];
    }
    
    /**
     * Send via Orange SMS API
     */
    private function sendOrangeSMS($to, $message) {
        // First get access token
        $tokenUrl = 'https://api.orange.com/oauth/v3/token';
        $credentials = base64_encode($this->config['orange_sms']['client_id'] . ':' . $this->config['orange_sms']['client_secret']);
        
        $ch = curl_init($tokenUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Basic ' . $credentials,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $tokenResponse = curl_exec($ch);
        curl_close($ch);
        
        $tokenData = json_decode($tokenResponse, true);
        $accessToken = $tokenData['access_token'] ?? null;
        
        if (!$accessToken) {
            return ['success' => false, 'message' => 'Failed to get access token'];
        }
        
        // Send SMS
        $url = 'https://api.orange.com/smsmessaging/v1/outbound/tel%3A%2B' . $this->config['orange_sms']['from'] . '/requests';
        
        $payload = [
            'outboundSMSMessageRequest' => [
                'address' => ['tel:+' . $to],
                'senderAddress' => 'tel:+' . $this->config['orange_sms']['from'],
                'outboundSMSTextMessage' => [
                    'message' => $message
                ]
            ]
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 201) {
            return ['success' => true];
        }
        
        return [
            'success' => false,
            'message' => 'SMS sending failed',
            'error' => json_decode($response, true)
        ];
    }
}

// =====================================================
// USSD SIMULATION
// =====================================================

/**
 * USSD Session Handler
 */
class USSDHandler {
    private $sessionId;
    private $phoneNumber;
    private $networkCode;
    private $input;
    
    public function __construct($sessionId, $phoneNumber, $networkCode, $input) {
        $this->sessionId = $sessionId;
        $this->phoneNumber = $phoneNumber;
        $this->networkCode = $networkCode;
        $this->input = $input;
    }
    
    /**
     * Process USSD request
     * @return string USSD response
     */
    public function process() {
        // Get or create session
        $session = $this->getSession();
        
        if ($this->input === '') {
            // New session - show main menu
            $this->updateSession('main_menu');
            return $this->mainMenu();
        }
        
        // Process based on current state
        switch ($session['state']) {
            case 'main_menu':
                return $this->handleMainMenu($this->input);
            case 'check_balance':
                return $this->checkBalance();
            case 'send_money':
                return $this->handleSendMoney($this->input, $session);
            case 'enter_amount':
                return $this->handleEnterAmount($this->input, $session);
            case 'enter_pin':
                return $this->handleEnterPIN($this->input, $session);
            default:
                $this->clearSession();
                return "END Session terminée.\nMerci d'utiliser NigerPay!";
        }
    }
    
    /**
     * Get session from database
     */
    private function getSession() {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM ussd_sessions WHERE session_id = ?");
        $stmt->execute([$this->sessionId]);
        $session = $stmt->fetch();
        
        if (!$session) {
            $stmt = $db->prepare("
                INSERT INTO ussd_sessions (session_id, phone_number, state, data, created_at)
                VALUES (?, ?, 'main_menu', '{}', NOW())
            ");
            $stmt->execute([$this->sessionId, $this->phoneNumber]);
            return ['state' => 'main_menu', 'data' => []];
        }
        
        return $session;
    }
    
    /**
     * Update session state
     */
    private function updateSession($state, $data = []) {
        $db = getDB();
        $stmt = $db->prepare("
            UPDATE ussd_sessions 
            SET state = ?, data = ?, updated_at = NOW()
            WHERE session_id = ?
        ");
        $stmt->execute([$state, json_encode($data), $this->sessionId]);
    }
    
    /**
     * Clear session
     */
    private function clearSession() {
        $db = getDB();
        $stmt = $db->prepare("DELETE FROM ussd_sessions WHERE session_id = ?");
        $stmt->execute([$this->sessionId]);
    }
    
    /**
     * Main menu
     */
    private function mainMenu() {
        return "CON Bienvenue sur NigerPay\n"
             . "1. Consulter solde\n"
             . "2. Envoyer argent\n"
             . "3. Retirer argent\n"
             . "4. Dernieres transactions\n"
             . "5. Aide";
    }
    
    /**
     * Handle main menu selection
     */
    private function handleMainMenu($input) {
        switch ($input) {
            case '1':
                return $this->checkBalance();
            case '2':
                $this->updateSession('send_money');
                return "CON Envoyer argent\nEntrez le numero du destinataire:";
            case '3':
                return "END Retrait d'argent\nRendez-vous chez un agent NigerPay avec votre code PIN.";
            case '4':
                return $this->getLastTransactions();
            case '5':
                return "END Aide NigerPay\n"
                     . "Service client: XX XX XX XX\n"
                     . "Email: support@nigerpay.ne";
            default:
                return "END Option invalide.\nMerci d'utiliser NigerPay!";
        }
    }
    
    /**
     * Check balance
     */
    private function checkBalance() {
        $db = getDB();
        $stmt = $db->prepare("
            SELECT wa.available_balance 
            FROM wallet_accounts wa
            JOIN users u ON wa.user_id = u.id
            WHERE u.phone_number = ? AND wa.account_type = 'primary'
        ");
        $stmt->execute([formatPhoneNumber($this->phoneNumber)]);
        $result = $stmt->fetch();
        
        if ($result) {
            $balance = formatAmount($result['available_balance']);
            return "END Votre solde:\n$balance\n\nMerci d'utiliser NigerPay!";
        }
        
        return "END Compte non trouve.\nVeuillez vous inscrire chez un agent.";
    }
    
    /**
     * Handle send money
     */
    private function handleSendMoney($input, $session) {
        $data = json_decode($session['data'], true);
        $data['recipient'] = $input;
        $this->updateSession('enter_amount', $data);
        return "CON Envoyer a: $input\nEntrez le montant (FCFA):";
    }
    
    /**
     * Handle enter amount
     */
    private function handleEnterAmount($input, $session) {
        $data = json_decode($session['data'], true);
        $data['amount'] = $input;
        $this->updateSession('enter_pin', $data);
        return "CON Montant: " . number_format($input) . " FCFA\nEntrez votre PIN:";
    }
    
    /**
     * Handle PIN entry and process transfer
     */
    private function handleEnterPIN($input, $session) {
        $data = json_decode($session['data'], true);
        $this->clearSession();
        
        // Process transfer
        $result = processTransfer(
            $this->phoneNumber,
            $data['recipient'],
            $data['amount'],
            $input,
            'USSD Transfer'
        );
        
        if ($result['success']) {
            return "END Transfert reussi!\n"
                 . "Montant: " . number_format($data['amount']) . " FCFA\n"
                 . "ID: " . substr($result['transaction_id'], -8) . "\n"
                 . "Nouveau solde: " . formatAmount($result['sender_balance'], false) . " FCFA";
        }
        
        return "END Erreur: " . $result['message'];
    }
    
    /**
     * Get last transactions
     */
    private function getLastTransactions() {
        $db = getDB();
        $stmt = $db->prepare("
            SELECT t.amount, t.transaction_type, t.created_at
            FROM transactions t
            JOIN users u ON t.sender_user_id = u.id OR t.receiver_user_id = u.id
            WHERE u.phone_number = ?
            ORDER BY t.created_at DESC
            LIMIT 3
        ");
        $stmt->execute([formatPhoneNumber($this->phoneNumber)]);
        $transactions = $stmt->fetchAll();
        
        if (empty($transactions)) {
            return "END Aucune transaction recente.";
        }
        
        $response = "END Dernieres transactions:\n";
        foreach ($transactions as $tx) {
            $type = $tx['transaction_type'] === 'transfer' ? 'Transfert' : ucfirst($tx['transaction_type']);
            $amount = formatAmount($tx['amount'], false);
            $date = date('d/m', strtotime($tx['created_at']));
            $response .= "$date: $type $amount\n";
        }
        
        return $response;
    }
}
