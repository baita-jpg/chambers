<?php
/**
 * Niger Fintech System - Core Functions
 * Contains database connection, session management, and utility helpers.
 */

// ==========================================
// 1. DATABASE CONNECTION
// ==========================================
if (!function_exists('getDB')) {
    function getDB() {
        static $db = null;
        if ($db === null) {
            // Adjust these credentials if your database uses a different user/password
            $host = '127.0.0.1';
            $dbname = 'niger_fintech';
            $username = 'root'; 
            $password = ''; 
            
            try {
                $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                die("Database Connection Error: " . $e->getMessage());
            }
        }
        return $db;
    }
}

if (!function_exists('executeInTransaction')) {
    function executeInTransaction($callback) {
        $db = getDB();
        try {
            $db->beginTransaction();
            $result = $callback($db);
            $db->commit();
            return $result;
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }
}

// ==========================================
// 2. SESSION & AUTHENTICATION
// ==========================================
if (!function_exists('startSecureSession')) {
    function startSecureSession() {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.cookie_httponly', 1);
            ini_set('session.use_only_cookies', 1);
            ini_set('session.cookie_samesite', 'Lax');
            session_start();
        }
    }
}

if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        startSecureSession();
        return isset($_SESSION['user_id']) && isset($_SESSION['session_token']);
    }
}

if (!function_exists('getCurrentUser')) {
    function getCurrentUser() {
        if (!isLoggedIn()) return null;
        
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ? AND is_active = TRUE");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    }
}

if (!function_exists('getUserByPhone')) {
    function getUserByPhone($phone) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE phone_number = ?");
        $stmt->execute([formatPhoneNumber($phone)]);
        return $stmt->fetch();
    }
}

if (!function_exists('logout')) {
    function logout() {
        startSecureSession();
        // Clear remember me tokens from DB if exists
        if (isset($_SESSION['user_id'])) {
            $db = getDB();
            $stmt = $db->prepare("DELETE FROM user_remember_me_tokens WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
        }
        
        // Clear session and cookies
        session_unset();
        session_destroy();
        setcookie('remember_me', '', time() - 3600, '/');
        
        header("Location: /login.php");
        exit;
    }
}

// ==========================================
// 3. SECURITY & ENCRYPTION
// ==========================================
if (!function_exists('hashPIN')) {
    function hashPIN($pin) {
        return password_hash($pin, PASSWORD_BCRYPT, ['cost' => 12]);
    }
}

if (!function_exists('verifyPIN')) {
    function verifyPIN($pin, $hash) {
        return password_verify($pin, $hash);
    }
}

if (!function_exists('generateSecureToken')) {
    function generateSecureToken($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }
}

if (!function_exists('csrfField')) {
    function csrfField() {
        startSecureSession();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = generateSecureToken(32);
        }
        echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($_SESSION['csrf_token']) . '">';
    }
}

if (!function_exists('validateCSRFToken')) {
    function validateCSRFToken($token) {
        startSecureSession();
        if (empty($_SESSION['csrf_token']) || empty($token)) return false;
        return hash_equals($_SESSION['csrf_token'], $token);
    }
}

if (!function_exists('sanitizeInput')) {
    function sanitizeInput($data) {
        return htmlspecialchars(strip_tags(trim($data)));
    }
}

// ==========================================
// 4. RATE LIMITING (Brute Force Protection)
// ==========================================
if (!function_exists('checkRateLimit')) {
    function checkRateLimit($action, $ip, $maxAttempts = 5, $lockoutTime = 300) {
        startSecureSession();
        $key = "rate_limit_{$action}_{$ip}";
        
        if (isset($_SESSION[$key])) {
            $data = $_SESSION[$key];
            if ($data['attempts'] >= $maxAttempts) {
                $timeLeft = $data['expires'] - time();
                if ($timeLeft > 0) {
                    $mins = ceil($timeLeft / 60);
                    return ['is_blocked' => true, 'message' => "Too many attempts. Try again in {$mins} minutes."];
                } else {
                    // Lockout expired, reset
                    unset($_SESSION[$key]);
                }
            }
        }
        return ['is_blocked' => false];
    }
}

if (!function_exists('incrementRateLimit')) {
    function incrementRateLimit($action, $ip, $lockoutTime = 300) {
        startSecureSession();
        $key = "rate_limit_{$action}_{$ip}";
        
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = ['attempts' => 1, 'expires' => time() + $lockoutTime];
        } else {
            $_SESSION[$key]['attempts']++;
            $_SESSION[$key]['expires'] = time() + $lockoutTime; // Reset lockout timer
        }
    }
}

if (!function_exists('clearRateLimit')) {
    function clearRateLimit($action, $ip) {
        startSecureSession();
        unset($_SESSION["rate_limit_{$action}_{$ip}"]);
    }
}

// ==========================================
// 5. UTILITIES & FORMATTING
// ==========================================
if (!function_exists('formatPhoneNumber')) {
    function formatPhoneNumber($phone) {
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strpos($phone, '227') === 0 && strlen($phone) === 11) {
            return '+' . $phone;
        }
        if (strlen($phone) === 8) {
            return '+227' . $phone;
        }
        if (strpos($phone, '+') !== 0) {
            $phone = '+' . $phone;
        }
        return $phone;
    }
}

if (!function_exists('validatePhoneNumber')) {
    function validatePhoneNumber($phone) {
        $formatted = formatPhoneNumber($phone);
        return preg_match('/^\+227[0-9]{8}$/', $formatted);
    }
}

if (!function_exists('getCurrentLanguage')) {
    function getCurrentLanguage() {
        startSecureSession();
        if (isset($_SESSION['lang'])) {
            return $_SESSION['lang'];
        }
        return 'ha'; // Default to Hausa
    }
}

if (!function_exists('getLangAttribute')) {
    function getLangAttribute() {
        $lang = getCurrentLanguage();
        return "lang=\"{$lang}\"";
    }
}

if (!function_exists('setFlashMessage')) {
    function setFlashMessage($type, $message) {
        startSecureSession();
        $_SESSION['flash_messages'][] = ['type' => $type, 'message' => $message];
    }
}

if (!function_exists('generateAccountNumber')) {
    function generateAccountNumber($prefix, $userId) {
        $paddedId = str_pad($userId, 6, '0', STR_PAD_LEFT);
        $random = mt_rand(100, 999);
        return "{$prefix}-{$paddedId}-{$random}";
    }
}

if (!function_exists('generateAgentCode')) {
    function generateAgentCode($userId) {
        $paddedId = str_pad($userId, 4, '0', STR_PAD_LEFT);
        return "AGT{$paddedId}";
    }
}

// ==========================================
// 6. LOGGING & AUDIT
// ==========================================
if (!function_exists('logError')) {
    function logError($message) {
        // In production, write this to a file like /var/log/nigerpay_errors.log
        error_log("[NigerPay Error] " . $message);
    }
}

if (!function_exists('logActivity')) {
    function logActivity($tableName, $recordId, $action, $oldValues = [], $newValues = []) {
        try {
            $db = getDB();
            $stmt = $db->prepare("
                INSERT INTO audit_logs (table_name, record_id, action, old_values, new_values, performed_by, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
            
            $stmt->execute([
                $tableName,
                $recordId,
                $action,
                empty($oldValues) ? null : json_encode($oldValues),
                empty($newValues) ? null : json_encode($newValues),
                $userId,
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
            ]);
        } catch (Exception $e) {
            logError("Audit Log Failed: " . $e->getMessage());
        }
    }
}

if (!function_exists('getCurrentLanguage')) {
    function getCurrentLanguage() {
        startSecureSession();
        if (isset($_SESSION['lang'])) {
            return $_SESSION['lang'];
        }
        return 'ha'; // Default to Hausa
    }
}

if (!function_exists('getLangAttribute')) {
    function getLangAttribute() {
        $lang = getCurrentLanguage();
        return "lang=\"{$lang}\"";
    }
}

/**
 * Get a system configuration value by key
 */
function getConfig($key, $default = null) {
    $db = getDB();
    $stmt = $db->prepare("SELECT config_value FROM system_config WHERE config_key = ?");
    $stmt->execute([$key]);
    $val = $stmt->fetchColumn();
    return $val !== false ? $val : $default;
}

/**
 * Get all limits for a specific KYC Tier
 */
function getTierLimits($level) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM kyc_tier_limits WHERE tier_level = ?");
    $stmt->execute([$level]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Fetches the balance details for a specific user and account type.
 * * @param int $userId The ID of the user
 * @param string $accountType 'primary', 'float', 'commission', or 'savings'
 * @return array|false Returns associative array of balance data or false if not found
 */
if (!function_exists('getAccountBalance')) {
    function getAccountBalance($userId, $accountType = 'primary') {
        try {
            $db = getDB();
            $stmt = $db->prepare("
                SELECT 
                    id, 
                    account_number, 
                    balance, 
                    available_balance, 
                    locked_amount, 
                    tier_limit 
                FROM wallet_accounts 
                WHERE user_id = ? AND account_type = ?
                LIMIT 1
            ");
            $stmt->execute([(int)$userId, $accountType]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            logError("Balance Fetch Error: " . $e->getMessage());
            return false;
        }
    }
}
/**
 * Monitors Agent Float and alerts Admin if it falls below threshold
 */
function checkLowFloatAlert($agentId) {
    $db = getDB();
    $$threshold = (float)getConfig('low_float_threshold', 50000); // FETCH DYNAMIC THRESHOLD FROM DATABASE
    
    // Get current float balance
    $wallet = getAccountBalance($agentId, 'float');
    
    if ($wallet && $wallet['available_balance'] < $threshold) {
        // Check if an unread alert already exists for this agent to avoid spamming
        $stmt = $db->prepare("SELECT id FROM system_alerts WHERE agent_id = ? AND alert_type = 'low_float' AND is_read = 0");
        $stmt->execute([$agentId]);
        
        if (!$stmt->fetch()) {
            $msg = "Alert: Agent ID " . $agentId . " has a low float balance of " . number_format($wallet['available_balance']) . " XOF.";
            $stmt = $db->prepare("INSERT INTO system_alerts (agent_id, alert_type, message) VALUES (?, 'low_float', ?)");
            $stmt->execute([$agentId, $msg]);
        }
    }
}
/**
 * Maintenance Mode Middleware
 * Checks if the system is locked and redirects non-admins.
 */
if (!function_exists('checkMaintenanceMode')) {
    function checkMaintenanceMode() {
        // We only check if we aren't already on the maintenance page
        if (basename($_SERVER['PHP_SELF']) === 'maintenance.php') {
            return;
        }

        $isMaintenance = getConfig('maintenance_mode', '0');

        if ($isMaintenance === '1') {
            startSecureSession();
            // Allow Admins to bypass maintenance to fix things
            if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
                // Determine path to maintenance page based on current directory
                $path = (str_contains($_SERVER['PHP_SELF'], '/admin/') || str_contains($_SERVER['PHP_SELF'], '/agent/') || str_contains($_SERVER['PHP_SELF'], '/customer/')) 
                    ? '../maintenance.php' 
                    : 'maintenance.php';
                
                header("Location: $path");
                exit;
            }
        }
    }
}
?>