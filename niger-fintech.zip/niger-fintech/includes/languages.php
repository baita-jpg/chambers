<?php
/**
 * Niger Fintech System - Language Management
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define available languages
const AVAILABLE_LANGUAGES = [
    'fr' => ['name' => 'Français', 'native' => 'Français'],
    'ha' => ['name' => 'Hausa', 'native' => 'Hausa'],
];

// Set default language
const DEFAULT_LANGUAGE = 'ha';

// Check for language change request
if (isset($_GET['lang']) && array_key_exists($_GET['lang'], AVAILABLE_LANGUAGES)) {
    $_SESSION['lang'] = $_GET['lang'];
    
    // Redirect to the same page without the lang parameter
    $redirect_url = strtok($_SERVER['REQUEST_URI'], '?');
    header('Location: ' . $redirect_url);
    exit;
}

/**
 * Get the current language code.
 * @return string
 */
function getCurrentLanguage() {
    return $_SESSION['lang'] ?? DEFAULT_LANGUAGE;
}

/**
 * Get the current language's HTML lang attribute.
 * @return string
 */
function getLangAttribute() {
    return 'lang="' . getCurrentLanguage() . '"';
}

/**
 * Get the URL to switch to a specific language.
 * @param string $langCode
 * @return string
 */
function getLanguageSwitchUrl($langCode) {
    $url = strtok($_SERVER['REQUEST_URI'], '?');
    return $url . '?lang=' . $langCode;
}

?>