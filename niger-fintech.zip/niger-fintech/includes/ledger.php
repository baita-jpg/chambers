<?php
/**
 * Niger Fintech System - Ledger Engine (Double-Entry)
 */

require_once __DIR__ . '/functions.php';

/**
 * Process a Cash-In transaction
 */
function processCashIn($customerPhone, $amount, $agentId, $description = '') {
    if ($amount < 100) return ['success' => false, 'message' => 'Min 100 FCFA'];
    $transactionId = generateTransactionID('CIN');
    
    try {
        return executeInTransaction(function($db) use ($customerPhone, $amount, $agentId, $description, $transactionId) {
            // 1. Lock Customer Account
            $stmt = $db->prepare("SELECT wa.id, wa.user_id, wa.balance, wa.tier_limit FROM wallet_accounts wa JOIN users u ON wa.user_id = u.id WHERE u.phone_number = ? AND wa.account_type = 'primary' FOR UPDATE");
            $stmt->execute([formatPhoneNumber($customerPhone)]);
            $cust = $stmt->fetch();
            if (!$cust) throw new Exception('Client non trouvé');
            if (($cust['balance'] + $amount) > $cust['tier_limit']) throw new Exception('Limite KYC dépassée');

            // 2. Lock Agent Float
            $stmt = $db->prepare("SELECT id, available_balance FROM wallet_accounts WHERE user_id = ? AND account_type = 'float' FOR UPDATE");
            $stmt->execute([$agentId]);
            $agent = $stmt->fetch();
            if (!$agent || $agent['available_balance'] < $amount) throw new Exception('Solde float insuffisant');

            // 3. Calculate Commission
            $commRate = getConfig('agent_commission_rate', 1.0);
            $comm = floor($amount * ($commRate / 100));

            // 4. Atomic Updates
            $db->prepare("UPDATE wallet_accounts SET balance = balance - ?, available_balance = available_balance - ? WHERE id = ?")->execute([$amount, $amount, $agent['id']]);
            $db->prepare("UPDATE wallet_accounts SET balance = balance + ? WHERE user_id = ? AND account_type = 'float'")->execute([$amount, $agentId]);
            
            // 5. Records
            $stmt = $db->prepare("INSERT INTO transactions (transaction_id, transaction_type, debit_account_id, credit_account_id, amount, commission_amount, agent_id, receiver_user_id, status, created_at) VALUES (?, 'cash_in', ?, ?, ?, ?, ?, ?, 'completed', NOW())");
            $stmt->execute([$transactionId, $agent['id'], $cust['id'], $amount, $comm, $agentId, $cust['user_id']]);

            sendSMSNotification($customerPhone, "Dépôt reçu: " . formatAmount($amount) . ". ID: $transactionId");
            return ['success' => true, 'transaction_id' => $transactionId];
        });
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Process a Cash-Out transaction
 */
function processCashOut($customerPhone, $amount, $agentId, $pin) {
    if ($amount < 100) return ['success' => false, 'message' => 'Min 100 FCFA'];
    $transactionId = generateTransactionID('COT');

    try {
        return executeInTransaction(function($db) use ($customerPhone, $amount, $agentId, $pin, $transactionId) {
            // Verify Customer & PIN
            $stmt = $db->prepare("SELECT wa.id, wa.user_id, wa.balance, u.pin_hash FROM wallet_accounts wa JOIN users u ON wa.user_id = u.id WHERE u.phone_number = ? AND wa.account_type = 'primary' FOR UPDATE");
            $stmt->execute([formatPhoneNumber($customerPhone)]);
            $cust = $stmt->fetch();
            
            if (!$cust || !password_verify($pin, $cust['pin_hash'])) throw new Exception('Identifiants invalides');

            $fee = floor($amount * (getConfig('cash_out_fee_percent', 1.5) / 100));
            $total = $amount + $fee;
            if ($cust['balance'] < $total) throw new Exception('Solde insuffisant');

            // Atomic Updates
            $db->prepare("UPDATE wallet_accounts SET balance = balance - ?, available_balance = available_balance - ? WHERE id = ?")->execute([$total, $total, $cust['id']]);
            $db->prepare("UPDATE wallet_accounts SET balance = balance + ?, available_balance = available_balance + ? WHERE user_id = ? AND account_type = 'float'")->execute([$amount, $amount, $agentId]);

            return ['success' => true, 'transaction_id' => $transactionId];
        });
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * P2P Transfer
 */
function processTransfer($senderPhone, $receiverPhone, $amount, $pin) {
    if ($amount < 100) return ['success' => false, 'message' => 'Min 100 FCFA'];
    $transactionId = generateTransactionID('TRF');

    try {
        return executeInTransaction(function($db) use ($senderPhone, $receiverPhone, $amount, $pin, $transactionId) {
            $stmt = $db->prepare("SELECT id, balance, pin_hash FROM users u JOIN wallet_accounts wa ON u.id = wa.user_id WHERE u.phone_number = ? AND wa.account_type = 'primary' FOR UPDATE");
            
            $stmt->execute([formatPhoneNumber($senderPhone)]);
            $sender = $stmt->fetch();
            if (!$sender || !password_verify($pin, $sender['pin_hash'])) throw new Exception('PIN invalide');

            $stmt->execute([formatPhoneNumber($receiverPhone)]);
            $recv = $stmt->fetch();
            if (!$recv) throw new Exception('Destinataire non trouvé');

            $fee = floor($amount * (getConfig('transfer_fee_percent', 0.5) / 100));
            if ($sender['balance'] < ($amount + $fee)) throw new Exception('Solde insuffisant');

            $db->prepare("UPDATE wallet_accounts SET balance = balance - ? WHERE id = ?")->execute([$amount + $fee, $sender['id']]);
            $db->prepare("UPDATE wallet_accounts SET balance = balance + ? WHERE id = ?")->execute([$amount, $recv['id']]);

            return ['success' => true, 'transaction_id' => $transactionId];
        });
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Create a Withdrawal Request (Customer Side)
 * This generates a 6-digit code and locks the requested amount.
 */
function processWithdrawalRequest($userId, $amount) {
    $db = getDB();
    
    if ($amount < 100) {
        return ['success' => false, 'message' => 'Minimum 100 XOF'];
    }

    try {
        return executeInTransaction(function($db) use ($userId, $amount) {
            // 1. Check if user already has a pending withdrawal
            $stmt = $db->prepare("SELECT id FROM transactions WHERE sender_user_id = ? AND transaction_type = 'withdrawal' AND status = 'pending'");
            $stmt->execute([$userId]);
            if ($stmt->fetch()) {
                throw new Exception('Kuna da lambar cire kuɗi da ba ku yi amfani da ita ba / Vous avez déjà un retrait en cours.');
            }

            // 2. Lock the user's funds
            $stmt = $db->prepare("SELECT id, available_balance FROM wallet_accounts WHERE user_id = ? AND account_type = 'primary' FOR UPDATE");
            $stmt->execute([$userId]);
            $account = $stmt->fetch();

            if (!$account || $account['available_balance'] < $amount) {
                throw new Exception('Ba ku da isassun kuɗi / Solde insuffisant.');
            }

            // Move funds to locked status
            $db->prepare("UPDATE wallet_accounts SET available_balance = available_balance - ?, locked_amount = locked_amount + ? WHERE id = ?")
               ->execute([$amount, $amount, $account['id']]);

            // 3. Generate a unique 6-digit token
            $token = str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
            $transactionId = 'WTH' . date('ymd') . strtoupper(bin2hex(random_bytes(2)));

            // 4. Create the pending transaction
            $stmt = $db->prepare("
                INSERT INTO transactions (
                    transaction_id, transaction_type, status, sender_user_id, 
                    amount, withdrawal_token, created_at
                ) VALUES (?, 'withdrawal', 'pending', ?, ?, ?, NOW())
            ");
            $stmt->execute([$transactionId, $userId, $amount, $token]);

            return [
                'success' => true, 
                'token' => $token, 
                'transaction_id' => $transactionId
            ];
        });
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Finalize Withdrawal (Agent Side)
 * This is called when an agent enters the customer's 6-digit code.
 */
function completeWithdrawalWithToken($agentId, $token) {
    try {
        return executeInTransaction(function($db) use ($agentId, $token) {
            // 1. Find the pending withdrawal by token
            $stmt = $db->prepare("
                SELECT t.*, wa.id as account_id 
                FROM transactions t 
                JOIN wallet_accounts wa ON t.sender_user_id = wa.user_id 
                WHERE t.withdrawal_token = ? AND t.status = 'pending' AND wa.account_type = 'primary'
                FOR UPDATE
            ");
            $stmt->execute([$token]);
            $tx = $stmt->fetch();

            if (!$tx) throw new Exception('Lambar ba daidai ba ce / Code invalide ou expiré.');

            $amount = $tx['amount'];

            // 2. Deduct from customer's TOTAL balance and LOCKED amount
            $db->prepare("UPDATE wallet_accounts SET balance = balance - ?, locked_amount = locked_amount - ? WHERE id = ?")
               ->execute([$amount, $amount, $tx['account_id']]);

            // 3. Credit Agent Float (The agent gave physical cash, so they get digital float back)
            $db->prepare("UPDATE wallet_accounts SET balance = balance + ?, available_balance = available_balance + ? WHERE user_id = ? AND account_type = 'float'")
               ->execute([$amount, $amount, $agentId]);

            // 4. Mark transaction as completed
            $db->prepare("UPDATE transactions SET status = 'completed', agent_id = ?, completed_at = NOW(), withdrawal_token = NULL WHERE id = ?")
               ->execute([$agentId, $tx['id']]);

            return ['success' => true, 'amount' => $amount];
        });
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}