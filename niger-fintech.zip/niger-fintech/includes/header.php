<?php
/**
 * Niger Fintech System - Header Template
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/languages.php';

// Start session and validate
startSecureSession();

// Get current user if logged in
$currentUser = null;
if (isset($_SESSION['user_id'])) {
    $currentUser = getCurrentUser();
}

// Determine page title
$pageTitle = $pageTitle ?? 'NigerPay - Système Financier Mobile';
?>
<!DOCTYPE html>
<html <?php echo getLangAttribute(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="NigerPay - Système financier mobile pour le Niger">
    <meta name="theme-color" content="#0f766e">
    
    <!-- Security Headers -->
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' cdn.tailwindcss.com cdnjs.cloudflare.com; style-src 'self' cdn.tailwindcss.com cdnjs.cloudflare.com fonts.googleapis.com; font-src 'self' fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self';">
    
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom Tailwind Config -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'system-ui', 'sans-serif'],
                    },
                    colors: {
                        primary: {
                            50: '#f0fdfa',
                            100: '#ccfbf1',
                            200: '#99f6e4',
                            300: '#5eead4',
                            400: '#2dd4bf',
                            500: '#14b8a6',
                            600: '#0d9488',
                            700: '#0f766e',
                            800: '#115e59',
                            900: '#134e4a',
                        },
                        secondary: {
                            50: '#fff7ed',
                            100: '#ffedd5',
                            200: '#fed7aa',
                            300: '#fdba74',
                            400: '#fb923c',
                            500: '#f97316',
                            600: '#ea580c',
                            700: '#c2410c',
                            800: '#9a3412',
                            900: '#7c2d12',
                        },
                        success: {
                            50: '#f0fdf4',
                            100: '#dcfce7',
                            500: '#22c55e',
                            600: '#16a34a',
                        },
                        warning: {
                            50: '#fffbeb',
                            100: '#fef3c7',
                            500: '#f59e0b',
                            600: '#d97706',
                        },
                        danger: {
                            50: '#fef2f2',
                            100: '#fee2e2',
                            500: '#ef4444',
                            600: '#dc2626',
                        }
                    }
                }
            }
        }
    </script>
    
    <style>
        /* Custom styles for mobile optimization */
        body {
            font-family: 'Inter', system-ui, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        .touch-target {
            min-height: 44px;
            min-width: 44px;
        }
        
        /* PIN input styling */
        .pin-input {
            letter-spacing: 0.5em;
            text-align: center;
            font-variant-numeric: tabular-nums;
        }
        
        /* Loading spinner */
        .spinner {
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        /* Fade animation */
        .fade-in {
            animation: fadeIn 0.3s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Slide animation */
        .slide-up {
            animation: slideUp 0.3s ease-out;
        }
        
        @keyframes slideUp {
            from { transform: translateY(100%); }
            to { transform: translateY(0); }
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f5f9;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 3px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        /* Amount display */
        .amount-display {
            font-variant-numeric: tabular-nums;
            font-feature-settings: "tnum";
        }
        
        /* Card hover effect */
        .card-hover {
            transition: all 0.2s ease;
        }
        
        .card-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
        }
        
        /* Button press effect */
        .btn-press:active {
            transform: scale(0.98);
        }
        
        /* Status badges */
        .status-badge {
            @apply inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium;
        }
        
        /* Bottom navigation for mobile */
        .bottom-nav {
            @apply fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-50;
        }
        
        .bottom-nav-item {
            @apply flex flex-col items-center justify-center py-2 px-3 text-gray-500 hover:text-primary-600 transition-colors;
        }
        
        .bottom-nav-item.active {
            @apply text-primary-600;
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 min-h-screen">
    <?php if ($currentUser): ?>
    <!-- Top Navigation -->
    <nav class="bg-primary-700 text-white sticky top-0 z-40 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-14">
                <!-- Logo -->
                <div class="flex items-center">
                    <a href="/" class="flex items-center space-x-2">
                        <div class="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                            <i class="fas fa-wallet text-primary-700 text-lg"></i>
                        </div>
                        <span class="font-bold text-lg hidden sm:block">NigerPay</span>
                    </a>
                </div>
                
                <!-- Desktop Navigation -->
                <div class="hidden md:flex items-center space-x-4">
                    <?php if ($currentUser['user_type'] === 'customer'): ?>
                        <a href="/customer/dashboard.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Tableau de bord</a>
                        <a href="/customer/transfer.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Transfert</a>
                        <a href="/customer/history.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Historique</a>
                    <?php elseif ($currentUser['user_type'] === 'agent' || $currentUser['user_type'] === 'super_agent'): ?>
                        <a href="/agent/dashboard.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Tableau de bord</a>
                        <a href="/agent/cash-in.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Dépôt</a>
                        <a href="/agent/cash-out.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Retrait</a>
                    <?php elseif ($currentUser['user_type'] === 'admin'): ?>
                        <a href="/admin/dashboard.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Admin</a>
                        <a href="/admin/agents.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Agents</a>
                        <a href="/admin/transactions.php" class="px-3 py-2 rounded-md text-sm font-medium hover:bg-primary-600 transition">Transactions</a>
                    <?php endif; ?>
                </div>
                
                <!-- User Menu -->
                <div class="flex items-center space-x-3">
                    <!-- Balance (for agents) -->
                    <?php if ($currentUser['user_type'] === 'agent' || $currentUser['user_type'] === 'super_agent'): ?>
                        <?php $balance = getAccountBalance($currentUser['id'], 'float'); ?>
                        <div class="hidden sm:flex items-center bg-primary-800 rounded-lg px-3 py-1.5">
                            <i class="fas fa-coins text-yellow-400 mr-2 text-sm"></i>
                            <span class="font-semibold text-sm amount-display"><?php echo formatAmount($balance['available_balance'] ?? 0); ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Profile Dropdown -->
                    <div class="relative" id="userMenu">
                        <button onclick="toggleUserMenu()" class="flex items-center space-x-2 focus:outline-none">
                            <div class="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                                <span class="text-sm font-semibold"><?php echo strtoupper(substr($currentUser['first_name'], 0, 1)); ?></span>
                            </div>
                            <span class="hidden sm:block text-sm font-medium"><?php echo htmlspecialchars($currentUser['first_name']); ?></span>
                            <i class="fas fa-chevron-down text-xs hidden sm:block"></i>
                        </button>
                        
                        <!-- Dropdown -->
                        <div id="userDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-50">
                            <a href="/profile.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Profil
                            </a>
                            <a href="/settings.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cog mr-2"></i> Paramètres
                            </a>
                            <hr class="my-1">
                            <a href="/logout.php" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                                <i class="fas fa-sign-out-alt mr-2"></i> Déconnexion
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Mobile Bottom Navigation -->
    <nav class="bottom-nav md:hidden">
        <div class="flex justify-around">
            <?php if ($currentUser['user_type'] === 'customer'): ?>
                <a href="/customer/dashboard.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/customer/dashboard.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-home text-lg"></i>
                    <span class="text-xs mt-1">Accueil</span>
                </a>
                <a href="/customer/transfer.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/customer/transfer.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-paper-plane text-lg"></i>
                    <span class="text-xs mt-1">Transfert</span>
                </a>
                <a href="/customer/qr-pay.php" class="bottom-nav-item">
                    <div class="w-12 h-12 bg-primary-600 rounded-full flex items-center justify-center -mt-6 shadow-lg">
                        <i class="fas fa-qrcode text-white text-xl"></i>
                    </div>
                </a>
                <a href="/customer/history.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/customer/history.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-history text-lg"></i>
                    <span class="text-xs mt-1">Historique</span>
                </a>
                <a href="/customer/profile.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/customer/profile.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-user text-lg"></i>
                    <span class="text-xs mt-1">Profil</span>
                </a>
            <?php elseif ($currentUser['user_type'] === 'agent' || $currentUser['user_type'] === 'super_agent'): ?>
                <a href="/agent/dashboard.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/agent/dashboard.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-home text-lg"></i>
                    <span class="text-xs mt-1">Accueil</span>
                </a>
                <a href="/agent/cash-in.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/agent/cash-in.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-arrow-down text-lg"></i>
                    <span class="text-xs mt-1">Dépôt</span>
                </a>
                <a href="/agent/cash-out.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/agent/cash-out.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-arrow-up text-lg"></i>
                    <span class="text-xs mt-1">Retrait</span>
                </a>
                <a href="/agent/kyc.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/agent/kyc.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-id-card text-lg"></i>
                    <span class="text-xs mt-1">KYC</span>
                </a>
                <a href="/agent/profile.php" class="bottom-nav-item <?php echo strpos($_SERVER['PHP_SELF'], '/agent/profile.php') !== false ? 'active' : ''; ?>">
                    <i class="fas fa-user text-lg"></i>
                    <span class="text-xs mt-1">Profil</span>
                </a>
            <?php endif; ?>
        </div>
    </nav>
    <?php endif; ?>
    
    <!-- Flash Messages -->
    <?php if (hasFlashMessages()): ?>
        <div class="fixed top-16 left-0 right-0 z-50 px-4">
            <?php foreach (getFlashMessages() as $flash): ?>
                <div class="max-w-md mx-auto mb-2 p-4 rounded-lg shadow-lg fade-in <?php 
                    echo $flash['type'] === 'success' ? 'bg-success-100 text-success-800 border border-success-200' : 
                         ($flash['type'] === 'error' ? 'bg-danger-100 text-danger-800 border border-danger-200' : 
                         ($flash['type'] === 'warning' ? 'bg-warning-100 text-warning-800 border border-warning-200' : 
                         'bg-primary-100 text-primary-800 border border-primary-200')); 
                ?>">
                    <div class="flex items-center">
                        <i class="fas <?php 
                            echo $flash['type'] === 'success' ? 'fa-check-circle' : 
                                 ($flash['type'] === 'error' ? 'fa-exclamation-circle' : 
                                 ($flash['type'] === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle')); 
                        ?> mr-2"></i>
                        <span class="text-sm font-medium"><?php echo htmlspecialchars($flash['message']); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <!-- Main Content -->
    <main class="<?php echo $currentUser ? 'pb-20 md:pb-0' : ''; ?>">
