<?php
/**
 * Niger Fintech System - Authentication Module
 * * Identity & Access Management (IAM) - Handles login, session tokens, and PIN encryption.
 */

require_once __DIR__ . '/functions.php'; // <--- THIS IS THE FIX

if (!function_exists('authenticateUser')) {
    function authenticateUser($phone, $pin) {
        $db = getDB();
        
        // Find user by phone
        $stmt = $db->prepare("SELECT * FROM users WHERE phone_number = ? AND is_active = TRUE");
        $stmt->execute([formatPhoneNumber($phone)]);
        $user = $stmt->fetch();

        // Check if user exists and PIN matches
        // verifyPIN() is defined in functions.php
        if ($user && verifyPIN($pin, $user['pin_hash'])) {
            startSecureSession();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['session_token'] = generateSecureToken();
            return ['success' => true, 'user' => $user];
        }

        return ['success' => false, 'message' => 'Lambar waya ko PIN ba daidai ba / Téléphone ou PIN incorrect'];
    }
}

/**
 * Restricts page access based on user type.
 * * @param string|array $role A single role (string) or multiple roles (array) allowed.
 * @param string $redirect The URL to redirect unauthorized users to.
 */
if (!function_exists('requireRole')) {
    function requireRole($role, $redirect = '../login.php') {
        // 1. Ensure a session is active
        startSecureSession();

        // 2. Check if the user is logged in
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type'])) {
            header("Location: $redirect?error=unauthorized");
            exit;
        }

        // 3. Normalize role check (allows passing 'admin' or ['admin', 'agent'])
        $allowedRoles = is_array($role) ? $role : [$role];

        // 4. Verify user type against allowed roles
        if (!in_array($_SESSION['user_type'], $allowedRoles)) {
            // Log unauthorized access attempt for security auditing
            logActivity('security', $_SESSION['user_id'], 'UNAUTHORIZED_ACCESS_ATTEMPT', ['attempted_role' => $role]);
            
            header("Location: $redirect?error=access_denied");
            exit;
        }
    }
}

/**
 * Generate and send OTP
 */
function generateOTP($phoneNumber) {
    $otp = str_pad(random_int(100000, 999999), 6, '0', STR_PAD_LEFT);
    
    if (session_status() === PHP_SESSION_NONE) {
        startSecureSession();
    }

    $_SESSION['otp'] = [
        'code' => $otp,
        'phone' => formatPhoneNumber($phoneNumber),
        'expires' => time() + 300 
    ];
    
    $message = "Votre code de verification est: $otp. Ne partagez ce code avec personne.";
    sendSMSNotification($phoneNumber, $message, 'otp');
    
    return ['success' => true, 'message' => 'Code envoyé'];
}

/**
 * Verify OTP
 */
function verifyOTP($otp, $phoneNumber) {
    if (session_status() === PHP_SESSION_NONE) {
        startSecureSession();
    }
    
    if (!isset($_SESSION['otp'])) {
        return false;
    }
    
    $storedOTP = $_SESSION['otp'];
    
    if ($storedOTP['expires'] < time()) {
        unset($_SESSION['otp']);
        return false;
    }
    
    if ($storedOTP['phone'] !== formatPhoneNumber($phoneNumber)) {
        return false;
    }
    
    if ($storedOTP['code'] !== $otp) {
        return false;
    }
    
    unset($_SESSION['otp']);
    return true;
}

/**
 * Create user session
 */
function createUserSession($user) {
    if (session_status() === PHP_SESSION_NONE) {
        startSecureSession();
    }
    
    session_regenerate_id(true);
    
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['phone_number'] = $user['phone_number'];
    $_SESSION['first_name'] = $user['first_name'];
    $_SESSION['last_name'] = $user['last_name'];
    $_SESSION['user_type'] = $user['user_type'];
    $_SESSION['kyc_tier'] = $user['kyc_tier'];
    $_SESSION['kyc_status'] = $user['kyc_status'];
    $_SESSION['login_time'] = time();
    $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];
    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
    
    $db = getDB();
    $sessionToken = generateSecureToken();
    $expiresAt = date('Y-m-d H:i:s', time() + 1800); 
    
    $stmt = $db->prepare("
        INSERT INTO user_sessions (user_id, session_token, device_info, ip_address, expires_at, created_at)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $user['id'],
        $sessionToken,
        $_SERVER['HTTP_USER_AGENT'],
        $_SERVER['REMOTE_ADDR'],
        $expiresAt
    ]);
    
    $_SESSION['session_token'] = $sessionToken;
}

/**
 * Create a "Remember Me" cookie and token
 */
function rememberUser($userId) {
    $db = getDB();
    clearRememberMeTokens($userId);

    $selector = generateSecureToken(12);
    $validator = generateSecureToken(32);
    $tokenHash = hash('sha256', $validator);
    $expiresAt = date('Y-m-d H:i:s', time() + (86400 * 30));

    try {
        $stmt = $db->prepare("
            INSERT INTO user_remember_me_tokens (user_id, selector, token_hash, expires_at)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$userId, $selector, $tokenHash, $expiresAt]);

        $cookieValue = $selector . ':' . $validator;
        setcookie('remember_me', $cookieValue, [
            'expires' => time() + (86400 * 30),
            'path' => '/',
            'domain' => '', 
            'secure' => isset($_SERVER['HTTPS']), 
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
    } catch (PDOException $e) {
        logError('Remember Me token creation failed: ' . $e->getMessage());
    }
}

/**
 * Check for a valid "Remember Me" cookie
 */
function checkRememberMeCookie() {
    if (isLoggedIn() || !isset($_COOKIE['remember_me'])) {
        return false;
    }

    list($selector, $validator) = explode(':', $_COOKIE['remember_me'], 2);

    if (empty($selector) || empty($validator)) {
        return false;
    }

    $db = getDB();
    $stmt = $db->prepare("
        SELECT * FROM user_remember_me_tokens 
        WHERE selector = ? AND expires_at > NOW()
    ");
    $stmt->execute([$selector]);
    $tokenData = $stmt->fetch();

    if (!$tokenData) {
        return false;
    }

    if (hash_equals($tokenData['token_hash'], hash('sha256', $validator))) {
        $stmt = $db->prepare("
            SELECT u.*, wa.id as wallet_id, wa.balance, wa.available_balance, wa.account_number
            FROM users u
            LEFT JOIN wallet_accounts wa ON u.id = wa.user_id AND wa.account_type = 'primary'
            WHERE u.id = ?
        ");
        $stmt->execute([$tokenData['user_id']]);
        $user = $stmt->fetch();

        if ($user) {
            createUserSession($user);
            logActivity('users', $user['id'], 'LOGIN_REMEMBER_ME', [], ['ip' => $_SERVER['REMOTE_ADDR']]);
            rememberUser($user['id']);
            return true;
        }
    }

    clearRememberMeTokens($tokenData['user_id']);
    return false;
}

/**
 * Clear all "Remember Me" tokens for a user
 */
function clearRememberMeTokens($userId) {
    getDB()->prepare("DELETE FROM user_remember_me_tokens WHERE user_id = ?")->execute([$userId]);
}

/**
 * Validate session token
 */
function validateSession() {
    if (session_status() === PHP_SESSION_NONE) {
        startSecureSession();
    }
    
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_token'])) {
        return false;
    }
    
    if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time'] > 1800)) {
        logout();
        return false;
    }
    
    $db = getDB();
    $stmt = $db->prepare("
        SELECT * FROM user_sessions 
        WHERE user_id = ? AND session_token = ? AND is_active = TRUE AND expires_at > NOW()
    ");
    $stmt->execute([$_SESSION['user_id'], $_SESSION['session_token']]);
    
    if (!$stmt->fetch()) {
        logout();
        return false;
    }
    
    $_SESSION['login_time'] = time();
    return true;
}

/**
 * Change user PIN
 */
function changePIN($userId, $currentPin, $newPin) {
    $db = getDB();
    
    if (strlen($newPin) < 4 || strlen($newPin) > 6 || !preg_match('/^[0-9]+$/', $newPin)) {
        return ['success' => false, 'message' => 'Le PIN doit contenir entre 4 et 6 chiffres'];
    }
    
    try {
        $stmt = $db->prepare("SELECT pin_hash FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) return ['success' => false, 'message' => 'Utilisateur non trouvé'];
        
        if (!verifyPIN($currentPin, $user['pin_hash'])) {
            return ['success' => false, 'message' => 'PIN actuel incorrect'];
        }
        
        $newPinHash = hashPIN($newPin);
        
        $stmt = $db->prepare("UPDATE users SET pin_hash = ? WHERE id = ?");
        $stmt->execute([$newPinHash, $userId]);
        
        logActivity('users', $userId, 'PIN_CHANGE', [], []);
        sendSMSNotification(getUserPhone($userId), 'Votre code PIN a été modifié avec succès.', 'alert');
        
        return ['success' => true, 'message' => 'PIN modifié avec succès'];
        
    } catch (PDOException $e) {
        logError('PIN change error: ' . $e->getMessage());
        return ['success' => false, 'message' => 'Erreur lors du changement de PIN'];
    }
}

/**
 * Reset user PIN (admin only)
 */
function resetPIN($userId, $newPin, $adminId) {
    $db = getDB();
    
    if (strlen($newPin) < 4 || strlen($newPin) > 6) {
        return ['success' => false, 'message' => 'Le PIN doit contenir entre 4 et 6 chiffres'];
    }
    
    try {
        $newPinHash = hashPIN($newPin);
        
        $stmt = $db->prepare("UPDATE users SET pin_hash = ?, failed_pin_attempts = 0, is_blocked = FALSE WHERE id = ?");
        $stmt->execute([$newPinHash, $userId]);
        
        logActivity('users', $userId, 'PIN_RESET', [], ['reset_by' => $adminId]);
        sendSMSNotification(getUserPhone($userId), 'Votre code PIN a été réinitialisé. Veuillez contacter votre agent pour le nouveau PIN.', 'alert');
        
        return ['success' => true, 'message' => 'PIN réinitialisé avec succès'];
        
    } catch (PDOException $e) {
        logError('PIN reset error: ' . $e->getMessage());
        return ['success' => false, 'message' => 'Erreur lors de la réinitialisation du PIN'];
    }
}

/**
 * Reset user PIN by phone number after OTP verification.
 */
function resetUserPINByPhone($phoneNumber, $newPin) {
    $db = getDB();
    $currentLang = getCurrentLanguage();

    if (!preg_match('/^\d{4,6}$/', $newPin)) {
        return [
            'success' => false,
            'message' => ($currentLang === 'ha') ? 'PIN dole ne ya kasance tsakanin lambobi 4 zuwa 6.' : 'Le PIN doit contenir entre 4 et 6 chiffres.'
        ];
    }

    try {
        $newPinHash = hashPIN($newPin);

        $stmt = $db->prepare("
            UPDATE users 
            SET pin_hash = ?, failed_pin_attempts = 0, is_blocked = FALSE 
            WHERE phone_number = ?
        ");
        $stmt->execute([$newPinHash, $phoneNumber]);

        $user = getUserByPhone($phoneNumber);
        if ($user) {
            logActivity('users', $user['id'], 'PIN_RESET_USER', [], ['ip' => $_SERVER['REMOTE_ADDR']]);
            $message = ($currentLang === 'ha') ? 'An yi nasarar sake saita lambar PIN ɗinka.' : 'Votre code PIN a été réinitialisé avec succès.';
            sendSMSNotification($phoneNumber, $message, 'alert');
        }

        return ['success' => true];

    } catch (PDOException $e) {
        logError('User PIN reset error: ' . $e->getMessage());
        return [
            'success' => false,
            'message' => ($currentLang === 'ha') ? 'Kuskure ya faru. Da fatan za a sake gwadawa.' : 'Une erreur est survenue. Veuillez réessayer.'
        ];
    }
}

/**
 * Get user phone number
 */
function getUserPhone($userId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT phone_number FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $result = $stmt->fetch();
    return $result ? $result['phone_number'] : null;
}

/**
 * Send SMS notification
 */
function sendSMSNotification($phoneNumber, $message, $type = 'transaction') {
    $db = getDB();
    
    try {
        $stmt = $db->prepare("
            INSERT INTO sms_notifications (phone_number, message, message_type, status, created_at)
            VALUES (?, ?, ?, 'pending', NOW())
        ");
        $stmt->execute([formatPhoneNumber($phoneNumber), $message, $type]);
        
        return true;
    } catch (PDOException $e) {
        logError('SMS notification error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Register new user
 */
function registerUser($userData) {
    try {
        return executeInTransaction(function($db) use ($userData) {
            $phoneNumber = formatPhoneNumber($userData['phone_number']);
            
            $stmt = $db->prepare("SELECT id FROM users WHERE phone_number = ?");
            $stmt->execute([$phoneNumber]);
            if ($stmt->fetch()) {
                throw new Exception('An riga an yi rijistar wannan lambar wayar');
            }

            if (preg_match('/^[+]?227[0-9]{8}$/', $phoneNumber)) {
                 throw new Exception('Lambar wayar ba ta bi tsarin da ake buƙata ba.');
            }
            
            if (strlen($userData['pin']) < 4 || strlen($userData['pin']) > 6) {
                throw new Exception('Dole ne PIN ya kasance tsakanin lambobi 4 zuwa 6');
            }
            
            $pinHash = hashPIN($userData['pin']);
            $userType = $userData['user_type'] ?? 'customer';
            $kycTier = $userData['kyc_tier'] ?? 1;
            
            $stmt = $db->prepare("
                INSERT INTO users (
                    phone_number, pin_hash, user_type, kyc_tier, kyc_status,
                    first_name, last_name, email, date_of_birth, gender,
                    nina_number, address, city, region, created_at
                ) VALUES (?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $phoneNumber, $pinHash, $userType, $kycTier,
                $userData['first_name'], $userData['last_name'],
                $userData['email'] ?? null, $userData['date_of_birth'] ?? null,
                $userData['gender'] ?? null, $userData['nina_number'] ?? null,
                $userData['address'] ?? null, $userData['city'] ?? null,
                $userData['region'] ?? null
            ]);
            
            $userId = $db->lastInsertId();
            $accountNumber = generateAccountNumber('PRM', $userId);
            
            $stmt = $db->prepare("
                INSERT INTO wallet_accounts (user_id, account_type, account_number, tier_limit)
                VALUES (?, 'primary', ?, (SELECT max_balance FROM kyc_tier_limits WHERE tier_level = ?))
            ");
            $stmt->execute([$userId, $accountNumber, $kycTier]);
            
            if ($userType === 'agent' || $userType === 'super_agent') {
                $commissionAccount = generateAccountNumber('COM', $userId);
                $stmt = $db->prepare("INSERT INTO wallet_accounts (user_id, account_type, account_number, tier_limit) VALUES (?, 'commission', ?, 999999999999)");
                $stmt->execute([$userId, $commissionAccount]);
                
                $floatAccount = generateAccountNumber('FLT', $userId);
                $stmt = $db->prepare("INSERT INTO wallet_accounts (user_id, account_type, account_number, tier_limit) VALUES (?, 'float', ?, 999999999999)");
                $stmt->execute([$userId, $floatAccount]);
                
                $agentCode = generateAgentCode($userId);
                $stmt = $db->prepare("INSERT INTO agent_details (user_id, agent_code, business_name, super_agent_id) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $userId, $agentCode, 
                    $userData['business_name'] ?? ($userData['first_name'] . ' ' . $userData['last_name']),
                    $userData['super_agent_id'] ?? null
                ]);
            }
            
            logActivity('users', $userId, 'REGISTER', [], ['phone' => $phoneNumber, 'type' => $userType]);
            sendSMSNotification($phoneNumber, 'Barka da zuwa NigerPay! An yi nasarar ƙirƙirar asusunka.', 'system');
            
            return ['success' => true, 'message' => 'An yi nasarar ƙirƙirar asusu', 'user_id' => $userId];
        });
    } catch (Exception $e) {
        logError('Registration error: ' . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
?>