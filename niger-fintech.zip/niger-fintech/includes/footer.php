<?php
/**
 * Niger Fintech System - Footer Template
 */
?>
    </main>
    
    <!-- Footer (desktop only) -->
    <footer class="hidden md:block bg-gray-900 text-gray-400 py-8 mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <!-- Brand -->
                <div>
                    <div class="flex items-center space-x-2 mb-4">
                        <div class="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                            <i class="fas fa-wallet text-white"></i>
                        </div>
                        <span class="text-white font-bold text-lg">NigerPay</span>
                    </div>
                    <p class="text-sm">Système financier mobile sécurisé pour le Niger. Transferts, paiements et services financiers.</p>
                </div>
                
                <!-- Quick Links -->
                <div>
                    <h4 class="text-white font-semibold mb-4">Liens Rapides</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="/" class="hover:text-white transition">Accueil</a></li>
                        <li><a href="/about.php" class="hover:text-white transition">À propos</a></li>
                        <li><a href="/services.php" class="hover:text-white transition">Services</a></li>
                        <li><a href="/contact.php" class="hover:text-white transition">Contact</a></li>
                    </ul>
                </div>
                
                <!-- Services -->
                <div>
                    <h4 class="text-white font-semibold mb-4">Services</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="#" class="hover:text-white transition">Transferts P2P</a></li>
                        <li><a href="#" class="hover:text-white transition">Paiements marchands</a></li>
                        <li><a href="#" class="hover:text-white transition">Factures</a></li>
                        <li><a href="#" class="hover:text-white transition">Recharge crédit</a></li>
                    </ul>
                </div>
                
                <!-- Contact -->
                <div>
                    <h4 class="text-white font-semibold mb-4">Contact</h4>
                    <ul class="space-y-2 text-sm">
                        <li><i class="fas fa-phone mr-2"></i> +227 XX XX XX XX</li>
                        <li><i class="fas fa-envelope mr-2"></i> support@nigerpay.ne</li>
                        <li><i class="fas fa-map-marker-alt mr-2"></i> Niamey, Niger</li>
                    </ul>
                    <div class="flex space-x-4 mt-4">
                        <a href="#" class="text-gray-400 hover:text-white transition"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white transition"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white transition"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
            </div>
            
            <div class="border-t border-gray-800 mt-8 pt-8 text-sm text-center">
                <p>&copy; <?php echo date('Y'); ?> NigerPay. Tous droits réservés. | 
                    <a href="/terms.php" class="hover:text-white">Conditions d'utilisation</a> | 
                    <a href="/privacy.php" class="hover:text-white">Politique de confidentialité</a>
                </p>
                <p class="mt-2 text-xs">Système conforme aux réglementations BCEAO et UEMOA.</p>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script>
        // Toggle user menu dropdown
        function toggleUserMenu() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('hidden');
        }
        
        // Toggle language menu dropdown
        function toggleLangMenu() {
            const dropdown = document.getElementById('langDropdown');
            dropdown.classList.toggle('hidden');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const menu = document.getElementById('userMenu');
            const dropdown = document.getElementById('userDropdown');
            if (menu && !menu.contains(event.target)) {
                dropdown?.classList.add('hidden');
            }

            const langMenu = document.getElementById('langMenu');
            const langDropdown = document.getElementById('langDropdown');
            if (langMenu && !langMenu.contains(event.target)) {
                langDropdown?.classList.add('hidden');
            }
        });
        
        // Format amount input
        function formatAmountInput(input) {
            let value = input.value.replace(/[^\d]/g, '');
            if (value) {
                value = parseInt(value).toLocaleString('fr-FR');
            }
            input.value = value;
        }
        
        // Format phone number input
        function formatPhoneInput(input) {
            let value = input.value.replace(/[^\d]/g, '');
            if (value.length >= 8) {
                value = value.replace(/(\d{2})(\d{2})(\d{2})(\d{2})/, '$1 $2 $3 $4');
            }
            input.value = value;
        }
        
        // Show loading state on form submit
        function showLoading(button, text = 'Traitement...') {
            button.disabled = true;
            button.dataset.originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>' + text;
        }
        
        function hideLoading(button) {
            button.disabled = false;
            button.innerHTML = button.dataset.originalText;
        }
        
        // Confirm action
        function confirmAction(message) {
            return confirm(message);
        }
        
        // Copy to clipboard
        function copyToClipboard(text, button) {
            navigator.clipboard.writeText(text).then(function() {
                const originalText = button.innerHTML;
                button.innerHTML = '<i class="fas fa-check mr-1"></i> Copié';
                setTimeout(() => {
                    button.innerHTML = originalText;
                }, 2000);
            });
        }
        
        // Auto-hide flash messages
        document.addEventListener('DOMContentLoaded', function() {
            const flashMessages = document.querySelectorAll('.fade-in');
            flashMessages.forEach(function(msg) {
                setTimeout(function() {
                    msg.style.opacity = '0';
                    msg.style.transform = 'translateY(-10px)';
                    setTimeout(function() {
                        msg.remove();
                    }, 300);
                }, 5000);
            });
        });
        
        // PIN input handling
        function setupPinInput(input) {
            input.addEventListener('input', function(e) {
                this.value = this.value.replace(/[^0-9]/g, '').slice(0, 6);
            });
        }
        
        // Amount quick select
        function selectAmount(amount, inputId) {
            document.getElementById(inputId).value = amount.toLocaleString('fr-FR');
        }
        
        // Confirm before leaving page with unsaved changes
        let formChanged = false;
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('change', () => formChanged = true);
                form.addEventListener('submit', () => formChanged = false);
            });
        });
        
        window.addEventListener('beforeunload', function(e) {
            if (formChanged) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
    </script>
</body>
</html>
