<?php
/**
 * Niger Fintech System - Test User Generator
 * Run this script ONCE in your browser to populate test users.
 */

require_once __DIR__ . '/includes/auth.php'; // Loads DB and helper functions

$db = getDB();

// The default PIN for all test users will be 123456
$defaultPin = '123456';
$pinHash = hashPIN($defaultPin);

// Array of test users to create
$testUsers = [
    [
        'phone' => '+22790000000',
        'first_name' => 'System',
        'last_name' => 'Admin',
        'type' => 'admin',
        'tier' => 4
    ],
    [
        'phone' => '+22791111111',
        'first_name' => 'Garba',
        'last_name' => 'SuperAgent',
        'type' => 'super_agent',
        'tier' => 4
    ],
    [
        'phone' => '+22792222222',
        'first_name' => 'Fatima',
        'last_name' => 'Agent',
        'type' => 'agent',
        'tier' => 3
    ],
    [
        'phone' => '+22793333333',
        'first_name' => 'Moussa',
        'last_name' => 'Customer',
        'type' => 'customer',
        'tier' => 1
    ],
    [
        'phone' => '+22794444444',
        'first_name' => 'Aisha',
        'last_name' => 'Customer',
        'type' => 'customer',
        'tier' => 2
    ]
];

echo "<h2>Generating Test Users...</h2>";

try {
    $db->beginTransaction();

    // Clear old test data (Optional, removes previous test users)
    $db->exec("DELETE FROM users WHERE phone_number LIKE '+2279%'");

    foreach ($testUsers as $u) {
        // 1. Insert User
        $stmt = $db->prepare("
            INSERT INTO users (phone_number, pin_hash, user_type, kyc_tier, kyc_status, first_name, last_name, is_active, created_at) 
            VALUES (?, ?, ?, ?, 'approved', ?, ?, TRUE, NOW())
        ");
        $stmt->execute([$u['phone'], $pinHash, $u['type'], $u['tier'], $u['first_name'], $u['last_name']]);
        
        $userId = $db->lastInsertId();
        
        // 2. Create Primary Wallet
        $primaryAccount = generateAccountNumber('PRM', $userId);
        $stmt = $db->prepare("INSERT INTO wallet_accounts (user_id, account_type, account_number, balance, available_balance, tier_limit) VALUES (?, 'primary', ?, 50000, 50000, 999999999)");
        $stmt->execute([$userId, $primaryAccount]);

        // 3. Create Agent-specific wallets if necessary
        if ($u['type'] === 'agent' || $u['type'] === 'super_agent') {
            $comAccount = generateAccountNumber('COM', $userId);
            $fltAccount = generateAccountNumber('FLT', $userId);
            
            $db->prepare("INSERT INTO wallet_accounts (user_id, account_type, account_number, balance, available_balance, tier_limit) VALUES (?, 'commission', ?, 0, 0, 999999999)")->execute([$userId, $comAccount]);
            $db->prepare("INSERT INTO wallet_accounts (user_id, account_type, account_number, balance, available_balance, tier_limit) VALUES (?, 'float', ?, 250000, 250000, 999999999)")->execute([$userId, $fltAccount]);
            
            // Add Agent Details
            $agentCode = generateAgentCode($userId);
            $db->prepare("INSERT INTO agent_details (user_id, agent_code, business_name) VALUES (?, ?, ?)")->execute([$userId, $agentCode, $u['first_name'] . ' Shop']);
        }

        echo "<p>✅ Created <strong>{$u['type']}</strong>: {$u['phone']} (PIN: $defaultPin)</p>";
    }

    $db->commit();
    echo "<h3 style='color: green;'>Seeding Complete! You can now test the login page.</h3>";
    echo "<a href='/login.php'>Go to Login</a>";

} catch (Exception $e) {
    $db->rollBack();
    echo "<h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
}
?>