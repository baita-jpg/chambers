<?php
/**
 * Niger Fintech System - Landing Page
 */

require_once __DIR__ . '/includes/functions.php';

// Redirect to dashboard if logged in
if (isLoggedIn()) {
    $user = getCurrentUser();
    switch ($user['user_type']) {
        case 'admin':
            header('Location: admin/dashboard.php');
            break;
        case 'agent':
        case 'super_agent':
            header('Location: agent/dashboard.php');
            break;
        default:
            header('Location: customer/dashboard.php');
    }
    exit;
}

$pageTitle = 'NigerPay - Tsarin Kuɗi na Wayar Hannu';
?>
<!DOCTYPE html>
<html lang="ha">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
                    colors: {
                        primary: { 50: '#f0fdfa', 100: '#ccfbf1', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e', 800: '#115e59' },
                        secondary: { 500: '#f97316', 600: '#ea580c' }
                    }
                }
            }
        }
    </script>
</head>
<body class="font-sans antialiased">
    <!-- Navigation -->
    <nav class="bg-white shadow-sm sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center mr-3">
                        <i class="fas fa-wallet text-white text-xl"></i>
                    </div>
                    <span class="text-xl font-bold text-gray-900">NigerPay</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="login.php" class="text-gray-600 hover:text-gray-900 font-medium">Shiga</a>
                    <a href="register.php" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg font-medium transition">Bude Asusun</a>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Hero Section -->
    <section class="bg-gradient-to-br from-primary-700 via-primary-800 to-primary-900 text-white py-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                    <h1 class="text-4xl md:text-5xl font-extrabold mb-6 leading-tight" lang="ha">
                        Jakar kuɗin ku ta wayar hannu a Nijar
                    </h1>
                    <p class="text-xl text-primary-100 mb-8" lang="ha">
                        Aika kuɗi, biya kuɗaɗenku kuma sarrafa kuɗin ku cikin aminci. 
                        Akwai 24/7, koda da karancin hanyar sadarwa.
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a href="register.php" class="bg-white text-primary-700 px-8 py-4 rounded-xl font-semibold text-center hover:bg-primary-50 transition" lang="ha">
                            <i class="fas fa-user-plus mr-2"></i> Bude Asusun
                        </a>
                        <a href="tel:*123#" class="bg-primary-600 border-2 border-white text-white px-8 py-4 rounded-xl font-semibold text-center hover:bg-primary-500 transition" lang="ha">
                            <i class="fas fa-mobile-alt mr-2"></i> Yi amfani da USSD *123#
                        </a>
                    </div>
                    <div class="mt-8 flex items-center text-primary-100 text-sm">
                        <i class="fas fa-shield-alt mr-2"></i>
                        <span lang="ha">Aminceccen kuma ya dace da ka'idojin BCEAO</span>
                    </div>
                </div>
                <div class="hidden lg:block">
                    <div class="relative">
                        <div class="absolute -inset-4 bg-white/10 rounded-3xl blur-xl"></div>
                        <div class="relative bg-white rounded-3xl p-6 shadow-2xl">
                            <div class="flex items-center justify-between mb-6">
                                <div lang="ha">
                                    <p class="text-gray-500 text-sm">Kuɗin da ke akwai</p>
                                    <p class="text-3xl font-bold text-gray-900">250 000 FCFA</p>
                                </div>
                                <div class="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                                    <i class="fas fa-wallet text-primary-600 text-xl"></i>
                                </div>
                            </div>
                            <div class="grid grid-cols-4 gap-3">
                                <div class="text-center" lang="ha">
                                    <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                                        <i class="fas fa-paper-plane text-blue-600"></i>
                                    </div>
                                    <span class="text-xs text-gray-600">Aika</span>
                                </div>
                                <div class="text-center" lang="ha">
                                    <div class="w-12 h-12 bg-success-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                                        <i class="fas fa-arrow-down text-success-600"></i>
                                    </div>
                                    <span class="text-xs text-gray-600">Saka Kuɗi</span>
                                </div>
                                <div class="text-center" lang="ha">
                                    <div class="w-12 h-12 bg-danger-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                                        <i class="fas fa-arrow-up text-danger-600"></i>
                                    </div>
                                    <span class="text-xs text-gray-600">Cire Kuɗi</span>
                                </div>
                                <div class="text-center" lang="ha">
                                    <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                                        <i class="fas fa-qrcode text-purple-600"></i>
                                    </div>
                                    <span class="text-xs text-gray-600">Biya</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Features Section -->
    <section class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16" lang="ha">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Ayyukanmu</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">Hanyoyin samar da kuɗi da aka tsara don bukatun 'yan Nijar, wanda aka kirkira don aiki a kowane yanayi.</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition" lang="ha">
                    <div class="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                        <i class="fas fa-exchange-alt text-blue-600 text-2xl"></i>
                    </div>
                    <h3 class="font-semibold text-gray-900 mb-2">Tura Kuɗi (P2P)</h3>
                    <p class="text-gray-600 text-sm">Aika kuɗi nan take ga kowa a Nijar, 24/7.</p>
                </div>
                
                <div class="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition" lang="ha">
                    <div class="w-14 h-14 bg-success-100 rounded-xl flex items-center justify-center mb-4">
                        <i class="fas fa-store text-success-600 text-2xl"></i>
                    </div>
                    <h3 class="font-semibold text-gray-900 mb-2">Saka Kuɗi / Cire Kuɗi</h3>
                    <p class="text-gray-600 text-sm">Saka ko cire kuɗi a wurin sama da wakilai 10,000 a fadin kasar.</p>
                </div>
                
                <div class="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition" lang="ha">
                    <div class="w-14 h-14 bg-secondary-100 rounded-xl flex items-center justify-center mb-4">
                        <i class="fas fa-file-invoice-dollar text-secondary-600 text-2xl"></i>
                    </div>
                    <h3 class="font-semibold text-gray-900 mb-2">Biyan Kuɗaɗe</h3>
                    <p class="text-gray-600 text-sm">Biya kuɗin wutar lantarki, ruwa, da sauran kuɗaɗe cikin sauki.</p>
                </div>
                
                <div class="bg-white rounded-2xl p-6 shadow-sm hover:shadow-lg transition" lang="ha">
                    <div class="w-14 h-14 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                        <i class="fas fa-mobile-alt text-purple-600 text-2xl"></i>
                    </div>
                    <h3 class="font-semibold text-gray-900 mb-2">USSD *123#</h3>
                    <p class="text-gray-600 text-sm">Samu damar ayyukanmu ba tare da intanet ba. Kawai danna *123#.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Stats Section -->
    <section class="py-20 bg-primary-700 text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center" lang="ha">
                <div>
                    <p class="text-4xl font-bold mb-2">500K+</p>
                    <p class="text-primary-100">Masu amfani</p>
                </div>
                <div>
                    <p class="text-4xl font-bold mb-2">10K+</p>
                    <p class="text-primary-100">Wakilai</p>
                </div>
                <div>
                    <p class="text-4xl font-bold mb-2">50M+</p>
                    <p class="text-primary-100">Ma'amaloli/shekara</p>
                </div>
                <div>
                    <p class="text-4xl font-bold mb-2">99.9%</p>
                    <p class="text-primary-100">Samuwar Aiki</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Agent Network Section -->
    <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center" lang="ha">
                <div>
                    <h2 class="text-3xl font-bold text-gray-900 mb-4">Zama Wakilin NigerPay</h2>
                    <p class="text-gray-600 mb-6">Shiga cikin jerin wakilanmu kuma sami kudin shiga ta hanyar taimaka wa al'ummarka samun damar ayyukan kuɗi.</p>
                    
                    <ul class="space-y-4 mb-8">
                        <li class="flex items-start">
                            <div class="w-6 h-6 bg-success-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                                <i class="fas fa-check text-success-600 text-xs"></i>
                            </div>
                            <span class="text-gray-700">Kwamiti mai tsoka akan kowace ma'amala</span>
                        </li>
                        <li class="flex items-start">
                            <div class="w-6 h-6 bg-success-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                                <i class="fas fa-check text-success-600 text-xs"></i>
                            </div>
                            <span class="text-gray-700">Horarwa kyauta da tallafi mai dorewa</span>
                        </li>
                        <li class="flex items-start">
                            <div class="w-6 h-6 bg-success-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                                <i class="fas fa-check text-success-600 text-xs"></i>
                            </div>
                            <span class="text-gray-700">Manhajar wayar hannu mai sauƙi da sauri</span>
                        </li>
                        <li class="flex items-start">
                            <div class="w-6 h-6 bg-success-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                                <i class="fas fa-check text-success-600 text-xs"></i>
                            </div>
                            <span class="text-gray-700">Ci gaba zuwa Babban Wakili</span>
                        </li>
                    </ul>
                    
                    <a href="agent-register.php" class="inline-block bg-primary-600 hover:bg-primary-700 text-white px-8 py-3 rounded-xl font-semibold transition">
                        Zama Wakili
                    </a>
                </div>
                <div class="bg-gray-100 rounded-3xl p-8" lang="ha">
                    <div class="bg-white rounded-2xl p-6 shadow-lg">
                        <h3 class="font-semibold text-gray-900 mb-4">Kalkuletar Kuɗin Shiga</h3>
                        <div class="space-y-4">
                            <div>
                                <label class="text-sm text-gray-600">Ma'amaloli a kowace rana</label>
                                <input type="range" min="10" max="200" value="50" class="w-full mt-1" id="transactionRange" oninput="updateRevenue()">
                                <p class="text-right text-sm font-medium text-primary-600"><span id="transactionCount">50</span> ma'amaloli</p>
                            </div>
                            <div class="border-t pt-4">
                                <p class="text-sm text-gray-600">Kiyasin kuɗin shiga na wata</p>
                                <p class="text-3xl font-bold text-gray-900" id="monthlyRevenue">75 000 FCFA</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-12" lang="ha">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                <div>
                    <div class="flex items-center mb-4">
                        <div class="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center mr-2">
                            <i class="fas fa-wallet text-white"></i>
                        </div>
                        <span class="text-white font-bold text-lg">NigerPay</span>
                    </div>
                    <p class="text-sm">Tsarin kuɗi na wayar hannu mai aminci ga Nijar. Aika kuɗi, biyan kuɗi da ayyukan kuɗi.</p>
                </div>
                
                <div>
                    <h4 class="text-white font-semibold mb-4">Ayyuka</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="#" class="hover:text-white transition">Tura Kuɗi (P2P)</a></li>
                        <li><a href="#" class="hover:text-white transition">Saka/Cire Kuɗi</a></li>
                        <li><a href="#" class="hover:text-white transition">Biyan Kuɗaɗe</a></li>
                        <li><a href="#" class="hover:text-white transition">Sayen Kati</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-white font-semibold mb-4">Kamfani</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="#" class="hover:text-white transition">Game da Mu</a></li>
                        <li><a href="#" class="hover:text-white transition">Zama Wakili</a></li>
                        <li><a href="#" class="hover:text-white transition">Ayyuka</a></li>
                        <li><a href="#" class="hover:text-white transition">Tuntuɓe Mu</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-white font-semibold mb-4">Tuntuɓa</h4>
                    <ul class="space-y-2 text-sm">
                        <li><i class="fas fa-phone mr-2"></i> +227 XX XX XX XX</li>
                        <li><i class="fas fa-envelope mr-2"></i> support@nigerpay.ne</li>
                        <li><i class="fas fa-map-marker-alt mr-2"></i> Niamey, Niger</li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-gray-800 pt-8 text-sm text-center">
                <p>&copy; <?php echo date('Y'); ?> NigerPay. An adana duk haƙƙoƙi. | 
                    <a href="/terms.php" class="hover:text-white">Sharuɗɗa</a> | 
                    <a href="/privacy.php" class="hover:text-white">Sirri</a>
                </p>
                <p class="mt-2 text-xs">Tsarin ya dace da ka'idojin BCEAO da UEMOA.</p>
            </div>
        </div>
    </footer>
    
    <script>
        function updateRevenue() {
            const transactions = document.getElementById('transactionRange').value;
            const avgCommission = 150; // Average commission per transaction in FCFA
            const monthlyRevenue = transactions * avgCommission * 30;
            
            document.getElementById('transactionCount').textContent = transactions;
            document.getElementById('monthlyRevenue').textContent = monthlyRevenue.toLocaleString('fr-FR') + ' FCFA';
        }
    </script>
</body>
</html>
