<?php
/**
 * Niger Fintech System - Forgot PIN Page
 */

require_once __DIR__ . '/includes/auth.php';

$currentLang = getCurrentLanguage();
$error = '';
$success = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = ($currentLang === 'ha') ? 'Zama mara inganci. Da fatan za a sake gwadawa.' : 'Session invalide. Veuillez réessayer.';
    } else {
        $phone = sanitizeInput($_POST['phone'] ?? '');

        if (empty($phone) || !validatePhoneNumber($phone)) {
            $error = ($currentLang === 'ha') ? 'Da fatan za a shigar da ingantacciyar lambar waya.' : 'Veuillez saisir un numéro de téléphone valide.';
        } else {
            $db = getDB();
            $formattedPhone = formatPhoneNumber($phone);
            $stmt = $db->prepare("SELECT id FROM users WHERE phone_number = ? AND is_active = TRUE");
            $stmt->execute([$formattedPhone]);
            $user = $stmt->fetch();

            if ($user) {
                // User exists, generate OTP and redirect
                generateOTP($formattedPhone);
                
                startSecureSession();
                $_SESSION['reset_pending_phone'] = $formattedPhone;

                header('Location: reset-pin.php');
                exit;
            } else {
                // To prevent user enumeration, show a generic message
                $success = ($currentLang === 'ha') ? 'Idan asusunka ya wanzu, za a aiko da umarnin sake saiti.' : 'Si votre compte existe, des instructions de réinitialisation seront envoyées.';
            }
        }
    }
}

$pageTitle = ($currentLang === 'ha') ? 'Manta PIN - NigerPay' : 'PIN Oublié - NigerPay';
?>
<!DOCTYPE html>
<html <?php echo getLangAttribute(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <div class="text-center mb-6">
            <a href="/" class="inline-block">
                <div class="w-16 h-16 bg-primary-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                    <i class="fas fa-wallet text-white text-2xl"></i>
                </div>
            </a>
            <h1 class="text-2xl font-bold text-gray-900"><?php echo ($currentLang === 'ha') ? 'Sake saita PIN ɗinka' : 'Réinitialisez votre PIN'; ?></h1>
            <p class="text-gray-600 mt-2"><?php echo ($currentLang === 'ha') ? 'Shigar da lambar wayarka don karɓar lambar tantancewa.' : 'Entrez votre numéro de téléphone pour recevoir un code de vérification.'; ?></p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-8">
            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-6">
                <?php csrfField(); ?>
                <div>
                    <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">
                        <?php echo ($currentLang === 'ha') ? 'Lambar Waya' : 'Numéro de téléphone'; ?>
                    </label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-phone text-gray-400"></i>
                        </div>
                        <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required placeholder="XX XX XX XX" class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition text-lg">
                    </div>
                </div>

                <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-200">
                    <?php echo ($currentLang === 'ha') ? 'Aika Lambar Tabbatarwa' : 'Envoyer le code'; ?>
                </button>
            </form>
        </div>

        <div class="text-center mt-6">
            <a href="login.php" class="text-sm font-medium text-primary-600 hover:text-primary-700">
                <i class="fas fa-arrow-left mr-1"></i>
                <?php echo ($currentLang === 'ha') ? 'Komawa zuwa shiga' : 'Retour à la connexion'; ?>
            </a>
        </div>
    </div>
</body>
</html>