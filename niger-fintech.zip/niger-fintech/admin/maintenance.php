<?php
require_once 'includes/functions.php';
$isHausa = (($_SESSION['lang'] ?? 'ha') === 'ha');
?>
<!DOCTYPE html>
<html lang="<?php echo $isHausa ? 'ha' : 'fr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NigerPay - Maintenance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.5.0/css/all.css">
</head>
<body class="bg-slate-50 flex items-center justify-center min-h-screen p-6">
    <div class="max-w-md w-full text-center space-y-8 bg-white p-12 rounded-[3rem] shadow-2xl border border-slate-100">
        <div class="w-24 h-24 bg-primary-50 text-primary-600 rounded-full flex items-center justify-center text-4xl mx-auto animate-pulse">
            <i class="fas fa-tools"></i>
        </div>
        
        <div class="space-y-4">
            <h1 class="text-3xl font-black text-slate-900 tracking-tight">
                <?php echo $isHausa ? 'Gyaran Tsari' : 'Maintenance en cours'; ?>
            </h1>
            <p class="text-slate-500 font-medium leading-relaxed">
                <?php echo $isHausa 
                    ? 'Muna gyara tsarin mu domin inganta ayyukan mu. Zamu dawo nan ba da jimawa ba.' 
                    : 'Nous mettons à jour notre système pour mieux vous servir. Nous serons de retour sous peu.'; ?>
            </p>
        </div>

        <div class="pt-8 border-t border-slate-50">
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">NigerPay Central Support</p>
            <p class="text-sm font-bold text-slate-900 mt-2">+227 00 00 00 00</p>
        </div>
    </div>
</body>
</html>