<?php
/**
 * NigerPay - Global System Settings
 */
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$message = '';

// Handle Settings Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRFToken($_POST['csrf_token'] ?? '')) {
    foreach ($_POST['config'] as $key => $value) {
        $stmt = $db->prepare("UPDATE system_config SET config_value = ? WHERE config_key = ?");
        $stmt->execute([sanitizeInput($value), $key]);
    }
    $message = $isHausa ? "An sabunta saitunan nasara!" : "Paramètres mis à jour avec succès !";
}

// Group settings by category (using a naming convention like float_xxx, fee_xxx)
$settings = $db->query("SELECT * FROM system_config ORDER BY config_key ASC")->fetchAll();

$pageTitle = $isHausa ? 'Saitunan Tsarin' : 'Configuration Système';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-4xl mx-auto pb-20">
    <div class="mb-10">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $pageTitle; ?></h1>
        <p class="text-slate-500 font-medium">Configure global thresholds, fees, and operational limits.</p>
    </div>

    <?php if($message): ?>
        <div class="bg-green-50 text-green-700 p-6 rounded-2xl mb-8 font-bold flex items-center shadow-sm">
            <i class="fas fa-check-circle mr-3"></i> <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-8">
        <?php csrfField(); ?>

        <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
            <div class="px-8 py-6 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
                <h3 class="text-xs font-black text-white uppercase tracking-widest">
                    <i class="fas fa-hammer mr-2 text-primary-500"></i> Critical Operations
                </h3>
                <span class="text-[9px] font-black bg-red-500 text-white px-2 py-0.5 rounded">ADMIN ONLY</span>
            </div>
            <div class="p-8">
                <div class="flex items-center justify-between">
                    <div class="max-w-md">
                        <label class="block text-sm font-black text-slate-900">Maintenance Mode</label>
                        <p class="text-[10px] text-slate-400 font-bold italic">
                            Turning this ON will immediately log out all Customers and Agents and show a maintenance screen.
                        </p>
                    </div>
                    <div class="flex items-center">
                        <?php $mMode = getConfig('maintenance_mode', '0'); ?>
                        <select name="config[maintenance_mode]" class="px-6 py-3 <?php echo $mMode == '1' ? 'bg-red-50 text-red-600 border-red-100' : 'bg-slate-50 text-slate-900 border-slate-100'; ?> border-2 rounded-xl font-black text-xs transition-all">
                            <option value="0" <?php echo $mMode == '0' ? 'selected' : ''; ?>>OFF (System Live)</option>
                            <option value="1" <?php echo $mMode == '1' ? 'selected' : ''; ?>>ON (System Locked)</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
            <div class="px-8 py-6 bg-slate-50 border-b border-slate-100">
                <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest">
                    <i class="fas fa-bell mr-2"></i> <?php echo $isHausa ? 'Iyakoki & Fadakarwa' : 'Seuils & Alertes'; ?>
                </h3>
            </div>
            <div class="p-8 space-y-6">
                <?php foreach($settings as $s): if(str_contains($s['config_key'], 'limit') || str_contains($s['config_key'], 'threshold')): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                    <div>
                        <label class="block text-sm font-black text-slate-900 capitalize">
                            <?php echo str_replace('_', ' ', $s['config_key']); ?>
                        </label>
                        <p class="text-[10px] text-slate-400 font-bold"><?php echo $s['description']; ?></p>
                    </div>
                    <input type="text" name="config[<?php echo $s['config_key']; ?>]" 
                           value="<?php echo htmlspecialchars($s['config_value']); ?>" 
                           class="w-full px-6 py-3 bg-slate-50 border-2 border-slate-50 rounded-xl font-mono font-bold text-primary-600 focus:border-primary-500 transition-all">
                </div>
                <?php endif; endforeach; ?>
            </div>
        </div>

        <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
            <div class="px-8 py-6 bg-slate-50 border-b border-slate-100">
                <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest">
                    <i class="fas fa-percent mr-2"></i> <?php echo $isHausa ? 'Kudaden Ma\'amala' : 'Frais de Transaction'; ?>
                </h3>
            </div>
            <div class="p-8 space-y-6">
                <?php foreach($settings as $s): if(str_contains($s['config_key'], 'fee') || str_contains($s['config_key'], 'rate')): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                    <div>
                        <label class="block text-sm font-black text-slate-900 capitalize">
                            <?php echo str_replace('_', ' ', $s['config_key']); ?>
                        </label>
                        <p class="text-[10px] text-slate-400 font-bold"><?php echo $s['description']; ?></p>
                    </div>
                    <div class="relative">
                        <input type="text" name="config[<?php echo $s['config_key']; ?>]" 
                               value="<?php echo htmlspecialchars($s['config_value']); ?>" 
                               class="w-full px-6 py-3 bg-slate-50 border-2 border-slate-50 rounded-xl font-mono font-bold text-slate-900 focus:border-primary-500 transition-all">
                        <span class="absolute right-6 top-1/2 -translate-y-1/2 text-[10px] font-black text-slate-300">% / XOF</span>
                    </div>
                </div>
                <?php endif; endforeach; ?>
            </div>
        </div>

        <button type="submit" class="w-full bg-slate-900 text-white font-black py-5 rounded-3xl shadow-xl hover:bg-primary-600 transition-all uppercase tracking-widest">
            <?php echo $isHausa ? 'Ajiye Canje-canje' : 'Enregistrer les modifications'; ?>
        </button>
    </form>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>