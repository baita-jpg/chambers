<?php
/**
 * NigerPay - Float Top-up Processor (AJAX)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRFToken($_POST['csrf_token'])) {
    $agentId = (int)$_POST['agent_id'];
    $amount  = (float)$_POST['amount'];
    $adminId = $_SESSION['user_id'];

    try {
        $result = executeInTransaction(function($db) use ($agentId, $amount, $adminId) {
            // 1. Credit Agent Float Wallet
            $stmt = $db->prepare("UPDATE wallet_accounts SET balance = balance + ?, available_balance = available_balance + ? WHERE user_id = ? AND account_type = 'float'");
            $stmt->execute([$amount, $amount, $agentId]);

            // 2. Record Transaction
            $txId = generateTransactionID('TOP');
            $stmt = $db->prepare("INSERT INTO transactions (transaction_id, transaction_type, sender_user_id, receiver_user_id, amount, status, created_at) VALUES (?, 'float_topup', ?, ?, ?, 'completed', NOW())");
            $stmt->execute([$txId, $adminId, $agentId, $amount]);

            return true;
        });

        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

?>