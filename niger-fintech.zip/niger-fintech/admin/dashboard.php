<?php
/**
 * Niger Fintech System - Advanced Admin Dashboard
 */

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/auth.php';

// Robust Role-Based Authentication
if (!isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

$currentUser = getCurrentUser();
if (!$currentUser || $currentUser['user_type'] !== 'admin') {
    $redirect = ($currentUser['user_type'] === 'agent' || $currentUser['user_type'] === 'super_agent') ? '/agent/dashboard.php' : '/customer/dashboard.php';
    header("Location: $redirect");
    exit;
}

$db = getDB();
$stats = [
    'users' => ['total' => 0, 'customers' => 0, 'agents' => 0, 'super_agents' => 0],
    'today' => ['count' => 0, 'volume' => 0, 'fees' => 0, 'commissions' => 0],
    'yesterday' => ['count' => 0, 'volume' => 0, 'fees' => 0],
    'pending_kyc' => 0, 'pending_liquidity' => 0, 'fraud_alerts' => 0
];
$recentTransactions = [];
$chartData = [];
$typeDistribution = [];

try {
    // Total users breakdown
    $stmt = $db->query("SELECT COUNT(*) as total, 
        SUM(CASE WHEN user_type = 'customer' THEN 1 ELSE 0 END) as customers,
        SUM(CASE WHEN user_type = 'agent' THEN 1 ELSE 0 END) as agents,
        SUM(CASE WHEN user_type = 'super_agent' THEN 1 ELSE 0 END) as super_agents
        FROM users WHERE is_active = TRUE");
    if ($row = $stmt->fetch()) $stats['users'] = $row;

    // Today's transactions
    $stmt = $db->query("SELECT COUNT(*) as count, SUM(amount) as volume, SUM(fee_amount) as fees, SUM(commission_amount) as commissions
        FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'completed'");
    if ($row = $stmt->fetch()) $stats['today'] = $row;

    // Yesterday's transactions for Trend Comparison
    $stmt = $db->query("SELECT COUNT(*) as count, SUM(amount) as volume, SUM(fee_amount) as fees
        FROM transactions WHERE DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY) AND status = 'completed'");
    if ($row = $stmt->fetch()) $stats['yesterday'] = $row;

    // Pending Actionable Items
    try {
        $stats['pending_kyc'] = $db->query("SELECT COUNT(*) as pending FROM users WHERE kyc_status = 'pending'")->fetch()['pending'] ?? 0;
        $stats['pending_liquidity'] = $db->query("SELECT COUNT(*) as pending FROM liquidity_movements WHERE status = 'pending'")->fetch()['pending'] ?? 0;
        $stats['fraud_alerts'] = $db->query("SELECT COUNT(*) as open FROM fraud_alerts WHERE status = 'open'")->fetch()['open'] ?? 0;
    } catch (PDOException $e) { /* Ignore if tables not seeded */ }

    // Recent transactions
    $stmt = $db->query("
        SELECT t.*, sender.first_name as s_fname, sender.last_name as s_lname, receiver.first_name as r_fname, receiver.last_name as r_lname
        FROM transactions t
        LEFT JOIN users sender ON t.sender_user_id = sender.id
        LEFT JOIN users receiver ON t.receiver_user_id = receiver.id
        ORDER BY t.created_at DESC LIMIT 6
    ");
    $recentTransactions = $stmt->fetchAll();

    // 30-Day Line Chart Data
    $stmt = $db->query("
        SELECT DATE(created_at) as date, COUNT(*) as count, SUM(amount) as volume
        FROM transactions WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND status = 'completed'
        GROUP BY DATE(created_at) ORDER BY date
    ");
    $chartData = $stmt->fetchAll();

    // Transaction Type Distribution (Doughnut Chart)
    $stmt = $db->query("
        SELECT transaction_type, SUM(amount) as volume 
        FROM transactions WHERE status = 'completed' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY transaction_type
    ");
    $typeDistribution = $stmt->fetchAll();

} catch (PDOException $e) {
    logError("Admin Dashboard DB Error: " . $e->getMessage());
    $dbError = "Akwai matsalar samun bayanai daga rumbun adana bayanai.";
}

// Helper for Trend Calculation
function getTrend($today, $yesterday) {
    if ($yesterday == 0) return ['val' => 100, 'dir' => 'up', 'color' => 'text-green-500', 'bg' => 'bg-green-100'];
    $change = (($today - $yesterday) / $yesterday) * 100;
    $dir = $change >= 0 ? 'up' : 'down';
    $color = $change >= 0 ? 'text-green-500' : 'text-red-500';
    $bg = $change >= 0 ? 'bg-green-100' : 'bg-red-100';
    return ['val' => abs($change), 'dir' => $dir, 'color' => $color, 'bg' => $bg];
}

if (!function_exists('formatAmount')) {
    function formatAmount($amount) { return number_format((float)$amount, 0, ',', ' ') . ' FCFA'; }
}

$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');
$pageTitle = $isHausa ? 'Babban Shafi - NigerPay Admin' : 'Tableau de bord - NigerPay Admin';

include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto pb-10">
    
    <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-8 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <div>
            <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight">
                <?php echo $isHausa ? 'Babban Shafi' : 'Tableau de bord'; ?>
            </h1>
            <p class="text-gray-500 text-sm mt-1 flex items-center">
                <span class="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></span>
                <?php echo $isHausa ? 'Tsarin yana aiki sosai' : 'Système opérationnel'; ?> 
                <span class="mx-2 text-gray-300">|</span> 
                <i class="far fa-calendar-alt mr-1"></i> <?php echo date('d M Y, H:i'); ?>
            </p>
        </div>
        <div class="mt-4 md:mt-0 flex space-x-3">
            <button onclick="window.location.reload();" class="px-4 py-2 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg text-sm font-medium border border-gray-200 transition flex items-center">
                <i class="fas fa-sync-alt mr-2"></i> <?php echo $isHausa ? 'Sabunta' : 'Actualiser'; ?>
            </button>
            <a href="reports.php" class="px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-sm font-medium shadow-sm transition flex items-center">
                <i class="fas fa-download mr-2"></i> <?php echo $isHausa ? 'Fitarwa' : 'Exporter'; ?>
            </a>
        </div>
    </div>

    <?php if (isset($dbError)): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-lg shadow-sm">
            <div class="flex items-center"><i class="fas fa-exclamation-triangle text-red-500 mr-3"></i><p class="text-sm text-red-700 font-medium"><?php echo $dbError; ?></p></div>
        </div>
    <?php endif; ?>
    
    <?php if ($stats['pending_kyc'] > 0 || $stats['pending_liquidity'] > 0 || $stats['fraud_alerts'] > 0): ?>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <?php if ($stats['pending_kyc'] > 0): ?>
        <a href="kyc-pending.php" class="bg-gradient-to-r from-yellow-500 to-yellow-400 rounded-xl p-4 flex items-center shadow-md hover:shadow-lg transition group text-white">
            <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mr-4 backdrop-blur-sm">
                <i class="fas fa-id-card text-2xl"></i>
            </div>
            <div>
                <p class="text-2xl font-bold"><?php echo number_format($stats['pending_kyc']); ?></p>
                <p class="text-sm font-medium text-yellow-50"><?php echo $isHausa ? 'KYC na jiran amincewa' : 'KYC en attente'; ?></p>
            </div>
            <i class="fas fa-arrow-right ml-auto opacity-0 group-hover:opacity-100 transition"></i>
        </a>
        <?php endif; ?>
        
        <?php if ($stats['pending_liquidity'] > 0): ?>
        <a href="liquidity-pending.php" class="bg-gradient-to-r from-blue-500 to-blue-400 rounded-xl p-4 flex items-center shadow-md hover:shadow-lg transition group text-white">
            <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mr-4 backdrop-blur-sm">
                <i class="fas fa-exchange-alt text-2xl"></i>
            </div>
            <div>
                <p class="text-2xl font-bold"><?php echo number_format($stats['pending_liquidity']); ?></p>
                <p class="text-sm font-medium text-blue-50"><?php echo $isHausa ? 'Buƙatun kuɗaɗe' : 'Liquidité en attente'; ?></p>
            </div>
            <i class="fas fa-arrow-right ml-auto opacity-0 group-hover:opacity-100 transition"></i>
        </a>
        <?php endif; ?>
        
        <?php if ($stats['fraud_alerts'] > 0): ?>
        <a href="fraud-alerts.php" class="bg-gradient-to-r from-red-600 to-red-500 rounded-xl p-4 flex items-center shadow-md hover:shadow-lg transition group text-white animate-pulse">
            <div class="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mr-4 backdrop-blur-sm">
                <i class="fas fa-shield-virus text-2xl"></i>
            </div>
            <div>
                <p class="text-2xl font-bold"><?php echo number_format($stats['fraud_alerts']); ?></p>
                <p class="text-sm font-medium text-red-50"><?php echo $isHausa ? 'Matsalolin Tsaro' : 'Alertes de fraude'; ?></p>
            </div>
            <i class="fas fa-arrow-right ml-auto opacity-0 group-hover:opacity-100 transition"></i>
        </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group">
            <div class="absolute -right-6 -top-6 w-24 h-24 bg-blue-50 rounded-full opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            <div class="flex justify-between items-start mb-2 relative z-10">
                <p class="text-gray-500 text-sm font-semibold uppercase tracking-wider"><?php echo $isHausa ? 'Masu Amfani' : 'Utilisateurs'; ?></p>
                <div class="p-2 bg-blue-100 text-blue-600 rounded-lg"><i class="fas fa-users"></i></div>
            </div>
            <h3 class="text-3xl font-black text-gray-900 mb-4 relative z-10"><?php echo number_format($stats['users']['total'] ?? 0); ?></h3>
            <div class="flex justify-between text-xs font-medium text-gray-500 relative z-10 bg-gray-50 rounded-lg p-2">
                <span title="<?php echo $isHausa ? 'Abokan ciniki' : 'Clients'; ?>"><i class="fas fa-user text-gray-400"></i> <?php echo number_format($stats['users']['customers'] ?? 0); ?></span>
                <span title="<?php echo $isHausa ? 'Wakilai' : 'Agents'; ?>"><i class="fas fa-store text-gray-400"></i> <?php echo number_format($stats['users']['agents'] ?? 0); ?></span>
            </div>
        </div>
        
        <?php $volTrend = getTrend($stats['today']['volume'] ?? 0, $stats['yesterday']['volume'] ?? 0); ?>
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group">
            <div class="absolute -right-6 -top-6 w-24 h-24 bg-green-50 rounded-full opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            <div class="flex justify-between items-start mb-2 relative z-10">
                <p class="text-gray-500 text-sm font-semibold uppercase tracking-wider"><?php echo $isHausa ? 'Yawan Kuɗi (Yau)' : 'Volume (Auj)'; ?></p>
                <div class="p-2 bg-green-100 text-green-600 rounded-lg"><i class="fas fa-chart-line"></i></div>
            </div>
            <h3 class="text-3xl font-black text-gray-900 mb-2 relative z-10"><?php echo formatAmount($stats['today']['volume'] ?? 0); ?></h3>
            <div class="flex items-center text-xs font-medium relative z-10">
                <span class="flex items-center px-2 py-1 rounded-md <?php echo $volTrend['bg'] . ' ' . $volTrend['color']; ?>">
                    <i class="fas fa-arrow-<?php echo $volTrend['dir']; ?> mr-1"></i> <?php echo number_format($volTrend['val'], 1); ?>%
                </span>
                <span class="ml-2 text-gray-400"><?php echo $isHausa ? 'vs jiya' : 'vs hier'; ?></span>
            </div>
        </div>
        
        <?php $feeTrend = getTrend($stats['today']['fees'] ?? 0, $stats['yesterday']['fees'] ?? 0); ?>
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group">
            <div class="absolute -right-6 -top-6 w-24 h-24 bg-indigo-50 rounded-full opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            <div class="flex justify-between items-start mb-2 relative z-10">
                <p class="text-gray-500 text-sm font-semibold uppercase tracking-wider"><?php echo $isHausa ? 'Riba (Yau)' : 'Revenus (Auj)'; ?></p>
                <div class="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><i class="fas fa-coins"></i></div>
            </div>
            <h3 class="text-3xl font-black text-gray-900 mb-2 relative z-10"><?php echo formatAmount($stats['today']['fees'] ?? 0); ?></h3>
            <div class="flex items-center text-xs font-medium relative z-10">
                <span class="flex items-center px-2 py-1 rounded-md <?php echo $feeTrend['bg'] . ' ' . $feeTrend['color']; ?>">
                    <i class="fas fa-arrow-<?php echo $feeTrend['dir']; ?> mr-1"></i> <?php echo number_format($feeTrend['val'], 1); ?>%
                </span>
                <span class="ml-2 text-gray-400"><?php echo $isHausa ? 'vs jiya' : 'vs hier'; ?></span>
            </div>
        </div>
        
        <?php $countTrend = getTrend($stats['today']['count'] ?? 0, $stats['yesterday']['count'] ?? 0); ?>
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group">
            <div class="absolute -right-6 -top-6 w-24 h-24 bg-orange-50 rounded-full opacity-50 group-hover:scale-150 transition-transform duration-500"></div>
            <div class="flex justify-between items-start mb-2 relative z-10">
                <p class="text-gray-500 text-sm font-semibold uppercase tracking-wider"><?php echo $isHausa ? 'Ma\'amaloli' : 'Txns (Auj)'; ?></p>
                <div class="p-2 bg-orange-100 text-orange-600 rounded-lg"><i class="fas fa-exchange-alt"></i></div>
            </div>
            <h3 class="text-3xl font-black text-gray-900 mb-2 relative z-10"><?php echo number_format($stats['today']['count'] ?? 0); ?></h3>
            <div class="flex items-center text-xs font-medium relative z-10">
                <span class="flex items-center px-2 py-1 rounded-md <?php echo $countTrend['bg'] . ' ' . $countTrend['color']; ?>">
                    <i class="fas fa-arrow-<?php echo $countTrend['dir']; ?> mr-1"></i> <?php echo number_format($countTrend['val'], 1); ?>%
                </span>
                <span class="ml-2 text-gray-400"><?php echo $isHausa ? 'vs jiya' : 'vs hier'; ?></span>
            </div>
        </div>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        
        <div class="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="font-bold text-gray-800 text-lg"><?php echo $isHausa ? 'Tafiyar Kuɗi (Kwanaki 30)' : 'Tendance de Volume (30j)'; ?></h2>
                <button class="text-gray-400 hover:text-primary-600"><i class="fas fa-ellipsis-h"></i></button>
            </div>
            <div class="relative h-72 w-full">
                <canvas id="mainChart"></canvas>
            </div>
        </div>
        
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h2 class="font-bold text-gray-800 text-lg mb-4"><?php echo $isHausa ? 'Rabe-raben Ma\'amaloli' : 'Répartition par Type'; ?></h2>
            <div class="relative h-56 w-full flex justify-center">
                <canvas id="doughnutChart"></canvas>
            </div>
            <div class="mt-4 pt-4 border-t border-gray-100">
                <a href="reports.php" class="w-full block text-center text-sm font-semibold text-primary-600 hover:text-primary-800 transition">
                    <?php echo $isHausa ? 'Cikakken Rahoto' : 'Rapport Complet'; ?> &rarr;
                </a>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
            <h2 class="font-bold text-gray-800 text-lg"><?php echo $isHausa ? 'Ma\'amalolin Baya-bayan nan' : 'Transactions Récentes'; ?></h2>
            <a href="transactions.php" class="text-sm font-medium text-primary-600 bg-primary-50 px-3 py-1.5 rounded-lg hover:bg-primary-100 transition">
                <?php echo $isHausa ? 'Duba Duk' : 'Voir tout'; ?>
            </a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-white text-gray-400 text-xs uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 font-semibold">T-ID</th>
                        <th class="px-6 py-4 font-semibold"><?php echo $isHausa ? 'Mai aikawa' : 'Expéditeur'; ?></th>
                        <th class="px-6 py-4 font-semibold"><?php echo $isHausa ? 'Mai karɓa' : 'Destinataire'; ?></th>
                        <th class="px-6 py-4 font-semibold text-right"><?php echo $isHausa ? 'Yawa' : 'Montant'; ?></th>
                        <th class="px-6 py-4 font-semibold text-center"><?php echo $isHausa ? 'Matsayi' : 'Statut'; ?></th>
                        <th class="px-6 py-4 font-semibold"><?php echo $isHausa ? 'Kwanan wata' : 'Date'; ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($recentTransactions as $tx): ?>
                    <tr class="hover:bg-blue-50/30 transition">
                        <td class="px-6 py-4 text-xs font-mono text-gray-500"><?php echo substr($tx['transaction_id'], 0, 10); ?>...</td>
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars(trim($tx['s_fname'] . ' ' . $tx['s_lname']) ?: '-'); ?></div>
                            <div class="text-xs text-gray-500"><?php echo htmlspecialchars($tx['sender_phone'] ?? ''); ?></div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars(trim($tx['r_fname'] . ' ' . $tx['r_lname']) ?: '-'); ?></div>
                            <div class="text-xs text-gray-500"><?php echo htmlspecialchars($tx['receiver_phone'] ?? ''); ?></div>
                        </td>
                        <td class="px-6 py-4 text-right font-bold text-gray-900"><?php echo formatAmount($tx['amount']); ?></td>
                        <td class="px-6 py-4 text-center">
                            <?php 
                                $statusColors = ['completed' => 'bg-green-100 text-green-700', 'pending' => 'bg-yellow-100 text-yellow-700', 'failed' => 'bg-red-100 text-red-700'];
                                $badgeClass = $statusColors[$tx['status']] ?? 'bg-gray-100 text-gray-700';
                            ?>
                            <span class="px-3 py-1 rounded-full text-xs font-bold <?php echo $badgeClass; ?>">
                                &bull; <?php echo ucfirst($tx['status']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-xs font-medium text-gray-500"><?php echo date('d M, H:i', strtotime($tx['created_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // --- 1. Main Line Chart (Gradient Volume) ---
    <?php if (!empty($chartData)): ?>
    const ctxMain = document.getElementById('mainChart').getContext('2d');
    
    // Create beautiful dynamic gradient
    let gradientFill = ctxMain.createLinearGradient(0, 0, 0, 300);
    gradientFill.addColorStop(0, 'rgba(20, 184, 166, 0.4)'); // Primary color (Teal) fading out
    gradientFill.addColorStop(1, 'rgba(20, 184, 166, 0.0)');

    new Chart(ctxMain, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_map(function($d) { return date('d/m', strtotime($d['date'])); }, $chartData)); ?>,
            datasets: [{
                label: "<?php echo $isHausa ? 'Yawa (FCFA)' : 'Volume (FCFA)'; ?>",
                data: <?php echo json_encode(array_map(function($d) { return $d['volume']; }, $chartData)); ?>,
                borderColor: '#0d9488',
                backgroundColor: gradientFill,
                borderWidth: 3,
                pointBackgroundColor: '#ffffff',
                pointBorderColor: '#0d9488',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                tension: 0.4, // Smooth curves
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { intersect: false, mode: 'index' },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    titleFont: { size: 13, family: 'Inter' },
                    bodyFont: { size: 14, weight: 'bold', family: 'Inter' },
                    padding: 12,
                    callbacks: {
                        label: function(context) { return context.raw.toLocaleString('fr-FR') + ' FCFA'; }
                    }
                }
            },
            scales: {
                x: { grid: { display: false, drawBorder: false } },
                y: {
                    border: { display: false },
                    grid: { color: '#f3f4f6' },
                    ticks: { maxTicksLimit: 6, callback: function(value) { return value >= 1000000 ? (value/1000000).toFixed(1) + 'M' : value.toLocaleString('fr-FR'); } }
                }
            }
        }
    });
    <?php endif; ?>

    // --- 2. Doughnut Chart (Transaction Types) ---
    <?php if (!empty($typeDistribution)): ?>
    const ctxDoughnut = document.getElementById('doughnutChart').getContext('2d');
    
    // Process PHP data into Chart.js arrays
    const typeData = <?php echo json_encode($typeDistribution); ?>;
    const labels = typeData.map(d => d.transaction_type.replace('_', ' ').toUpperCase());
    const data = typeData.map(d => d.volume);
    
    new Chart(ctxDoughnut, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: ['#10b981', '#f59e0b', '#3b82f6', '#8b5cf6', '#6366f1'], // Green, Orange, Blue
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '75%', // Modern thin ring
            plugins: {
                legend: { position: 'bottom', labels: { usePointStyle: true, padding: 20, font: { family: 'Inter', size: 12 } } },
                tooltip: {
                    callbacks: {
                        label: function(context) { return ' ' + context.raw.toLocaleString('fr-FR') + ' FCFA'; }
                    }
                }
            }
        }
    });
    <?php endif; ?>
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>