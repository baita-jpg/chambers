<?php
/**
 * Niger Fintech System - Analytics & Reports
 */
require_once __DIR__ . '/../includes/auth.php';

// Verify Admin Access
if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'admin') {
    header('Location: /login.php');
    exit;
}

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');

if (!function_exists('formatAmount')) {
    function formatAmount($amount) { return number_format((float)$amount, 0, ',', ' ') . ' FCFA'; }
}

// 1. Date Filtering Logic
$startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Validate dates
if ($startDate > $endDate) {
    $temp = $startDate;
    $startDate = $endDate;
    $endDate = $temp;
}

// 2. Export to CSV Logic
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="NigerPay_Report_' . $startDate . '_to_' . $endDate . '.csv"');
    $output = fopen('php://output', 'w');
    
    // Headers
    fputcsv($output, ['Date', 'Transaction Type', 'Count', 'Volume (FCFA)', 'Fees (FCFA)', 'Commissions (FCFA)']);
    
    // Fetch data for export
    $stmt = $db->prepare("
        SELECT DATE(created_at) as date, transaction_type, COUNT(id) as count, 
               SUM(amount) as volume, SUM(fee_amount) as fees, SUM(commission_amount) as commissions
        FROM transactions 
        WHERE status = 'completed' AND DATE(created_at) BETWEEN ? AND ?
        GROUP BY DATE(created_at), transaction_type
        ORDER BY date DESC, transaction_type ASC
    ");
    $stmt->execute([$startDate, $endDate]);
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['date'], 
            str_replace('_', ' ', $row['transaction_type']), 
            $row['count'], 
            $row['volume'] ?? 0, 
            $row['fees'] ?? 0, 
            $row['commissions'] ?? 0
        ]);
    }
    fclose($output);
    exit;
}

// 3. Fetch Dashboard Analytics
$stats = [
    'volume' => 0, 'fees' => 0, 'commissions' => 0, 'tx_count' => 0, 'new_users' => 0
];
$chartData = [];
$typeBreakdown = [];

try {
    // Overall Summary for the selected period
    $stmt = $db->prepare("
        SELECT COUNT(id) as tx_count, SUM(amount) as volume, 
               SUM(fee_amount) as fees, SUM(commission_amount) as commissions 
        FROM transactions 
        WHERE status = 'completed' AND DATE(created_at) BETWEEN ? AND ?
    ");
    $stmt->execute([$startDate, $endDate]);
    if ($row = $stmt->fetch()) {
        $stats = array_merge($stats, $row);
    }

    // New Users in period
    $stmt = $db->prepare("SELECT COUNT(id) as new_users FROM users WHERE DATE(created_at) BETWEEN ? AND ?");
    $stmt->execute([$startDate, $endDate]);
    $stats['new_users'] = $stmt->fetch()['new_users'] ?? 0;

    // Daily Chart Data (Volume & Fees)
    $stmt = $db->prepare("
        SELECT DATE(created_at) as date, SUM(amount) as volume, SUM(fee_amount) as fees
        FROM transactions
        WHERE status = 'completed' AND DATE(created_at) BETWEEN ? AND ?
        GROUP BY DATE(created_at) ORDER BY date ASC
    ");
    $stmt->execute([$startDate, $endDate]);
    $chartData = $stmt->fetchAll();

    // Breakdown by Transaction Type
    $stmt = $db->prepare("
        SELECT transaction_type, COUNT(id) as count, SUM(amount) as volume, SUM(fee_amount) as fees
        FROM transactions
        WHERE status = 'completed' AND DATE(created_at) BETWEEN ? AND ?
        GROUP BY transaction_type ORDER BY volume DESC
    ");
    $stmt->execute([$startDate, $endDate]);
    $typeBreakdown = $stmt->fetchAll();

} catch (PDOException $e) {
    logError("Reports DB Error: " . $e->getMessage());
    $error = $isHausa ? "An sami matsala wajen loda rahotanni." : "Erreur lors du chargement des rapports.";
}

$pageTitle = $isHausa ? 'Rahotanni - NigerPay' : 'Rapports - NigerPay';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto">
    <div class="flex flex-col lg:flex-row lg:justify-between lg:items-end mb-6 gap-4">
        <div>
            <h1 class="text-2xl font-bold text-gray-900"><?php echo $isHausa ? 'Binciken Kuɗi & Rahotanni' : 'Analyses & Rapports'; ?></h1>
            <p class="text-gray-500 text-sm mt-1">
                <?php echo $isHausa ? "Daga $startDate zuwa $endDate" : "Du $startDate au $endDate"; ?>
            </p>
        </div>
        
        <form method="GET" class="flex flex-wrap items-end gap-3 bg-white p-3 rounded-lg border border-gray-200 shadow-sm">
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1"><?php echo $isHausa ? 'Daga' : 'De'; ?></label>
                <input type="date" name="start_date" value="<?php echo $startDate; ?>" class="px-3 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-primary-500 focus:border-primary-500">
            </div>
            <div>
                <label class="block text-xs font-medium text-gray-500 mb-1"><?php echo $isHausa ? 'Zuwa' : 'À'; ?></label>
                <input type="date" name="end_date" value="<?php echo $endDate; ?>" class="px-3 py-1.5 border border-gray-300 rounded-md text-sm focus:ring-primary-500 focus:border-primary-500">
            </div>
            <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-1.5 rounded-md text-sm font-medium transition">
                <?php echo $isHausa ? 'Tace' : 'Filtrer'; ?>
            </button>
            <a href="?start_date=<?php echo $startDate; ?>&end_date=<?php echo $endDate; ?>&export=csv" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-1.5 rounded-md text-sm font-medium transition border border-gray-300">
                <i class="fas fa-download mr-1"></i> CSV
            </a>
        </form>
    </div>

    <?php if (isset($error)): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-lg">
            <p class="text-sm text-red-700"><?php echo $error; ?></p>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100 border-l-4 border-l-blue-500">
            <p class="text-sm font-medium text-gray-500"><?php echo $isHausa ? 'Jimillar Kuɗi (Volume)' : 'Volume Total'; ?></p>
            <p class="text-2xl font-bold text-gray-900 mt-1"><?php echo formatAmount($stats['volume'] ?? 0); ?></p>
            <p class="text-xs text-gray-400 mt-2"><i class="fas fa-exchange-alt mr-1"></i> <?php echo number_format($stats['tx_count']); ?> <?php echo $isHausa ? "ma'amaloli" : "transactions"; ?></p>
        </div>
        
        <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100 border-l-4 border-l-green-500">
            <p class="text-sm font-medium text-gray-500"><?php echo $isHausa ? 'Kuɗin Shiga (Fees)' : 'Frais Générés'; ?></p>
            <p class="text-2xl font-bold text-gray-900 mt-1"><?php echo formatAmount($stats['fees'] ?? 0); ?></p>
            <p class="text-xs text-green-600 font-medium mt-2"><i class="fas fa-arrow-up mr-1"></i> <?php echo $isHausa ? 'Riba ta kamfani' : 'Revenu brut'; ?></p>
        </div>
        
        <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100 border-l-4 border-l-orange-500">
            <p class="text-sm font-medium text-gray-500"><?php echo $isHausa ? 'An Biya Wakilai' : 'Commissions Agents'; ?></p>
            <p class="text-2xl font-bold text-gray-900 mt-1"><?php echo formatAmount($stats['commissions'] ?? 0); ?></p>
            <p class="text-xs text-orange-600 font-medium mt-2"><i class="fas fa-hand-holding-usd mr-1"></i> <?php echo $isHausa ? 'Kuɗin fita' : 'Dépenses réseau'; ?></p>
        </div>

        <div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100 border-l-4 border-l-purple-500">
            <p class="text-sm font-medium text-gray-500"><?php echo $isHausa ? 'Sababbin Masu Amfani' : 'Nouveaux Utilisateurs'; ?></p>
            <p class="text-2xl font-bold text-gray-900 mt-1"><?php echo number_format($stats['new_users']); ?></p>
            <p class="text-xs text-purple-600 font-medium mt-2"><i class="fas fa-users mr-1"></i> <?php echo $isHausa ? 'A cikin wannan lokacin' : 'Sur cette période'; ?></p>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                <h2 class="font-bold text-gray-800"><?php echo $isHausa ? 'Tsarin Kuɗi na Kullum' : 'Tendance Financière Quotidienne'; ?></h2>
            </div>
            <div class="p-6 relative h-80 w-full">
                <?php if (empty($chartData)): ?>
                    <div class="absolute inset-0 flex items-center justify-center text-gray-400">
                        <?php echo $isHausa ? 'Babu bayanai' : 'Aucune donnée'; ?>
                    </div>
                <?php else: ?>
                    <canvas id="revenueChart"></canvas>
                <?php endif; ?>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-100">
                <h2 class="font-bold text-gray-800"><?php echo $isHausa ? 'Rabe-raben Ma\'amaloli' : 'Répartition par Type'; ?></h2>
            </div>
            <div class="p-0">
                <?php if (empty($typeBreakdown)): ?>
                    <div class="p-8 text-center text-gray-400"><?php echo $isHausa ? 'Babu bayanai' : 'Aucune donnée'; ?></div>
                <?php else: ?>
                    <div class="divide-y divide-gray-50">
                        <?php foreach ($typeBreakdown as $type): ?>
                        <div class="p-4 hover:bg-gray-50 transition">
                            <div class="flex justify-between items-center mb-1">
                                <span class="text-sm font-medium text-gray-700 capitalize"><?php echo str_replace('_', ' ', $type['transaction_type']); ?></span>
                                <span class="text-sm font-bold text-gray-900"><?php echo formatAmount($type['volume']); ?></span>
                            </div>
                            <div class="flex justify-between text-xs text-gray-500">
                                <span><?php echo number_format($type['count']); ?> <?php echo $isHausa ? "ma'amaloli" : "txns"; ?></span>
                                <span class="text-green-600"><?php echo formatAmount($type['fees']); ?> <?php echo $isHausa ? "Riba" : "Frais"; ?></span>
                            </div>
                            <?php $percent = $stats['volume'] > 0 ? ($type['volume'] / $stats['volume']) * 100 : 0; ?>
                            <div class="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                                <div class="bg-primary-500 h-1.5 rounded-full" style="width: <?php echo $percent; ?>%"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php if (!empty($chartData)): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('revenueChart').getContext('2d');
        const langVolume = "<?php echo $isHausa ? 'Jimillar Kuɗi' : 'Volume'; ?>";
        const langFees = "<?php echo $isHausa ? 'Kuɗin Shiga (Fees)' : 'Frais'; ?>";

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_map(function($d) { return date('d M', strtotime($d['date'])); }, $chartData)); ?>,
                datasets: [
                    {
                        type: 'line',
                        label: langVolume,
                        data: <?php echo json_encode(array_map(function($d) { return $d['volume']; }, $chartData)); ?>,
                        borderColor: 'rgba(59, 130, 246, 1)', // Blue
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true,
                        yAxisID: 'y'
                    },
                    {
                        type: 'bar',
                        label: langFees,
                        data: <?php echo json_encode(array_map(function($d) { return $d['fees']; }, $chartData)); ?>,
                        backgroundColor: 'rgba(16, 185, 129, 0.8)', // Green
                        borderRadius: 4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.raw.toLocaleString('fr-FR') + ' FCFA';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        type: 'linear', display: true, position: 'left',
                        ticks: { callback: function(value) { return value.toLocaleString('fr-FR'); } }
                    },
                    y1: {
                        type: 'linear', display: true, position: 'right',
                        grid: { drawOnChartArea: false },
                        ticks: { callback: function(value) { return value.toLocaleString('fr-FR'); } }
                    }
                }
            }
        });
    });
</script>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>