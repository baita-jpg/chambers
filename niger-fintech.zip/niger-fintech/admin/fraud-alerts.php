<?php
/**
 * Niger Fintech System - Fraud Alerts
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'admin') { header('Location: /login.php'); exit; }

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');

try {
    // If table exists, fetch. If not, it will default to empty array.
    $stmt = $db->query("
        SELECT f.*, u.first_name, u.last_name, u.phone_number 
        FROM fraud_alerts f 
        LEFT JOIN users u ON f.user_id = u.id 
        ORDER BY f.created_at DESC LIMIT 50
    ");
    $alerts = $stmt->fetchAll();
} catch (PDOException $e) {
    $alerts = [];
}

$pageTitle = $isHausa ? 'Matsalolin Tsaro - NigerPay' : 'Alertes Fraude - NigerPay';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-900"><?php echo $isHausa ? 'Matsalolin Tsaro' : 'Alertes de sécurité'; ?></h1>
            <p class="text-gray-500 text-sm mt-1"><?php echo $isHausa ? 'Kula da ayyukan da ake zargi' : 'Surveillance des activités suspectes'; ?></p>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <?php if (empty($alerts)): ?>
            <div class="p-10 text-center text-gray-500">
                <i class="fas fa-shield-check text-5xl text-green-400 mb-4"></i>
                <p class="text-lg font-medium text-gray-700"><?php echo $isHausa ? 'Tsarin yana cikin koshin lafiya' : 'Le système est sécurisé'; ?></p>
                <p class="text-sm mt-1"><?php echo $isHausa ? 'Babu matsalolin tsaro a yanzu.' : 'Aucune alerte de fraude détectée.'; ?></p>
            </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 font-medium">Alert ID</th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Mai amfani' : 'Utilisateur'; ?></th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Tsanani' : 'Sévérité'; ?></th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Bayani' : 'Description'; ?></th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Matsayi' : 'Statut'; ?></th>
                        <th class="px-6 py-4 text-right font-medium"><?php echo $isHausa ? 'Ayyuka' : 'Actions'; ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($alerts as $alert): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 text-sm font-mono text-gray-500">#<?php echo $alert['id']; ?></td>
                        <td class="px-6 py-4">
                            <div class="font-medium text-gray-900"><?php echo htmlspecialchars($alert['first_name'] . ' ' . $alert['last_name']); ?></div>
                            <div class="text-xs text-gray-500"><?php echo htmlspecialchars($alert['phone_number']); ?></div>
                        </td>
                        <td class="px-6 py-4">
                            <?php 
                                $sevColor = 'bg-gray-100 text-gray-700';
                                if ($alert['severity'] === 'critical') $sevColor = 'bg-red-100 text-red-700 font-bold';
                                if ($alert['severity'] === 'high') $sevColor = 'bg-orange-100 text-orange-700';
                                if ($alert['severity'] === 'medium') $sevColor = 'bg-yellow-100 text-yellow-700';
                            ?>
                            <span class="px-2 py-1 text-xs rounded-md uppercase <?php echo $sevColor; ?>">
                                <?php echo htmlspecialchars($alert['severity']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-700 max-w-xs truncate" title="<?php echo htmlspecialchars($alert['description']); ?>">
                            <?php echo htmlspecialchars($alert['description']); ?>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-md capitalize">
                                <?php echo htmlspecialchars($alert['status']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <button class="text-primary-600 hover:text-primary-800 text-sm font-medium transition">
                                <?php echo $isHausa ? 'Bincika' : 'Enquêter'; ?>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>