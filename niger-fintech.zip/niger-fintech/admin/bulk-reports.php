<?php
/**
 * NigerPay - Admin Bulk Activity Reports
 */
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Handle Filters
$startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-7 days'));
$endDate   = $_GET['end_date'] ?? date('Y-m-d');
$type      = $_GET['type'] ?? 'all';

$sql = "SELECT t.*, u_s.first_name as sender, u_r.first_name as receiver 
        FROM transactions t
        LEFT JOIN users u_s ON t.sender_user_id = u_s.id
        LEFT JOIN users u_r ON t.receiver_user_id = u_r.id
        WHERE DATE(t.created_at) BETWEEN ? AND ?";

$params = [$startDate, $endDate];
if ($type !== 'all') {
    $sql .= " AND t.transaction_type = ?";
    $params[] = $type;
}
$sql .= " ORDER BY t.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto pb-20">
    <div class="flex justify-between items-center mb-10">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $isHausa ? 'Rahoton Ma\'amala' : 'Rapports d\'Activité'; ?></h1>
        <button onclick="window.print()" class="bg-slate-100 text-slate-900 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-slate-200">
            <i class="fas fa-file-pdf mr-2"></i> Export PDF
        </button>
    </div>

    <div class="bg-white p-6 rounded-[2rem] shadow-soft border border-slate-100 mb-8">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            <div class="space-y-1">
                <label class="text-[10px] font-black text-slate-400 uppercase ml-2">Start Date</label>
                <input type="date" name="start_date" value="<?php echo $startDate; ?>" class="w-full px-4 py-3 bg-slate-50 border-0 rounded-xl font-bold">
            </div>
            <div class="space-y-1">
                <label class="text-[10px] font-black text-slate-400 uppercase ml-2">End Date</label>
                <input type="date" name="end_date" value="<?php echo $endDate; ?>" class="w-full px-4 py-3 bg-slate-50 border-0 rounded-xl font-bold">
            </div>
            <div class="space-y-1">
                <label class="text-[10px] font-black text-slate-400 uppercase ml-2">Type</label>
                <select name="type" class="w-full px-4 py-3 bg-slate-50 border-0 rounded-xl font-bold">
                    <option value="all">All Types</option>
                    <option value="cash_in" <?php echo $type == 'cash_in' ? 'selected' : ''; ?>>Cash In</option>
                    <option value="cash_out" <?php echo $type == 'cash_out' ? 'selected' : ''; ?>>Cash Out</option>
                </select>
            </div>
            <button type="submit" class="bg-slate-900 text-white py-3 rounded-xl font-black text-xs uppercase tracking-widest">Filter Results</button>
        </form>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <tr>
                    <th class="px-8 py-5">Date</th>
                    <th class="px-8 py-5">TXID</th>
                    <th class="px-8 py-5">Details</th>
                    <th class="px-8 py-5 text-right">Amount (XOF)</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-50">
                <?php foreach($transactions as $tx): ?>
                <tr>
                    <td class="px-8 py-5 text-xs text-slate-500"><?php echo date('M d, H:i', strtotime($tx['created_at'])); ?></td>
                    <td class="px-8 py-5 font-mono text-[10px] font-bold"><?php echo $tx['transaction_id']; ?></td>
                    <td class="px-8 py-5">
                        <p class="text-sm font-black text-slate-900 uppercase"><?php echo str_replace('_', ' ', $tx['transaction_type']); ?></p>
                        <p class="text-[10px] text-slate-400 font-bold"><?php echo $tx['sender'] ?? 'System'; ?> ➔ <?php echo $tx['receiver'] ?? 'External'; ?></p>
                    </td>
                    <td class="px-8 py-5 text-right font-black text-slate-900"><?php echo number_format($tx['amount']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>