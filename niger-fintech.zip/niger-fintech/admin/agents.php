<?php
/**
 * Niger Fintech System - Agent Network Management
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'admin') { header('Location: /login.php'); exit; }

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');

// Helper function
if (!function_exists('formatAmount')) {
    function formatAmount($amount) { return number_format((float)$amount, 0, ',', ' ') . ' FCFA'; }
}

$agents = [];
$networkStats = ['total_agents' => 0, 'active_agents' => 0, 'total_float' => 0, 'total_commissions' => 0];
$chartData = ['labels' => [], 'volumes' => []];

try {
    // 1. Fetch Network KPIs
    $stmt = $db->query("
        SELECT 
            COUNT(id) as total_agents,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_agents
        FROM users WHERE user_type IN ('agent', 'super_agent')
    ");
    if ($row = $stmt->fetch()) $networkStats = array_merge($networkStats, $row);

    // Sum of all agent 'float' wallets
    $stmt = $db->query("SELECT SUM(balance) as total_float FROM wallet_accounts WHERE account_type = 'float'");
    $networkStats['total_float'] = $stmt->fetch()['total_float'] ?? 0;

    // Sum of all commissions paid in last 30 days
    $stmt = $db->query("SELECT SUM(commission_amount) as total_commissions FROM transactions WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND status = 'completed'");
    $networkStats['total_commissions'] = $stmt->fetch()['total_commissions'] ?? 0;

    // 2. Fetch Top Performing Agents for Chart (Last 30 Days)
    $stmt = $db->query("
        SELECT 
            u.first_name, 
            SUM(t.amount) as volume
        FROM users u
        JOIN transactions t ON u.id = t.agent_id
        WHERE u.user_type IN ('agent', 'super_agent') 
          AND t.status = 'completed' 
          AND t.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY u.id
        ORDER BY volume DESC
        LIMIT 5
    ");
    while ($row = $stmt->fetch()) {
        $chartData['labels'][] = $row['first_name'];
        $chartData['volumes'][] = $row['volume'];
    }

    // 3. Fetch Full Agent List with their current float balances
    $stmt = $db->query("
        SELECT u.id, u.first_name, u.last_name, u.phone_number, u.user_type, u.is_active, 
               a.agent_code, a.business_name,
               COALESCE(w.balance, 0) as float_balance
        FROM users u 
        JOIN agent_details a ON u.id = a.user_id 
        LEFT JOIN wallet_accounts w ON u.id = w.user_id AND w.account_type = 'float'
        WHERE u.user_type IN ('agent', 'super_agent') 
        ORDER BY u.created_at DESC
    ");
    $agents = $stmt->fetchAll();

} catch (PDOException $e) {
    logError("Agent DB Error: " . $e->getMessage());
}

$pageTitle = $isHausa ? 'Harkar Wakilai - NigerPay' : 'Réseau d\'Agents - NigerPay';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto pb-12">
    <div class="flex flex-col sm:flex-row justify-between items-center mb-8 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <div>
            <h1 class="text-3xl font-extrabold text-gray-900 tracking-tight"><?php echo $isHausa ? 'Harkar Wakilai' : 'Réseau d\'Agents'; ?></h1>
            <p class="text-gray-500 text-sm mt-1"><?php echo $isHausa ? 'Kula da duk wakilan NigerPay' : 'Gérer l\'ensemble des agents NigerPay'; ?></p>
        </div>
        <button class="mt-4 sm:mt-0 bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition shadow-md flex items-center">
            <i class="fas fa-plus mr-2"></i> <?php echo $isHausa ? 'Sabuwar Wakili' : 'Nouvel Agent'; ?>
        </button>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div class="flex items-center justify-between mb-2">
                <p class="text-gray-500 text-sm font-semibold uppercase tracking-wider"><?php echo $isHausa ? 'Duk Wakilai' : 'Total Agents'; ?></p>
                <div class="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center"><i class="fas fa-store"></i></div>
            </div>
            <h3 class="text-3xl font-black text-gray-900"><?php echo number_format($networkStats['total_agents']); ?></h3>
            <p class="text-xs text-green-600 font-medium mt-2"><i class="fas fa-check-circle mr-1"></i> <?php echo number_format($networkStats['active_agents']); ?> <?php echo $isHausa ? 'masu aiki' : 'actifs'; ?></p>
        </div>
        
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 lg:col-span-2">
            <div class="flex items-center justify-between mb-2">
                <p class="text-gray-500 text-sm font-semibold uppercase tracking-wider"><?php echo $isHausa ? 'Jimillar Jari (Float)' : 'Liquidité Globale (Float)'; ?></p>
                <div class="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center"><i class="fas fa-water"></i></div>
            </div>
            <h3 class="text-3xl font-black text-gray-900"><?php echo formatAmount($networkStats['total_float']); ?></h3>
            <div class="w-full bg-gray-100 rounded-full h-1.5 mt-4">
                <div class="bg-indigo-500 h-1.5 rounded-full" style="width: 75%"></div>
            </div>
        </div>

        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div class="flex items-center justify-between mb-2">
                <p class="text-gray-500 text-sm font-semibold uppercase tracking-wider"><?php echo $isHausa ? 'Kwamishon (30J)' : 'Commissions (30J)'; ?></p>
                <div class="w-10 h-10 bg-green-50 text-green-600 rounded-lg flex items-center justify-center"><i class="fas fa-hand-holding-usd"></i></div>
            </div>
            <h3 class="text-3xl font-black text-gray-900"><?php echo formatAmount($networkStats['total_commissions']); ?></h3>
            <p class="text-xs text-gray-400 mt-2 font-medium"><?php echo $isHausa ? 'An biya a tsarin' : 'Payées par le système'; ?></p>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
        <h2 class="font-bold text-gray-800 text-lg mb-6"><?php echo $isHausa ? 'Manyan Wakilai (Kwanaki 30)' : 'Meilleurs Agents (Volume 30J)'; ?></h2>
        <?php if (empty($chartData['labels'])): ?>
            <div class="h-48 flex flex-col items-center justify-center text-gray-400">
                <i class="fas fa-chart-bar text-4xl mb-3 text-gray-200"></i>
                <p><?php echo $isHausa ? 'Babu isassun bayanai.' : 'Données insuffisantes.'; ?></p>
            </div>
        <?php else: ?>
            <div class="relative h-64 w-full">
                <canvas id="topAgentsChart"></canvas>
            </div>
        <?php endif; ?>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
            <h2 class="font-bold text-gray-800 text-lg"><?php echo $isHausa ? 'Jerin Wakilai' : 'Liste des Agents'; ?></h2>
            <div class="relative">
                <span class="absolute inset-y-0 left-0 flex items-center pl-3"><i class="fas fa-search text-gray-400 text-sm"></i></span>
                <input type="text" placeholder="<?php echo $isHausa ? 'Bincika wakili...' : 'Rechercher...'; ?>" class="pl-9 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-primary-500 w-64">
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-white text-gray-400 text-xs uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 font-semibold"><?php echo $isHausa ? 'Wakili' : 'Code Agent'; ?></th>
                        <th class="px-6 py-4 font-semibold"><?php echo $isHausa ? 'Kasuwanci' : 'Entreprise'; ?></th>
                        <th class="px-6 py-4 font-semibold"><?php echo $isHausa ? 'Waya' : 'Téléphone'; ?></th>
                        <th class="px-6 py-4 font-semibold text-right"><?php echo $isHausa ? 'Jari (Float)' : 'Solde Float'; ?></th>
                        <th class="px-6 py-4 font-semibold text-center"><?php echo $isHausa ? 'Matsayi' : 'Statut'; ?></th>
                        <th class="px-6 py-4 text-right font-semibold"><?php echo $isHausa ? 'Ayyuka' : 'Actions'; ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($agents as $agent): ?>
                    <tr class="hover:bg-blue-50/30 transition">
                        <td class="px-6 py-4 font-mono text-sm text-primary-700 font-bold bg-primary-50/50 rounded-l-lg"><?php echo htmlspecialchars($agent['agent_code']); ?></td>
                        <td class="px-6 py-4">
                            <div class="font-bold text-gray-900"><?php echo htmlspecialchars($agent['business_name']); ?></div>
                            <div class="text-xs text-gray-500 font-medium mt-0.5">
                                <?php echo htmlspecialchars($agent['first_name'] . ' ' . $agent['last_name']); ?>
                                <span class="ml-2 px-1.5 py-0.5 <?php echo $agent['user_type'] === 'super_agent' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'; ?> rounded text-[10px] uppercase tracking-wider">
                                    <?php echo str_replace('_', ' ', $agent['user_type']); ?>
                                </span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm font-medium text-gray-600"><?php echo htmlspecialchars($agent['phone_number']); ?></td>
                        <td class="px-6 py-4 text-right font-bold text-gray-900"><?php echo formatAmount($agent['float_balance']); ?></td>
                        <td class="px-6 py-4 text-center">
                            <?php if ($agent['is_active']): ?>
                                <span class="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full"><i class="fas fa-check-circle mr-1"></i> <?php echo $isHausa ? 'Mai aiki' : 'Actif'; ?></span>
                            <?php else: ?>
                                <span class="px-3 py-1 bg-red-100 text-red-700 text-xs font-bold rounded-full"><i class="fas fa-ban mr-1"></i> <?php echo $isHausa ? 'A kulle' : 'Bloqué'; ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <a href="agent-performance.php?id=<?php echo $agent['id']; ?>" class="text-primary-600 hover:text-white hover:bg-primary-600 p-2 rounded-lg transition inline-block">
                                <i class="fas fa-chart-line"></i>
                            </a>
                            <button onclick="openTopupModal('<?php echo $agent['id']; ?>', '<?php echo $agent['first_name']; ?>')" 
                                    class="bg-primary-50 text-primary-600 px-4 py-2 rounded-xl font-black text-[10px] uppercase hover:bg-primary-600 hover:text-white transition-all">
                                <i class="fas fa-plus-circle mr-1"></i> Top-up
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="topupModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div class="p-8 border-b border-slate-50 flex justify-between items-center">
            <h3 class="text-xl font-black text-slate-900">Float Top-up</h3>
            <button onclick="closeModal()" class="text-slate-400 hover:text-slate-600"><i class="fas fa-times"></i></button>
        </div>
        
        <form id="topupForm" class="p-8 space-y-6">
            <input type="hidden" id="modal_agent_id" name="agent_id">
            <?php csrfField(); ?>

            <div class="text-center bg-slate-50 p-4 rounded-2xl mb-4">
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Agent Account</p>
                <p id="modal_agent_name" class="font-bold text-slate-900">---</p>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Amount to Add (XOF)</label>
                <input type="number" name="amount" required placeholder="500000" 
                       class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-2xl focus:border-primary-500 transition-all outline-none">
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Funding Source</label>
                <select name="source" class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold">
                    <option value="central_reserve">Central Reserve</option>
                    <option value="bank_deposit">Bank Deposit Settlement</option>
                    <option value="cash_received">Physical Cash Received</option>
                </select>
            </div>

            <button type="button" onclick="submitTopup()" class="w-full bg-primary-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-primary-900/20 hover:scale-[1.02] active:scale-95 transition-all uppercase tracking-widest">
                Confirm Funding
            </button>
        </form>
    </div>
</div>

<script>
function openTopupModal(id, name) {
    document.getElementById('modal_agent_id').value = id;
    document.getElementById('modal_agent_name').innerText = name;
    document.getElementById('topupModal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('topupModal').classList.add('hidden');
}

async function submitTopup() {
    const form = document.getElementById('topupForm');
    const formData = new FormData(form);

    const response = await fetch('ajax-topup.php', {
        method: 'POST',
        body: formData
    });
    
    const result = await response.json();
    if(result.success) {
        alert('Float updated successfully!');
        location.reload();
    } else {
        alert('Error: ' + result.message);
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<?php if (!empty($chartData['labels'])): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('topAgentsChart').getContext('2d');
    
    // Gradient for the bars
    let gradientFill = ctx.createLinearGradient(0, 0, 0, 300);
    gradientFill.addColorStop(0, 'rgba(13, 148, 136, 0.8)'); // Teal
    gradientFill.addColorStop(1, 'rgba(59, 130, 246, 0.8)'); // Blue

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($chartData['labels']); ?>,
            datasets: [{
                label: "<?php echo $isHausa ? 'Jimillar Ma\'amaloli (FCFA)' : 'Volume Total (FCFA)'; ?>",
                data: <?php echo json_encode($chartData['volumes']); ?>,
                backgroundColor: gradientFill,
                borderRadius: 6,
                barThickness: 40
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(17, 24, 39, 0.9)',
                    padding: 12,
                    callbacks: {
                        label: function(context) { return ' ' + context.raw.toLocaleString('fr-FR') + ' FCFA'; }
                    }
                }
            },
            scales: {
                x: { grid: { display: false } },
                y: { 
                    border: { display: false },
                    grid: { color: '#f3f4f6' },
                    ticks: { callback: function(value) { return value >= 1000000 ? (value/1000000).toFixed(1) + 'M' : value.toLocaleString('fr-FR'); } }
                }
            }
        }
    });
});
</script>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>