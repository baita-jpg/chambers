<?php
/**
 * NigerPay - Create New Agent Account
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

// Security Gate
requireRole('admin');

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRFToken($_POST['csrf_token'] ?? '')) {
    $firstName = sanitizeInput($_POST['first_name']);
    $lastName  = sanitizeInput($_POST['last_name']);
    $phone     = formatPhoneNumber($_POST['phone']);
    $location  = sanitizeInput($_POST['location']);
    $pin       = $_POST['pin']; // Will be hashed

    try {
        executeInTransaction(function($db) use ($firstName, $lastName, $phone, $location, $pin) {
            // 1. Check if phone already exists
            $stmt = $db->prepare("SELECT id FROM users WHERE phone_number = ?");
            $stmt->execute([$phone]);
            if ($stmt->fetch()) throw new Exception("Wannan lambar tana riga da akwai / Ce numéro existe déjà.");

            // 2. Insert User
            $stmt = $db->prepare("INSERT INTO users (first_name, last_name, phone_number, pin_hash, user_type, is_active, created_at) VALUES (?, ?, ?, ?, 'agent', 1, NOW())");
            $stmt->execute([$firstName, $lastName, $phone, hashPIN($pin)]);
            $userId = $db->lastInsertId();

            // 3. Insert Agent Specific Details
            $agentCode = "NP" . str_pad($userId, 4, '0', STR_PAD_LEFT);
            $stmt = $db->prepare("INSERT INTO agent_details (user_id, agent_code, branch_location) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $agentCode, $location]);

            // 4. Initialize Wallets (Primary, Float, Commission)
            $wallets = ['primary', 'float', 'commission'];
            $stmt = $db->prepare("INSERT INTO wallet_accounts (user_id, account_type, account_number, balance, available_balance, tier_limit) VALUES (?, ?, ?, 0, 0, 10000000)");
            foreach ($wallets as $type) {
                $accNum = strtoupper($type[0]) . date('y') . str_pad($userId, 5, '0', STR_PAD_LEFT) . mt_rand(10, 99);
                $stmt->execute([$userId, $type, $accNum]);
            }
        });
        $message = $isHausa ? "An yi nasarar ƙirƙirar wakili!" : "Agent créé avec succès !";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$pageTitle = $isHausa ? 'Ƙara Sabuwar Wakili' : 'Ajouter un Nouvel Agent';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-2xl mx-auto pb-20">
    <div class="mb-10">
        <a href="agents.php" class="text-slate-400 hover:text-primary-600 font-bold text-xs uppercase tracking-widest flex items-center mb-4">
            <i class="fas fa-arrow-left mr-2"></i> <?php echo $isHausa ? 'Koma Baya' : 'Retour'; ?>
        </a>
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $pageTitle; ?></h1>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-10">
        <?php if($message): ?>
            <div class="bg-green-50 text-green-700 p-6 rounded-2xl mb-8 font-bold flex items-center animate-bounce">
                <i class="fas fa-check-circle mr-3"></i> <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="bg-red-50 text-red-700 p-6 rounded-2xl mb-8 font-bold flex items-center">
                <i class="fas fa-exclamation-triangle mr-3"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-8">
            <?php csrfField(); ?>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2"><?php echo $isHausa ? 'Sunan Farko' : 'Prénom'; ?></label>
                    <input type="text" name="first_name" required placeholder="Ex: Moussa" class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-bold">
                </div>
                <div class="space-y-2">
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2"><?php echo $isHausa ? 'Sunan Mahaifi' : 'Nom'; ?></label>
                    <input type="text" name="last_name" required placeholder="Ex: Ibrahim" class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-bold">
                </div>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2"><?php echo $isHausa ? 'Lambar Waya' : 'Numéro de Téléphone'; ?></label>
                <div class="relative">
                    <span class="absolute left-6 top-1/2 -translate-y-1/2 font-bold text-slate-400">+227</span>
                    <input type="tel" name="phone" required placeholder="90 00 00 00" class="w-full pl-20 pr-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-bold">
                </div>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2"><?php echo $isHausa ? 'Wurin Reshe' : 'Localisation / Branche'; ?></label>
                <select name="location" class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-bold">
                    <option value="Niamey Central">Niamey Central</option>
                    <option value="Zinder">Zinder</option>
                    <option value="Maradi">Maradi</option>
                    <option value="Tahoua">Tahoua</option>
                    <option value="Agadez">Agadez</option>
                </select>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Security PIN (4 Digits)</label>
                <input type="password" name="pin" maxlength="4" required placeholder="****" class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl focus:border-primary-500 focus:bg-white transition-all font-bold text-center tracking-widest text-2xl">
            </div>

            

            <button type="submit" class="w-full bg-slate-900 text-white font-black py-5 rounded-3xl shadow-xl hover:scale-[1.02] active:scale-95 transition-all uppercase tracking-widest flex items-center justify-center gap-3">
                <i class="fas fa-user-check opacity-50"></i>
                <span><?php echo $isHausa ? 'Ƙirƙiri Wakili' : 'Créer le Compte Agent'; ?></span>
            </button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>