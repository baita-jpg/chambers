<?php
/**
 * Niger Fintech System - Digital Transaction Receipt
 */
require_once __DIR__ . '/../includes/auth.php';

// Verify Access
if (!isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');

$transactionId = $_GET['id'] ?? '';
$error = '';

try {
    // Fetch detailed transaction data
    $stmt = $db->prepare("
        SELECT t.*, 
               sender.first_name as s_fname, sender.last_name as s_lname, sender.phone_number as s_phone,
               receiver.first_name as r_fname, receiver.last_name as r_lname, receiver.phone_number as r_phone,
               agent.business_name as agent_name, agent_u.first_name as ag_fname, agent_u.last_name as ag_lname
        FROM transactions t
        LEFT JOIN users sender ON t.sender_user_id = sender.id
        LEFT JOIN users receiver ON t.receiver_user_id = receiver.id
        LEFT JOIN agent_details agent ON t.agent_id = agent.user_id
        LEFT JOIN users agent_u ON t.agent_id = agent_u.id
        WHERE t.transaction_id = ?
    ");
    $stmt->execute([$transactionId]);
    $tx = $stmt->fetch();

    if (!$tx) {
        throw new Exception($isHausa ? "Ba a sami wannan ma'amala ba." : "Transaction introuvable.");
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}

function formatAmount($amount) { return number_format((float)$amount, 0, ',', ' ') . ' FCFA'; }

$pageTitle = $isHausa ? 'Rasit din Ma\'amala' : 'Reçu de Transaction';
?>
<!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @media print {
            .no-print { display: none !important; }
            body { background-color: white !important; }
            .receipt-card { border: none !important; shadow: none !important; }
        }
        .font-sharetech { font-family: 'Courier New', Courier, monospace; }
    </style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen p-4">

    <?php if ($error): ?>
        <div class="bg-white p-8 rounded-2xl shadow-xl text-center max-w-sm">
            <i class="fas fa-times-circle text-red-500 text-5xl mb-4"></i>
            <p class="text-gray-800 font-bold"><?php echo $error; ?></p>
            <a href="dashboard.php" class="mt-4 inline-block text-primary-600 font-bold">Koma Baya / Retour</a>
        </div>
    <?php else: ?>

        <div class="max-w-md w-full no-print mb-4 absolute top-4 flex justify-between px-4 w-full">
            <a href="javascript:history.back()" class="bg-white p-2 rounded-full shadow-md text-gray-600 hover:text-primary-600 transition">
                <i class="fas fa-arrow-left px-2"></i>
            </a>
            <button onclick="window.print()" class="bg-primary-600 text-white px-6 py-2 rounded-full font-bold shadow-lg hover:bg-primary-700 transition">
                <i class="fas fa-print mr-2"></i> <?php echo $isHausa ? 'Bugawa' : 'Imprimer'; ?>
            </button>
        </div>

        <div class="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-gray-100 receipt-card">
            <div class="bg-primary-600 p-8 text-center text-white">
                <i class="fas fa-wallet text-4xl mb-3"></i>
                <h1 class="text-2xl font-black tracking-tight">NigerPay</h1>
                <p class="text-primary-100 text-xs uppercase tracking-widest mt-1">Transaction Receipt</p>
            </div>

            <div class="p-8">
                <div class="text-center mb-8">
                    <div class="inline-flex items-center px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-black uppercase mb-3">
                        <i class="fas fa-check-circle mr-2"></i> <?php echo ucfirst($tx['status']); ?>
                    </div>
                    <h2 class="text-4xl font-black text-gray-900"><?php echo formatAmount($tx['amount']); ?></h2>
                    <p class="text-gray-400 text-sm mt-1"><?php echo date('d M Y | H:i:s', strtotime($tx['created_at'])); ?></p>
                </div>

                <div class="space-y-4 border-t border-b border-gray-100 py-6">
                    <div class="flex justify-between">
                        <span class="text-gray-400 text-sm"><?php echo $isHausa ? 'Nau\'i' : 'Type'; ?></span>
                        <span class="text-gray-900 font-bold uppercase text-sm"><?php echo str_replace('_', ' ', $tx['transaction_type']); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-400 text-sm"><?php echo $isHausa ? 'ID Ma\'amala' : 'ID Transaction'; ?></span>
                        <span class="text-gray-900 font-mono text-sm"><?php echo $tx['transaction_id']; ?></span>
                    </div>
                    
                    <div class="pt-4">
                        <p class="text-xs text-gray-400 font-bold uppercase mb-2"><?php echo $isHausa ? 'Bayanin Masu Ma\'amala' : 'Détails des parties'; ?></p>
                        <div class="bg-gray-50 rounded-2xl p-4 space-y-3">
                            <div class="flex justify-between">
                                <span class="text-gray-500 text-xs"><?php echo $isHausa ? 'Mai aikawa' : 'De (Expéditeur)'; ?></span>
                                <span class="text-gray-900 font-bold text-xs"><?php echo htmlspecialchars($tx['s_phone'] ?: '-'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-500 text-xs"><?php echo $isHausa ? 'Mai karɓa' : 'À (Destinataire)'; ?></span>
                                <span class="text-gray-900 font-bold text-xs"><?php echo htmlspecialchars($tx['r_phone'] ?: '-'); ?></span>
                            </div>
                        </div>
                    </div>

                    <?php if ($tx['agent_id']): ?>
                    <div class="flex justify-between pt-2">
                        <span class="text-gray-400 text-sm"><?php echo $isHausa ? 'Wakili' : 'Agent'; ?></span>
                        <span class="text-gray-900 font-bold text-sm text-right"><?php echo htmlspecialchars($tx['agent_name'] ?: $tx['ag_fname']); ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="flex flex-col items-center justify-center mt-8">
                    <div class="bg-gray-100 p-4 rounded-2xl mb-2">
                        <i class="fas fa-qrcode text-6xl text-gray-800"></i>
                    </div>
                    <p class="text-[10px] text-gray-400 uppercase font-black tracking-widest">Verify Authenticity</p>
                </div>
            </div>

            <div class="bg-gray-50 p-6 text-center">
                <p class="text-gray-400 text-[10px] leading-relaxed">
                    <?php echo $isHausa ? 'Wannan rasit din an samar da shi ne ta atomatik daga NigerPay. Idan akwai matsala, tuntuɓi tallafi.' : 'Ce reçu a été généré automatiquement par NigerPay. En cas de litige, contactez notre support.'; ?>
                </p>
                <p class="text-primary-600 font-black text-xs mt-3 tracking-tighter">WWW.NIGERPAY.NE</p>
            </div>
        </div>

    <?php endif; ?>

</body>
</html>