<?php
/**
 * Niger Fintech System - Advanced Agent Performance
 */
require_once __DIR__ . '/../includes/auth.php';

// Verify Admin/Super Admin Access
if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['admin', 'super_agent'])) {
    header('Location: /login.php');
    exit;
}

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');

$agentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$error = '';
$successMsg = '';

// --- HANDLE POST ACTIONS (RECHARGE / UPDATE) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRFToken($_POST['csrf_token'] ?? '')) {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'recharge_float') {
            $amount = (int)$_POST['amount'];
            if ($amount > 0) {
                try {
                    $db->prepare("UPDATE wallet_accounts SET balance = balance + ?, available_balance = available_balance + ? WHERE user_id = ? AND account_type = 'float'")
                       ->execute([$amount, $amount, $agentId]);
                    logActivity('wallet_accounts', $agentId, 'FLOAT_RECHARGE', [], ['amount' => $amount]);
                    $successMsg = $isHausa ? "An yi nasarar ƙara float!" : "Float rechargé avec succès !";
                } catch (Exception $e) { $error = $e->getMessage(); }
            }
        }
    }
}

try {
    // 1. Fetch Agent Core Info
    $stmt = $db->prepare("
        SELECT u.*, ad.agent_code, ad.business_name, ad.performance_score, ad.commission_rate
        FROM users u
        LEFT JOIN agent_details ad ON u.id = ad.user_id
        WHERE u.id = ? AND u.user_type IN ('agent', 'super_agent')
    ");
    $stmt->execute([$agentId]);
    $agent = $stmt->fetch();

    if (!$agent) throw new Exception($isHausa ? "Ba a sami wannan wakilin ba." : "Agent introuvable.");

    // 2. Fetch Wallet Balances
    $stmt = $db->prepare("SELECT account_type, balance, account_number FROM wallet_accounts WHERE user_id = ?");
    $stmt->execute([$agentId]);
    $wallets = [];
    while ($row = $stmt->fetch()) { $wallets[$row['account_type']] = $row; }

    // 3. Fetch 30-Day KPIs
    $stmt = $db->prepare("
        SELECT COUNT(id) as total_tx, SUM(amount) as total_volume, SUM(commission_amount) as total_commission,
            SUM(CASE WHEN transaction_type = 'cash_in' THEN amount ELSE 0 END) as cash_in_volume,
            SUM(CASE WHEN transaction_type = 'cash_out' THEN amount ELSE 0 END) as cash_out_volume
        FROM transactions WHERE agent_id = ? AND status = 'completed' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    ");
    $stmt->execute([$agentId]);
    $kpis = $stmt->fetch();

    // 4. Fetch Chart Data
    $stmt = $db->prepare("
        SELECT DATE(created_at) as date, SUM(amount) as volume, SUM(commission_amount) as commission
        FROM transactions WHERE agent_id = ? AND status = 'completed' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY DATE(created_at) ORDER BY date ASC
    ");
    $stmt->execute([$agentId]);
    $chartData = $stmt->fetchAll();

    // 5. Fetch Recent Activities
    $stmt = $db->prepare("
        SELECT t.*, 
               sender.first_name as s_fname, sender.last_name as s_lname, sender.phone_number as s_phone,
               receiver.first_name as r_fname, receiver.last_name as r_lname, receiver.phone_number as r_phone
        FROM transactions t
        LEFT JOIN users sender ON t.sender_user_id = sender.id
        LEFT JOIN users receiver ON t.receiver_user_id = receiver.id
        WHERE t.agent_id = ? OR t.sender_user_id = ? OR t.receiver_user_id = ?
        ORDER BY t.created_at DESC LIMIT 20
    ");
    $stmt->execute([$agentId, $agentId, $agentId]);
    $activities = $stmt->fetchAll();

} catch (Exception $e) { $error = $e->getMessage(); }

if (!function_exists('formatAmount')) {
    function formatAmount($amount) { return number_format((float)$amount, 0, ',', ' ') . ' FCFA'; }
}

$pageTitle = $isHausa ? 'Ayyukan Wakili - NigerPay' : 'Performance Agent - NigerPay';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto pb-12 px-4 sm:px-6 lg:px-8">
    
    <div class="flex justify-between items-center mb-6">
        <a href="agents.php" class="text-primary-600 hover:text-primary-800 text-sm font-medium flex items-center group transition">
            <i class="fas fa-arrow-left mr-2 group-hover:-translate-x-1 transition-transform"></i> <?php echo $isHausa ? 'Koma zuwa jerin wakilai' : 'Retour à la liste des agents'; ?>
        </a>
        <div class="text-xs text-gray-400 font-mono"><?php echo $isHausa ? 'ID Wakili' : 'ID Agent'; ?>: #<?php echo $agentId; ?></div>
    </div>

    <?php if ($successMsg): ?>
        <div class="bg-green-100 border-l-4 border-green-500 p-4 mb-6 rounded shadow-sm flex items-center">
            <i class="fas fa-check-circle text-green-600 mr-3"></i>
            <p class="text-sm text-green-700 font-bold"><?php echo $successMsg; ?></p>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 rounded mb-6 shadow-sm flex items-center">
            <i class="fas fa-exclamation-triangle text-red-600 mr-3"></i>
            <p class="text-sm text-red-700 font-medium"><?php echo $error; ?></p>
        </div>
    <?php else: ?>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8 flex flex-col md:flex-row justify-between items-start md:items-center">
        <div class="flex items-center">
            <div class="relative">
                <div class="w-20 h-20 bg-gradient-to-tr from-primary-600 to-primary-400 text-white rounded-2xl flex items-center justify-center text-3xl font-black shadow-lg">
                    <?php echo strtoupper(substr($agent['first_name'], 0, 1) . substr($agent['last_name'], 0, 1)); ?>
                </div>
                <div class="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 border-4 border-white rounded-full"></div>
            </div>
            <div class="ml-6">
                <h1 class="text-3xl font-extrabold text-gray-900"><?php echo htmlspecialchars($agent['business_name'] ?: $agent['first_name'].' '.$agent['last_name']); ?></h1>
                <div class="flex flex-wrap items-center gap-3 mt-2 text-sm">
                    <span class="bg-primary-50 text-primary-700 px-3 py-1 rounded-full font-bold text-xs"><?php echo htmlspecialchars($agent['agent_code']); ?></span>
                    <span class="text-gray-500"><i class="fas fa-phone mr-1"></i> <?php echo htmlspecialchars($agent['phone_number']); ?></span>
                    <span class="text-gray-500"><i class="fas fa-percent mr-1 text-indigo-500"></i> Commission: <?php echo ($agent['commission_rate'] * 100); ?>%</span>
                </div>
            </div>
        </div>
        <div class="mt-6 md:mt-0 flex flex-wrap gap-3">
            <button onclick="toggleModal('rechargeModal')" class="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-md transition-all flex items-center">
                <i class="fas fa-plus-circle mr-2"></i> <?php echo $isHausa ? 'Bada Float' : 'Charger Float'; ?>
            </button>
            <button onclick="toggleModal('editModal')" class="bg-white text-gray-700 hover:bg-gray-50 border border-gray-200 px-6 py-2.5 rounded-xl text-sm font-bold shadow-sm transition flex items-center">
                <i class="fas fa-user-edit mr-2"></i> <?php echo $isHausa ? 'Gyara' : 'Modifier'; ?>
            </button>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-2xl p-6 border-b-4 border-primary-500 shadow-sm">
            <div class="flex justify-between items-start mb-4">
                <p class="text-gray-500 text-xs font-bold uppercase tracking-widest"><?php echo $isHausa ? 'Jari (Float Balance)' : 'Solde Float'; ?></p>
                <i class="fas fa-vault text-primary-200 text-xl"></i>
            </div>
            <h3 class="text-3xl font-black text-gray-900"><?php echo formatAmount($wallets['float']['balance'] ?? 0); ?></h3>
            <p class="text-[10px] text-gray-400 font-mono mt-2"><?php echo $wallets['float']['account_number'] ?? 'N/A'; ?></p>
        </div>
        
        <div class="bg-white rounded-2xl p-6 border-b-4 border-indigo-500 shadow-sm">
            <div class="flex justify-between items-start mb-4">
                <p class="text-gray-500 text-xs font-bold uppercase tracking-widest"><?php echo $isHausa ? 'Riba (Commission)' : 'Commissions Cumulées'; ?></p>
                <i class="fas fa-coins text-indigo-200 text-xl"></i>
            </div>
            <h3 class="text-3xl font-black text-gray-900"><?php echo formatAmount($wallets['commission']['balance'] ?? 0); ?></h3>
            <p class="text-xs text-green-500 font-bold mt-2"><i class="fas fa-arrow-up mr-1"></i> <?php echo formatAmount($kpis['total_commission'] ?? 0); ?> (30J)</p>
        </div>

        <div class="bg-gray-900 rounded-2xl p-6 text-white shadow-lg">
            <p class="text-gray-400 text-xs font-bold uppercase tracking-widest mb-4"><?php echo $isHausa ? 'Ayyukan Kwanaki 30' : 'Activités 30 Jours'; ?></p>
            <div class="space-y-3">
                <div class="flex justify-between items-center">
                    <span class="text-sm text-gray-300">Ma'amaloli</span>
                    <span class="text-lg font-bold"><?php echo number_format($kpis['total_tx'] ?? 0); ?></span>
                </div>
                <div class="w-full bg-gray-700 h-1.5 rounded-full overflow-hidden">
                    <div class="bg-primary-500 h-full" style="width: 70%"></div>
                </div>
                <div class="flex justify-between text-xs pt-1">
                    <span class="text-green-400">IN: <?php echo formatAmount($kpis['cash_in_volume'] ?? 0); ?></span>
                    <span class="text-red-400">OUT: <?php echo formatAmount($kpis['cash_out_volume'] ?? 0); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 mb-8">
        <div class="flex justify-between items-center mb-6">
            <h2 class="font-black text-gray-800 text-lg uppercase tracking-tight"><?php echo $isHausa ? 'Jadawalin Ayyuka' : 'Graphique de Performance'; ?></h2>
            <div class="flex gap-2">
                <span class="flex items-center text-xs font-bold text-gray-400"><span class="w-3 h-3 bg-primary-500 rounded-full mr-1"></span> Volume</span>
                <span class="flex items-center text-xs font-bold text-gray-400"><span class="w-3 h-3 bg-indigo-500 rounded-full mr-1"></span> Commission</span>
            </div>
        </div>
        <div class="h-72 w-full">
            <canvas id="agentChart"></canvas>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        <div class="px-8 py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/30">
            <h2 class="font-black text-gray-900 text-xl"><?php echo $isHausa ? 'Tarihin Ma\'amaloli' : 'Registre des Transactions'; ?></h2>
            <button class="text-gray-400 hover:text-primary-600"><i class="fas fa-filter mr-1"></i> Filter</button>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead class="bg-gray-50 text-gray-400 text-[11px] uppercase tracking-[0.2em] font-bold">
                    <tr>
                        <th class="px-8 py-4">Transaction ID</th>
                        <th class="px-8 py-4">Client Info</th>
                        <th class="px-8 py-4 text-right">Amount</th>
                        <th class="px-8 py-4 text-right">Comm.</th>
                        <th class="px-8 py-4 text-center">Status</th>
                        <th class="px-8 py-4 text-center">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($activities as $act): ?>
                    <tr class="hover:bg-primary-50/30 transition-colors">
                        <td class="px-8 py-5">
                            <div class="font-mono text-xs font-bold text-gray-800"><?php echo substr($act['transaction_id'], 0, 14); ?>...</div>
                            <div class="text-[10px] text-gray-400 mt-1 uppercase font-bold"><?php echo date('d M Y | H:i', strtotime($act['created_at'])); ?></div>
                        </td>
                        <td class="px-8 py-5">
                            <div class="text-sm font-bold text-gray-900"><?php echo htmlspecialchars($act['s_phone'] ?: $act['r_phone']); ?></div>
                            <div class="text-[10px] font-black uppercase <?php echo $act['transaction_type'] === 'cash_in' ? 'text-green-500' : 'text-red-500'; ?>">
                                <i class="fas <?php echo $act['transaction_type'] === 'cash_in' ? 'fa-arrow-down' : 'fa-arrow-up'; ?> mr-1"></i>
                                <?php echo str_replace('_', ' ', $act['transaction_type']); ?>
                            </div>
                        </td>
                        <td class="px-8 py-5 text-right font-black text-gray-900"><?php echo formatAmount($act['amount']); ?></td>
                        <td class="px-8 py-5 text-right font-black text-indigo-600">+<?php echo formatAmount($act['commission_amount']); ?></td>
                        <td class="px-8 py-5 text-center">
                            <span class="px-3 py-1 rounded-full text-[10px] font-black uppercase <?php echo $act['status'] === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'; ?>">
                                <?php echo $act['status']; ?>
                            </span>
                        </td>
                        <td class="px-8 py-5 text-center">
                            <a href="receipt.php?id=<?php echo $act['transaction_id']; ?>" target="_blank" class="bg-gray-100 hover:bg-primary-100 text-gray-600 hover:text-primary-700 p-2.5 rounded-lg transition-all inline-flex items-center shadow-sm">
                                <i class="fas fa-file-invoice mr-2 text-xs"></i> <span class="text-[11px] font-bold uppercase">Receipt</span>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <?php endif; ?>
</div>

<div id="rechargeModal" class="hidden fixed inset-0 z-50 overflow-auto bg-gray-900/60 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 transform transition-all">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-2xl font-black text-gray-900"><?php echo $isHausa ? 'Bada Jari (Float)' : 'Recharger Float'; ?></h3>
            <button onclick="toggleModal('rechargeModal')" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
            <?php csrfField(); ?>
            <input type="hidden" name="action" value="recharge_float">
            <div class="mb-6">
                <label class="block text-sm font-bold text-gray-700 mb-2 uppercase tracking-wide">Yawan Kuɗi (Amount)</label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-gray-400 font-bold">XOF</span>
                    <input type="number" name="amount" required class="w-full pl-16 pr-4 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-primary-500 focus:ring-0 transition-all text-xl font-black" placeholder="0.00">
                </div>
            </div>
            <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-black py-4 rounded-2xl shadow-lg transition-all transform hover:scale-[1.02]">
                <?php echo $isHausa ? 'TABBATAR' : 'CONFIRMER'; ?>
            </button>
        </form>
    </div>
</div>

<div id="editModal" class="hidden fixed inset-0 z-50 overflow-auto bg-gray-900/60 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-2xl font-black text-gray-900"><?php echo $isHausa ? 'Gyara Bayani' : 'Modifier Profil'; ?></h3>
            <button onclick="toggleModal('editModal')" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
        </div>
        <form class="space-y-4">
            <div>
                <label class="block text-xs font-bold text-gray-400 uppercase mb-1">Business Name</label>
                <input type="text" value="<?php echo htmlspecialchars($agent['business_name']); ?>" class="w-full px-4 py-3 bg-gray-50 border-2 border-gray-100 rounded-xl font-bold">
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-400 uppercase mb-1">Commission Rate (%)</label>
                <input type="number" step="0.1" value="<?php echo ($agent['commission_rate']*100); ?>" class="w-full px-4 py-3 bg-gray-50 border-2 border-gray-100 rounded-xl font-bold">
            </div>
            <button type="button" class="w-full bg-gray-900 text-white font-black py-4 rounded-2xl mt-4"><?php echo $isHausa ? 'ADANA' : 'ENREGISTRER'; ?></button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
function toggleModal(id) { document.getElementById(id).classList.toggle('hidden'); }

document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('agentChart').getContext('2d');
    const chartLabels = <?php echo json_encode(array_map(function($d) { return date('d/m', strtotime($d['date'])); }, $chartData)); ?>;
    const volumeData = <?php echo json_encode(array_map(function($d) { return $d['volume']; }, $chartData)); ?>;
    const commissionData = <?php echo json_encode(array_map(function($d) { return $d['commission']; }, $chartData)); ?>;

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartLabels,
            datasets: [
                {
                    label: 'Volume',
                    data: volumeData,
                    borderColor: '#14b8a6',
                    backgroundColor: 'rgba(20, 184, 166, 0.05)',
                    borderWidth: 4,
                    tension: 0.4,
                    fill: true,
                    yAxisID: 'y'
                },
                {
                    label: 'Comm',
                    data: commissionData,
                    borderColor: '#6366f1',
                    borderWidth: 3,
                    borderDash: [5, 5],
                    tension: 0.4,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { display: false } },
                y: { display: false },
                y1: { display: false }
            }
        }
    });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>