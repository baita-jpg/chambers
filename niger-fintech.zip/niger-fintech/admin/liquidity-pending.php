<?php
/**
 * Niger Fintech System - Liquidity & Float Management
 */
require_once __DIR__ . '/../includes/auth.php';

// Verify Access (Admin or Super Agent only)
if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['admin', 'super_agent'])) {
    header('Location: /login.php');
    exit;
}

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');
$message = '';
$error = '';

// --- HANDLE APPROVAL / REJECTION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['movement_id'], $_POST['action'])) {
    if (validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $movementId = (int)$_POST['movement_id'];
        $action = $_POST['action']; // 'approve' or 'reject'
        
        try {
            $db->beginTransaction();

            // 1. Fetch movement details
            $stmt = $db->prepare("SELECT * FROM liquidity_movements WHERE id = ? AND status = 'pending'");
            $stmt->execute([$movementId]);
            $mov = $stmt->fetch();

            if ($mov) {
                if ($action === 'approve') {
                    // Update Agent's Float Wallet
                    $stmt = $db->prepare("
                        UPDATE wallet_accounts 
                        SET balance = balance + ?, available_balance = available_balance + ? 
                        WHERE user_id = ? AND account_type = 'float'
                    ");
                    $stmt->execute([$mov['amount'], $mov['amount'], $mov['to_user_id']]);

                    // Mark movement as completed
                    $stmt = $db->prepare("UPDATE liquidity_movements SET status = 'completed', verified_by = ?, verified_at = NOW() WHERE id = ?");
                    $stmt->execute([getCurrentUser()['id'], $movementId]);
                    
                    logActivity('liquidity_movements', $movementId, 'APPROVE_LIQUIDITY', [], ['amount' => $mov['amount']]);
                    $message = $isHausa ? "An yi nasarar amincewa da kuɗin." : "Liquidité approuvée avec succès.";
                } else {
                    // Mark as rejected
                    $stmt = $db->prepare("UPDATE liquidity_movements SET status = 'rejected', verified_by = ?, verified_at = NOW() WHERE id = ?");
                    $stmt->execute([getCurrentUser()['id'], $movementId]);
                    $message = $isHausa ? "An ƙi karɓar wannan buƙatar." : "Demande rejetée.";
                }
            }
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            $error = $isHausa ? "Kuskure ya faru: " : "Une erreur est survenue: " . $e->getMessage();
        }
    }
}

// --- FETCH PENDING REQUESTS ---
try {
    $stmt = $db->query("
        SELECT lm.*, u.first_name, u.last_name, ad.agent_code, ad.business_name
        FROM liquidity_movements lm
        JOIN users u ON lm.to_user_id = u.id
        LEFT JOIN agent_details ad ON u.id = ad.user_id
        WHERE lm.status = 'pending'
        ORDER BY lm.created_at ASC
    ");
    $pendingMovements = $stmt->fetchAll();
} catch (PDOException $e) {
    $pendingMovements = [];
}

if (!function_exists('formatAmount')) {
    function formatAmount($amount) { return number_format((float)$amount, 0, ',', ' ') . ' FCFA'; }
}

$pageTitle = $isHausa ? 'Kuɗaɗen jiran amincewa' : 'Liquidité en attente';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto pb-10">
    <div class="flex flex-col md:flex-row justify-between items-center mb-8 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <div>
            <h1 class="text-2xl font-black text-gray-900 uppercase tracking-tight">
                <?php echo $isHausa ? 'Gudanar da Jari (Float)' : 'Gestion de la Liquidité'; ?>
            </h1>
            <p class="text-gray-500 text-sm mt-1">
                <?php echo $isHausa ? 'Tantance ajiyar kuɗi daga banki don ƙara jari ga wakilai.' : 'Vérifier les dépôts bancaires pour créditer le float des agents.'; ?>
            </p>
        </div>
        <div class="mt-4 md:mt-0">
            <span class="px-4 py-2 bg-primary-50 text-primary-700 rounded-lg text-xs font-black uppercase border border-primary-100">
                <?php echo count($pendingMovements); ?> <?php echo $isHausa ? 'Suna jiran dubawa' : 'En attente'; ?>
            </span>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded-r-xl shadow-sm flex items-center">
            <i class="fas fa-check-circle text-green-500 mr-3"></i>
            <p class="text-sm font-bold text-green-800"><?php echo $message; ?></p>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-xl shadow-sm flex items-center">
            <i class="fas fa-exclamation-circle text-red-500 mr-3"></i>
            <p class="text-sm font-bold text-red-800"><?php echo $error; ?></p>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 gap-6">
        <?php if (empty($pendingMovements)): ?>
            <div class="bg-white rounded-3xl p-20 text-center border-2 border-dashed border-gray-100">
                <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-300">
                    <i class="fas fa-check-double text-3xl"></i>
                </div>
                <h3 class="text-gray-900 font-bold text-lg"><?php echo $isHausa ? 'Babu buƙatun jiran amincewa' : 'Tout est à jour'; ?></h3>
                <p class="text-gray-400 text-sm"><?php echo $isHausa ? 'Duk buƙatun kuɗaɗe an riga an tantance su.' : 'Toutes les demandes de liquidité ont été traitées.'; ?></p>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-400 text-[11px] uppercase tracking-widest font-black border-b border-gray-100">
                                <th class="px-6 py-4"><?php echo $isHausa ? 'Wakili / Kasuwanci' : 'Agent / Entreprise'; ?></th>
                                <th class="px-6 py-4"><?php echo $isHausa ? 'Nau\'i' : 'Type'; ?></th>
                                <th class="px-6 py-4 text-right"><?php echo $isHausa ? 'Yawa' : 'Montant'; ?></th>
                                <th class="px-6 py-4"><?php echo $isHausa ? 'Bayanai' : 'Détails'; ?></th>
                                <th class="px-6 py-4 text-center"><?php echo $isHausa ? 'Ayyuka' : 'Actions'; ?></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                            <?php foreach ($pendingMovements as $mov): ?>
                            <tr class="hover:bg-gray-50/50 transition-colors">
                                <td class="px-6 py-5">
                                    <div class="font-bold text-gray-900"><?php echo htmlspecialchars($mov['business_name'] ?: $mov['first_name'].' '.$mov['last_name']); ?></div>
                                    <div class="text-xs text-primary-600 font-mono font-bold"><?php echo $mov['agent_code']; ?></div>
                                </td>
                                <td class="px-6 py-5 text-sm uppercase font-black text-gray-400 italic">
                                    <?php echo str_replace('_', ' ', $mov['movement_type']); ?>
                                </td>
                                <td class="px-6 py-5 text-right font-black text-lg text-gray-900">
                                    <?php echo formatAmount($mov['amount']); ?>
                                </td>
                                <td class="px-6 py-5 text-xs text-gray-500 max-w-xs">
                                    <?php if ($mov['bank_name']): ?>
                                        <span class="block font-bold text-gray-700 underline"><?php echo htmlspecialchars($mov['bank_name']); ?></span>
                                    <?php endif; ?>
                                    <?php echo htmlspecialchars($mov['notes']); ?>
                                    <div class="mt-1 text-[10px] text-gray-400 font-bold"><?php echo date('d M Y | H:i', strtotime($mov['created_at'])); ?></div>
                                </td>
                                <td class="px-6 py-5 text-center">
                                    <form method="POST" class="flex justify-center gap-2">
                                        <?php csrfField(); ?>
                                        <input type="hidden" name="movement_id" value="<?php echo $mov['id']; ?>">
                                        
                                        <button type="submit" name="action" value="approve" 
                                                class="bg-green-600 hover:bg-green-700 text-white p-2.5 rounded-lg shadow-sm transition-transform hover:scale-110"
                                                onclick="return confirm('<?php echo $isHausa ? 'Ka tabbata kana so ka amince da wannan kuɗin?' : 'Confirmer le rechargement du float ?'; ?>')">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        
                                        <button type="submit" name="action" value="reject" 
                                                class="bg-red-50 text-red-500 hover:bg-red-500 hover:text-white p-2.5 rounded-lg transition-all"
                                                onclick="return confirm('<?php echo $isHausa ? 'Ka tabbata kana so ka ƙi wannan?' : 'Rejeter cette demande ?'; ?>')">
                                            <i class="fas fa-times"></i>
                                        </button>

                                        <?php if ($mov['deposit_slip_url']): ?>
                                        <a href="<?php echo htmlspecialchars($mov['deposit_slip_url']); ?>" target="_blank" class="bg-gray-100 text-gray-400 p-2.5 rounded-lg hover:bg-gray-200">
                                            <i class="fas fa-paperclip"></i>
                                        </a>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-12 bg-indigo-900 rounded-3xl p-8 text-white flex flex-col md:flex-row items-center justify-between shadow-xl">
        <div class="flex items-center mb-4 md:mb-0">
            <div class="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mr-4">
                <i class="fas fa-info-circle text-xl"></i>
            </div>
            <div>
                <h4 class="font-bold text-lg"><?php echo $isHausa ? 'Tsanaki: Tantancewa tana da mahimmanci' : 'Attention: La vérification est cruciale'; ?></h4>
                <p class="text-indigo-200 text-sm"><?php echo $isHausa ? 'Kada ka amince da buƙata har sai ka tabbatar kuɗin sun shiga asusun banki.' : 'Ne confirmez pas avant d\'avoir vérifié la réception réelle sur le compte bancaire.'; ?></p>
            </div>
        </div>
        <div class="text-right">
            <p class="text-[10px] uppercase font-black tracking-widest text-indigo-400"><?php echo $isHausa ? 'Tsaro na NigerPay' : 'NigerPay Security'; ?></p>
            <p class="text-sm font-mono"><?php echo $_SERVER['REMOTE_ADDR']; ?></p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>