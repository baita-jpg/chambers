<?php
/**
 * NigerPay - Customer Management Directory
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/ledger.php';

requireRole('admin');

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Fetch all customers with their primary account balance
$query = "
    SELECT 
        u.id, u.first_name, u.last_name, u.phone_number, u.kyc_tier, u.is_active,
        wa.balance, wa.account_number
    FROM users u
    LEFT JOIN wallet_accounts wa ON u.id = wa.user_id AND wa.account_type = 'primary'
    WHERE u.user_type = 'customer'
    ORDER BY u.created_at DESC
";
$customers = $db->query($query)->fetchAll();

$pageTitle = $isHausa ? 'Abokan Ciniki' : 'Gestion des Clients';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto pb-20">
    <div class="flex justify-between items-end mb-10">
        <div>
            <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $pageTitle; ?></h1>
            <p class="text-slate-500 font-medium">Total registered users: <?php echo count($customers); ?></p>
        </div>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <tr>
                    <th class="px-8 py-5">Customer Details</th>
                    <th class="px-8 py-5">Account Number</th>
                    <th class="px-8 py-5">KYC Level</th>
                    <th class="px-8 py-5">Balance (XOF)</th>
                    <th class="px-8 py-5 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-50">
                <?php foreach($customers as $c): ?>
                <tr class="hover:bg-slate-50/50 transition-colors">
                    <td class="px-8 py-6">
                        <p class="text-sm font-black text-slate-900"><?php echo $c['first_name'] . ' ' . $c['last_name']; ?></p>
                        <p class="text-[10px] font-bold text-slate-400"><?php echo $c['phone_number']; ?></p>
                    </td>
                    <td class="px-8 py-6">
                        <span class="font-mono text-xs bg-slate-100 px-2 py-1 rounded"><?php echo $c['account_number'] ?? 'N/A'; ?></span>
                    </td>
                    <td class="px-8 py-6">
                        <span class="text-[10px] font-black px-3 py-1 rounded-full uppercase <?php echo $c['kyc_tier'] == 3 ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600'; ?>">
                            Tier <?php echo $c['kyc_tier']; ?>
                        </span>
                    </td>
                    <td class="px-8 py-6 font-black text-slate-900">
                        <?php echo number_format($c['balance']); ?>
                    </td>
                    <td class="px-8 py-6 text-right space-x-2">
                        <button class="text-slate-400 hover:text-primary-600"><i class="fas fa-eye"></i></button>
                        <button class="text-slate-400 hover:text-red-600"><i class="fas fa-user-slash"></i></button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>