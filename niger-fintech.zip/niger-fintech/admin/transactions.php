<?php
/**
 * Niger Fintech System - Master Transaction Ledger
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || getCurrentUser()['user_type'] !== 'admin') { header('Location: /login.php'); exit; }

if (!function_exists('formatAmount')) {
    function formatAmount($amount) { return number_format((float)$amount, 0, ',', ' ') . ' FCFA'; }
}

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');

try {
    $stmt = $db->query("
        SELECT t.*, 
               sender.first_name as s_fname, sender.last_name as s_lname,
               receiver.first_name as r_fname, receiver.last_name as r_lname
        FROM transactions t
        LEFT JOIN users sender ON t.sender_user_id = sender.id
        LEFT JOIN users receiver ON t.receiver_user_id = receiver.id
        ORDER BY t.created_at DESC LIMIT 100
    ");
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $transactions = [];
}

$pageTitle = $isHausa ? 'Ma\'amaloli - NigerPay' : 'Transactions - NigerPay';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto">
    <h1 class="text-2xl font-bold text-gray-900 mb-6"><?php echo $isHausa ? 'Duk Ma\'amaloli' : 'Toutes les Transactions'; ?></h1>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 font-medium">ID</th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Nau\'i' : 'Type'; ?></th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Mai aikawa' : 'Expéditeur'; ?></th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Mai karɓa' : 'Destinataire'; ?></th>
                        <th class="px-6 py-4 text-right font-medium"><?php echo $isHausa ? 'Yawa' : 'Montant'; ?></th>
                        <th class="px-6 py-4 text-center font-medium"><?php echo $isHausa ? 'Matsayi' : 'Statut'; ?></th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Kwanan wata' : 'Date'; ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($transactions as $tx): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 text-xs font-mono text-gray-500"><?php echo substr($tx['transaction_id'], 0, 12); ?>...</td>
                        <td class="px-6 py-4 text-sm font-medium text-gray-700 capitalize"><?php echo str_replace('_', ' ', $tx['transaction_type']); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-800"><?php echo htmlspecialchars(trim($tx['s_fname'] . ' ' . $tx['s_lname']) ?: $tx['sender_phone'] ?: '-'); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-800"><?php echo htmlspecialchars(trim($tx['r_fname'] . ' ' . $tx['r_lname']) ?: $tx['receiver_phone'] ?: '-'); ?></td>
                        <td class="px-6 py-4 text-right font-bold text-gray-900"><?php echo formatAmount($tx['amount']); ?></td>
                        <td class="px-6 py-4 text-center">
                            <span class="px-2 py-1 text-xs font-medium rounded-md <?php echo $tx['status'] === 'completed' ? 'bg-green-50 text-green-700' : ($tx['status'] === 'pending' ? 'bg-yellow-50 text-yellow-700' : 'bg-red-50 text-red-700'); ?>">
                                <?php echo ucfirst($tx['status']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-xs text-gray-500"><?php echo date('d/m/Y H:i', strtotime($tx['created_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>