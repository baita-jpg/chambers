<?php
/**
 * NigerPay - Admin Broadcast Center
 */
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCSRFToken($_POST['csrf_token'] ?? '')) {
    $title = sanitizeInput($_POST['title']);
    $content = sanitizeInput($_POST['message']);
    $severity = $_POST['severity'];

    // Deactivate old broadcasts first
    $db->query("UPDATE global_notifications SET is_active = 0");

    // Insert new broadcast
    $stmt = $db->prepare("INSERT INTO global_notifications (title, message, severity, is_active) VALUES (?, ?, ?, 1)");
    $stmt->execute([$title, $content, $severity]);
    
    $message = $isHausa ? "An tura sako ga dukkan wakilai!" : "Message diffusé à tous les agents !";
}

$pageTitle = $isHausa ? 'Tura Sako' : 'Diffusion de Message';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-2xl mx-auto pb-20">
    <div class="mb-10">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $pageTitle; ?></h1>
        <p class="text-slate-500 font-medium italic">Communicate maintenance schedules or urgent updates to the network.</p>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 p-10">
        <?php if($message): ?>
            <div class="bg-primary-50 text-primary-700 p-4 rounded-2xl mb-6 font-bold flex items-center">
                <i class="fas fa-bullhorn mr-3"></i> <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <?php csrfField(); ?>
            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Urgency Level</label>
                <select name="severity" class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-bold">
                    <option value="info">Information (Blue)</option>
                    <option value="warning">Warning (Orange)</option>
                    <option value="danger">Urgent/Maintenance (Red)</option>
                </select>
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Subject</label>
                <input type="text" name="title" required placeholder="e.g. System Update at 2:00 PM" 
                       class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-bold focus:border-primary-500 transition-all">
            </div>

            <div class="space-y-2">
                <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Message Content</label>
                <textarea name="message" rows="4" required class="w-full px-6 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-medium focus:border-primary-500 transition-all"></textarea>
            </div>

            <button type="submit" class="w-full bg-slate-900 text-white font-black py-5 rounded-3xl shadow-xl hover:bg-primary-600 transition-all uppercase tracking-widest">
                <i class="fas fa-paper-plane mr-2"></i> Send Broadcast
            </button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>