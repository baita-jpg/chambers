<?php
/**
 * NigerPay - Admin Audit & System Logs
 */
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Fetch the audit logs
$logs = $db->query("
    SELECT al.*, u.first_name, u.user_type 
    FROM audit_logs al 
    LEFT JOIN users u ON al.performed_by = u.id 
    ORDER BY al.created_at DESC 
    LIMIT 100
")->fetchAll();

$pageTitle = $isHausa ? 'Tarihin Ayyuka' : 'Journaux Système';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto pb-20">
    <div class="mb-10">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $pageTitle; ?></h1>
        <p class="text-slate-500 font-medium italic">Detailed record of all administrative and security events.</p>
    </div>

    <div class="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <tr>
                        <th class="px-8 py-5">Timestamp</th>
                        <th class="px-8 py-5">Admin / User</th>
                        <th class="px-8 py-5">Action</th>
                        <th class="px-8 py-5">Affected Record</th>
                        <th class="px-8 py-5">IP Address</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                    <?php foreach($logs as $log): ?>
                    <tr class="hover:bg-slate-50/50 transition-colors">
                        <td class="px-8 py-5 text-xs font-mono text-slate-400">
                            <?php echo date('d/m/Y H:i:s', strtotime($log['created_at'])); ?>
                        </td>
                        <td class="px-8 py-5">
                            <span class="text-sm font-black text-slate-900"><?php echo $log['first_name'] ?? 'System'; ?></span>
                            <span class="text-[9px] bg-slate-100 px-2 py-0.5 rounded ml-1 text-slate-500 uppercase"><?php echo $log['user_type'] ?? 'CRON'; ?></span>
                        </td>
                        <td class="px-8 py-5">
                            <span class="text-xs font-bold <?php echo str_contains($log['action'], 'DELETE') || str_contains($log['action'], 'DENIED') ? 'text-red-600' : 'text-primary-600'; ?>">
                                <?php echo str_replace('_', ' ', $log['action']); ?>
                            </span>
                        </td>
                        <td class="px-8 py-5 text-xs text-slate-500">
                            <?php echo $log['table_name']; ?> (ID: <?php echo $log['record_id']; ?>)
                        </td>
                        <td class="px-8 py-5 text-xs font-mono text-slate-400">
                            <?php echo $log['ip_address']; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>