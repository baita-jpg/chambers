<?php
/**
 * NigerPay - System Alerts & Resolution
 */
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Handle Resolution (Mark as Read)
if (isset($_POST['resolve_id'])) {
    $alertId = (int)$_POST['resolve_id'];
    $stmt = $db->prepare("UPDATE system_alerts SET is_read = 1 WHERE id = ?");
    $stmt->execute([$alertId]);
    setFlashMessage('success', 'Alert resolved.');
}

// Fetch only unread alerts
$alerts = $db->query("
    SELECT sa.*, u.first_name, ad.agent_code, wa.available_balance
    FROM system_alerts sa
    JOIN users u ON sa.agent_id = u.id
    JOIN agent_details ad ON u.id = ad.user_id
    JOIN wallet_accounts wa ON u.id = wa.user_id AND wa.account_type = 'float'
    WHERE sa.is_read = 0
    ORDER BY sa.created_at DESC
")->fetchAll();

$pageTitle = $isHausa ? 'Sanarwar Tsarin' : 'Alertes Système';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-4xl mx-auto pb-20">
    <div class="mb-10">
        <h1 class="text-3xl font-black text-slate-900 tracking-tight"><?php echo $pageTitle; ?></h1>
        <p class="text-slate-500 font-medium">Attention required for the following system events.</p>
    </div>

    <div class="space-y-4">
        <?php foreach($alerts as $alert): ?>
        <div class="bg-white p-8 rounded-[2.5rem] shadow-soft border-l-8 border-orange-500 flex items-center justify-between">
            <div class="flex items-center">
                <div class="w-12 h-12 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center text-xl mr-6">
                    <i class="fas fa-triangle-exclamation"></i>
                </div>
                <div>
                    <h4 class="font-black text-slate-900 uppercase text-xs tracking-widest mb-1">
                        Low Float: <?php echo $alert['first_name']; ?> (<?php echo $alert['agent_code']; ?>)
                    </h4>
                    <p class="text-sm text-slate-600 font-medium"><?php echo $alert['message']; ?></p>
                    <p class="text-[10px] text-slate-400 mt-2 font-bold"><?php echo date('M d, H:i', strtotime($alert['created_at'])); ?></p>
                </div>
            </div>

            <div class="flex flex-col items-end gap-3">
                <span class="text-xl font-black text-red-600"><?php echo number_format($alert['available_balance']); ?> <span class="text-xs">XOF</span></span>
                
                <form method="POST">
                    <input type="hidden" name="resolve_id" value="<?php echo $alert['id']; ?>">
                    <button type="submit" class="bg-slate-900 text-white px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-primary-600 transition-colors">
                        Mark Resolved
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>

        <?php if(empty($alerts)): ?>
        <div class="text-center py-20 bg-slate-50 rounded-[3rem] border-2 border-dashed border-slate-200">
            <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm text-green-500">
                <i class="fas fa-check-circle text-2xl"></i>
            </div>
            <p class="text-slate-400 font-bold uppercase tracking-widest text-xs">All systems healthy. No active alerts.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>