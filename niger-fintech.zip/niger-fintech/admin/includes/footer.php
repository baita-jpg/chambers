<?php
/**
 * Niger Fintech System - Footer with JS Sidebar Toggle
 */
?>
        </main>
        
        <footer class="bg-white border-t border-gray-100 py-4 px-8 mt-auto">
            <div class="flex flex-col md:flex-row justify-between items-center text-[10px] font-black uppercase tracking-widest text-gray-400">
                <p>&copy; 2026 NigerPay. BCEAO LICENSED.</p>
                <div class="space-x-4">
                    <a href="#" class="hover:text-primary-600">Privacy</a>
                    <a href="#" class="hover:text-primary-600">Terms</a>
                </div>
            </div>
        </footer>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const toggleBtn = document.getElementById('toggleSidebar');
            const sidebar = document.getElementById('sidebar');
            
            // Restore preference from LocalStorage
            if (localStorage.getItem('sidebar-collapsed') === 'true') {
                sidebar.classList.add('sidebar-collapsed');
            }

            toggleBtn.addEventListener('click', () => {
                // Mobile Toggle
                if (window.innerWidth < 1024) {
                    sidebar.classList.toggle('mobile-open');
                } else {
                    // Desktop Toggle
                    sidebar.classList.toggle('sidebar-collapsed');
                    localStorage.setItem('sidebar-collapsed', sidebar.classList.contains('sidebar-collapsed'));
                }
            });

            // Close mobile sidebar when clicking outside (on main content)
            document.querySelector('main').addEventListener('click', () => {
                if (window.innerWidth < 1024) {
                    sidebar.classList.remove('mobile-open');
                }
            });
        });
    </script>
</body>
</html>