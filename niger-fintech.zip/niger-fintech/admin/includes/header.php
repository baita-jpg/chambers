<?php
/**
 * Niger Fintech System - Master Header
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle Language Toggle
if (isset($_GET['lang']) && in_array($_GET['lang'], ['ha', 'fr'])) {
    $_SESSION['lang'] = $_GET['lang'];
    // Redirect to remove the ?lang parameter from the URL
    $clean_url = strtok($_SERVER["REQUEST_URI"], '?');
    header("Location: $clean_url");
    exit;
}

$lang = $_SESSION['lang'] ?? 'ha';
$isHausa = ($lang === 'ha');

// Fallback to empty user if not logged in yet (for public pages using this header)
$currentUser = function_exists('getCurrentUser') ? getCurrentUser() : ['first_name' => 'Guest', 'user_type' => 'customer'];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) : 'NigerPay'; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
                    colors: {
                        primary: { 50: '#f0fdfa', 100: '#ccfbf1', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e', 800: '#115e59', 900: '#134e4a' }
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
        /* Scrollbar styling for a cleaner look */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #0d9488; }

        /* Sidebar Tooltip Logic */
#sidebar.sidebar-collapsed .menu-item {
    position: relative;
}

/* Create the tooltip box */
#sidebar.sidebar-collapsed .menu-item::after {
    content: attr(data-tooltip);
    position: absolute;
    left: 100%;
    margin-left: 10px;
    top: 50%;
    transform: translateY(-50%);
    background: #1f2937; /* Gray-800 */
    color: white;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.2s;
    z-index: 100;
    box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
}

/* Tooltip Arrow */
#sidebar.sidebar-collapsed .menu-item::before {
    content: '';
    position: absolute;
    left: 100%;
    margin-left: 4px;
    top: 50%;
    transform: translateY(-50%);
    border-width: 5px;
    border-style: solid;
    border-color: transparent #1f2937 transparent transparent;
    opacity: 0;
    visibility: hidden;
    z-index: 100;
}

/* Show on hover only when collapsed */
#sidebar.sidebar-collapsed .menu-item:hover::after,
#sidebar.sidebar-collapsed .menu-item:hover::before {
    opacity: 1;
    visibility: visible;
}
    </style>
</head>
<body class="bg-gray-50 text-gray-800 font-sans flex h-screen overflow-hidden">

    <?php 
    if (isset($_SESSION['user_id']) && in_array($currentUser['user_type'], ['admin', 'super_agent', 'agent'])) {
        include __DIR__ . '/sidebar.php'; 
    }
    ?>

    <div class="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
        
        <header class="bg-white shadow-sm sticky top-0 z-20">
            <div class="flex items-center justify-between px-6 py-4">
                
                <div class="flex items-center">
                    <?php if (isset($_SESSION['user_id'])): ?>
                    <button id="mobileMenuBtn" class="text-gray-500 hover:text-primary-600 focus:outline-none lg:hidden mr-4">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <?php endif; ?>
                    
                    <div class="relative hidden sm:block">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="fas fa-search text-gray-400"></i>
                        </span>
                        <input type="text" placeholder="<?php echo $isHausa ? 'Bincika ma\'amala...' : 'Rechercher...'; ?>" class="pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent w-64 bg-gray-50">
                    </div>
                </div>

                <div class="flex items-center space-x-4">
                    
                    <div class="flex bg-gray-100 rounded-lg p-1">
                        <a href="?lang=ha" class="px-3 py-1 text-xs font-medium rounded-md transition <?php echo $isHausa ? 'bg-white shadow-sm text-primary-700' : 'text-gray-500 hover:text-gray-700'; ?>">
                            HA
                        </a>
                        <a href="?lang=fr" class="px-3 py-1 text-xs font-medium rounded-md transition <?php echo !$isHausa ? 'bg-white shadow-sm text-primary-700' : 'text-gray-500 hover:text-gray-700'; ?>">
                            FR
                        </a>
                    </div>

                    <button class="text-gray-400 hover:text-primary-600 relative">
                        <i class="far fa-bell text-xl"></i>
                        <span class="absolute top-0 right-0 -mt-1 -mr-1 flex h-3 w-3">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                        </span>
                    </button>

                    <div class="relative flex items-center border-l border-gray-200 pl-4 ml-2">
                        <div class="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-sm mr-2 border border-primary-200">
                            <?php echo substr($currentUser['first_name'], 0, 1); ?>
                        </div>
                        <div class="hidden md:block">
                            <p class="text-sm font-semibold text-gray-700"><?php echo htmlspecialchars($currentUser['first_name']); ?></p>
                            <p class="text-xs text-gray-500 capitalize"><?php echo str_replace('_', ' ', $currentUser['user_type']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <main class="w-full flex-grow p-6 bg-gray-50">