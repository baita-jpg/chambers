<?php
/**
 * NigerPay - Full Comprehensive Admin Sidebar
 * Includes every module built for the MVP.
 */
// require_once __DIR__ . '/functions.php';

$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';
$currentPath = basename($_SERVER['PHP_SELF']);

// Helper to highlight active link
function getActiveNav($page, $currentPath) {
    return ($page === $currentPath) 
        ? 'bg-primary-600 text-white shadow-lg shadow-primary-900/40' 
        : 'text-slate-400 hover:bg-slate-800 hover:text-white';
}

// Live alert counter for the sidebar
$db = getDB();
$pendingAlerts = $db->query("SELECT COUNT(*) FROM system_alerts WHERE is_read = 0")->fetchColumn() ?: 0;
$pendingFloat = $db->query("SELECT COUNT(*) FROM liquidity_movements WHERE status = 'pending'")->fetchColumn() ?: 0;
?>

<aside id="admin-sidebar" class="bg-slate-950 w-72 flex-shrink-0 hidden lg:flex flex-col h-screen sticky top-0 z-50 border-r border-white/5">
    
    <div class="h-24 flex items-center px-8 border-b border-white/5">
        <div class="w-10 h-10 bg-gradient-to-tr from-primary-600 to-primary-400 rounded-2xl flex items-center justify-center shadow-xl">
            <i class="fas fa-shield-check text-white text-xl"></i>
        </div>
        <div class="ml-4">
            <span class="block text-white font-black text-xl tracking-tighter uppercase leading-none">Niger<span class="text-primary-500">Pay</span></span>
            <span class="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em]">Core v3.1 Paid</span>
        </div>
    </div>

    <nav class="flex-1 px-4 py-6 space-y-1 overflow-y-auto no-scrollbar">
        
        <a href="dashboard.php" class="flex items-center px-4 py-3.5 rounded-2xl transition-all <?php echo getActiveNav('dashboard.php', $currentPath); ?>">
            <i class="fas fa-chart-line text-lg w-8"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Babban Shafi' : 'Tableau de Bord'; ?></span>
        </a>

        <div class="pt-6 pb-2 px-4 text-[10px] font-black text-slate-600 uppercase tracking-[0.2em]">Network Control</div>
        
        <a href="agents.php" class="flex items-center px-4 py-3.5 rounded-2xl transition-all group <?php echo getActiveNav('agents.php', $currentPath); ?>">
            <i class="fas fa-store text-lg w-8 text-slate-500 group-hover:text-white"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Gudanar da Wakilai' : 'Réseau d\'Agents'; ?></span>
        </a>

        <a href="add-agent.php" class="flex items-center px-4 py-3.5 rounded-2xl transition-all group <?php echo getActiveNav('add-agent.php', $currentPath); ?>">
            <i class="fas fa-user-plus text-lg w-8 text-slate-500 group-hover:text-white"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Ƙara Wakili' : 'Nouveau Agent'; ?></span>
        </a>

        <a href="customers.php" class="flex items-center px-4 py-3.5 rounded-2xl transition-all group <?php echo getActiveNav('customers.php', $currentPath); ?>">
            <i class="fas fa-users text-lg w-8 text-slate-500 group-hover:text-white"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Abokan Ciniki' : 'Portefeuille Clients'; ?></span>
        </a>

        <div class="pt-6 pb-2 px-4 text-[10px] font-black text-slate-600 uppercase tracking-[0.2em]">Financials</div>

        <a href="liquidity-approvals.php" class="flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all group <?php echo getActiveNav('liquidity-approvals.php', $currentPath); ?>">
            <div class="flex items-center">
                <i class="fas fa-money-bill-transfer text-lg w-8 text-slate-500 group-hover:text-white"></i>
                <span class="font-bold text-sm"><?php echo $isHausa ? 'Amincewa' : 'Approbations Float'; ?></span>
            </div>
            <?php if($pendingFloat > 0): ?>
                <span class="bg-primary-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full"><?php echo $pendingFloat; ?></span>
            <?php endif; ?>
        </a>

        <a href="bulk-reports.php" class="flex items-center px-4 py-3.5 rounded-2xl transition-all group <?php echo getActiveNav('bulk-reports.php', $currentPath); ?>">
            <i class="fas fa-file-invoice-dollar text-lg w-8 text-slate-500 group-hover:text-white"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Rahotanni' : 'Rapports d\'Activité'; ?></span>
        </a>

        <div class="pt-6 pb-2 px-4 text-[10px] font-black text-slate-600 uppercase tracking-[0.2em]">System & Security</div>

        <a href="alerts.php" class="flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all group <?php echo getActiveNav('alerts.php', $currentPath); ?>">
            <div class="flex items-center">
                <i class="fas fa-bell-exclamation text-lg w-8 text-slate-500 group-hover:text-white"></i>
                <span class="font-bold text-sm"><?php echo $isHausa ? 'Sanarwa' : 'Alertes Système'; ?></span>
            </div>
            <?php if($pendingAlerts > 0): ?>
                <span class="bg-red-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full animate-pulse"><?php echo $pendingAlerts; ?></span>
            <?php endif; ?>
        </a>

        <a href="settings.php" class="flex items-center px-4 py-3.5 rounded-2xl transition-all group <?php echo getActiveNav('settings.php', $currentPath); ?>">
            <i class="fas fa-gears text-lg w-8 text-slate-500 group-hover:text-white"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Saituna' : 'Configuration'; ?></span>
        </a>

        <a href="system-logs.php" class="flex items-center px-4 py-3.5 rounded-2xl transition-all group <?php echo getActiveNav('system-logs.php', $currentPath); ?>">
            <i class="fas fa-fingerprint text-lg w-8 text-slate-500 group-hover:text-white"></i>
            <span class="font-bold text-sm"><?php echo $isHausa ? 'Tarihin Tsarin' : 'Audit Logs'; ?></span>
        </a>
    </nav>

    <div class="p-6 border-t border-white/5 space-y-4">
        <div class="bg-slate-900 rounded-2xl p-4 flex items-center">
            <div class="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-300">AD</div>
            <div class="ml-3 overflow-hidden">
                <p class="text-xs font-black text-white truncate">Admin Account</p>
                <p class="text-[9px] text-slate-500 uppercase tracking-widest">Signed In</p>
            </div>
        </div>

        <a href="../logout.php" class="flex items-center justify-center p-4 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-2xl transition-all font-black text-[10px] uppercase tracking-widest">
            <i class="fas fa-power-off mr-3"></i> <?php echo $isHausa ? 'Fita' : 'Déconnexion'; ?>
        </a>
    </div>
</aside>