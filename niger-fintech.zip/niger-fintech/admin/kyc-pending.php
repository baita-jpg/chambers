<?php
/**
 * Niger Fintech System - KYC Approvals
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['admin', 'super_agent'])) {
    header('Location: /login.php');
    exit;
}

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');
$message = '';

// Handle Approve/Reject Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['action'])) {
    if (validateCSRFToken($_POST['csrf_token'])) {
        $status = $_POST['action'] === 'approve' ? 'approved' : 'rejected';
        $tier = $_POST['action'] === 'approve' ? 2 : 1; // Bump to Tier 2 on approval
        
        $stmt = $db->prepare("UPDATE users SET kyc_status = ?, kyc_tier = ?, approved_by = ?, approved_at = NOW() WHERE id = ?");
        $stmt->execute([$status, $tier, getCurrentUser()['id'], $_POST['user_id']]);
        
        $message = $isHausa ? "An sabunta matsayin KYC da nasara." : "Statut KYC mis à jour avec succès.";
    }
}

// Fetch Pending KYC
try {
    $stmt = $db->query("SELECT id, first_name, last_name, phone_number, nina_number, created_at FROM users WHERE kyc_status = 'pending' ORDER BY created_at ASC");
    $pendingUsers = $stmt->fetchAll();
} catch (PDOException $e) {
    $pendingUsers = [];
}

$pageTitle = $isHausa ? 'KYC na jiran amincewa' : 'KYC en attente';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto">
    <h1 class="text-2xl font-bold text-gray-900 mb-6"><?php echo $isHausa ? 'KYC na jiran amincewa' : 'Approbations KYC en attente'; ?></h1>

    <?php if ($message): ?>
        <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded-r-lg">
            <p class="text-sm text-green-700 font-medium"><?php echo $message; ?></p>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <?php if (empty($pendingUsers)): ?>
            <div class="p-8 text-center text-gray-500">
                <i class="fas fa-check-circle text-4xl text-green-400 mb-3"></i>
                <p><?php echo $isHausa ? 'Babu masu jiran amincewa a yanzu.' : 'Aucune demande KYC en attente.'; ?></p>
            </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 text-gray-500 text-xs uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Suna' : 'Nom'; ?></th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Waya' : 'Téléphone'; ?></th>
                        <th class="px-6 py-4 font-medium">NINA ID</th>
                        <th class="px-6 py-4 font-medium"><?php echo $isHausa ? 'Kwanan wata' : 'Date'; ?></th>
                        <th class="px-6 py-4 text-right font-medium"><?php echo $isHausa ? 'Ayyuka' : 'Actions'; ?></th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($pendingUsers as $u): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-4 font-medium text-gray-900"><?php echo htmlspecialchars($u['first_name'] . ' ' . $u['last_name']); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-600"><?php echo htmlspecialchars($u['phone_number']); ?></td>
                        <td class="px-6 py-4 text-sm font-mono text-gray-700"><?php echo htmlspecialchars($u['nina_number'] ?? 'N/A'); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?php echo date('d/m/Y', strtotime($u['created_at'])); ?></td>
                        <td class="px-6 py-4 text-right">
                            <form method="POST" class="inline">
                                <?php csrfField(); ?>
                                <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                <button type="submit" name="action" value="approve" class="bg-green-100 text-green-700 hover:bg-green-200 px-3 py-1 rounded-md text-sm font-medium mr-2 transition">
                                    <?php echo $isHausa ? 'Amince' : 'Approuver'; ?>
                                </button>
                                <button type="submit" name="action" value="reject" class="bg-red-100 text-red-700 hover:bg-red-200 px-3 py-1 rounded-md text-sm font-medium transition">
                                    <?php echo $isHausa ? 'Ƙi' : 'Rejeter'; ?>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>