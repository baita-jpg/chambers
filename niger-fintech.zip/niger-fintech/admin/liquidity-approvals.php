<?php
/**
 * NigerPay - Admin Float Approval Dashboard
 */
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/auth.php';
requireRole('admin'); // Custom helper from your auth file

$db = getDB();
$isHausa = ($_SESSION['lang'] ?? 'ha') === 'ha';

// Handle Approval
if (isset($_POST['approve_id'])) {
    $reqId = $_POST['approve_id'];
    
    executeInTransaction(function($db) use ($reqId) {
        // 1. Get request details
        $stmt = $db->prepare("SELECT * FROM liquidity_movements WHERE id = ? AND status = 'pending' FOR UPDATE");
        $stmt->execute([$reqId]);
        $req = $stmt->fetch();

        if ($req) {
            // 2. Credit Agent Float Account
            $stmt = $db->prepare("UPDATE wallet_accounts SET balance = balance + ?, available_balance = available_balance + ? WHERE user_id = ? AND account_type = 'float'");
            $stmt->execute([$req['amount'], $req['amount'], $req['agent_id']]);

            // 3. Mark request as completed
            $stmt = $db->prepare("UPDATE liquidity_movements SET status = 'completed', processed_at = NOW() WHERE id = ?");
            $stmt->execute([$reqId]);
        }
    });
}

// Fetch Pending Requests
$requests = $db->query("
    SELECT lm.*, u.first_name, u.phone_number 
    FROM liquidity_movements lm 
    JOIN users u ON lm.agent_id = u.id 
    WHERE lm.status = 'pending' 
    ORDER BY lm.created_at DESC
")->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="max-w-4xl mx-auto">
    <div class="mb-8">
        <h1 class="text-2xl font-black text-slate-900"><?php echo $isHausa ? 'Amincewar Float' : 'Approbations de Float'; ?></h1>
        <p class="text-slate-500"><?php echo $isHausa ? 'Saka kudi a asusun wakilai' : 'Validez les demandes de réapprovisionnement'; ?></p>
    </div>

    <div class="space-y-4">
        <?php foreach($requests as $r): ?>
        <div class="bg-white p-6 rounded-[2rem] shadow-soft border border-slate-100 flex items-center justify-between">
            <div class="flex items-center">
                <div class="w-12 h-12 bg-primary-100 text-primary-600 rounded-2xl flex items-center justify-center text-xl mr-4">
                    <i class="fas fa-money-bill-trend-up"></i>
                </div>
                <div>
                    <h4 class="font-black text-slate-900"><?php echo $r['first_name']; ?></h4>
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest"><?php echo $r['phone_number']; ?> • <?php echo $r['method']; ?></p>
                </div>
            </div>
            
            <div class="text-right flex items-center gap-6">
                <div>
                    <p class="text-lg font-black text-slate-900"><?php echo number_format($r['amount']); ?> XOF</p>
                    <p class="text-[9px] font-black text-slate-400 uppercase"><?php echo date('d M, H:i', strtotime($r['created_at'])); ?></p>
                </div>
                <form method="POST">
                    <input type="hidden" name="approve_id" value="<?php echo $r['id']; ?>">
                    <button type="submit" class="bg-primary-600 text-white px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg shadow-primary-100">
                        Approve
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>

        <?php if(empty($requests)): ?>
            <div class="text-center py-20 bg-slate-50 rounded-[3rem] border-2 border-dashed border-slate-200">
                <p class="text-slate-400 font-bold">Babu buƙatun da ke jiran amincewa.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>