<?php
/**
 * Niger Fintech System - Advanced User Management
 */
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn() || !in_array(getCurrentUser()['user_type'], ['admin', 'super_agent'])) {
    header('Location: /login.php');
    exit;
}

$db = getDB();
$currentLang = getCurrentLanguage();
$isHausa = ($currentLang === 'ha');

// Handle Block/Unblock via AJAX-like POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_id'])) {
    if (validateCSRFToken($_POST['csrf_token'])) {
        $userId = (int)$_POST['toggle_id'];
        $db->prepare("UPDATE users SET is_active = NOT is_active WHERE id = ?")->execute([$userId]);
        logActivity('users', $userId, 'TOGGLE_STATUS');
    }
}

// Fetch Users with their primary wallet balance for the Quick View
try {
    $stmt = $db->query("
        SELECT u.*, wa.balance, wa.account_number 
        FROM users u 
        LEFT JOIN wallet_accounts wa ON u.id = wa.user_id AND wa.account_type = 'primary'
        ORDER BY u.created_at DESC 
        LIMIT 200
    ");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
}

$pageTitle = $isHausa ? 'Masu Amfani - NigerPay' : 'Utilisateurs - NigerPay';
include __DIR__ . '/includes/header.php';
?>

<div class="max-w-7xl mx-auto">
    <div class="flex flex-col md:flex-row md:items-center justify-between mb-8">
        <div>
            <h1 class="text-3xl font-black text-gray-900 tracking-tight"><?php echo $isHausa ? 'Masu Amfani' : 'Gestion Utilisateurs'; ?></h1>
            <p class="text-gray-500 text-sm mt-1"><?php echo $isHausa ? 'Gudanar da asusun abokan ciniki' : 'Gérer les comptes clients et statuts'; ?></p>
        </div>
        
        <div class="mt-4 md:mt-0 flex gap-3">
            <div class="relative">
                <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                    <i class="fas fa-search"></i>
                </span>
                <input type="text" id="userSearch" onkeyup="filterUsers()" placeholder="<?php echo $isHausa ? 'Bincika suna ko waya...' : 'Rechercher...'; ?>" 
                       class="pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-primary-500 focus:border-transparent bg-white shadow-sm w-64 transition-all">
            </div>
            <button class="bg-primary-600 hover:bg-primary-700 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-primary-200 transition-all flex items-center">
                <i class="fas fa-user-plus mr-2"></i> <?php echo $isHausa ? 'Ƙara Sabo' : 'Nouveau'; ?>
            </button>
        </div>
    </div>

    <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse" id="usersTable">
                <thead>
                    <tr class="bg-gray-50/50 text-gray-400 text-[11px] uppercase tracking-[0.15em] font-black border-b border-gray-100">
                        <th class="px-8 py-5">User</th>
                        <th class="px-8 py-5">Phone & Type</th>
                        <th class="px-8 py-5">KYC Status</th>
                        <th class="px-8 py-5">Account Status</th>
                        <th class="px-8 py-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($users as $u): ?>
                    <tr class="user-row hover:bg-primary-50/20 transition-colors group">
                        <td class="px-8 py-5">
                            <div class="flex items-center">
                                <div class="w-10 h-10 rounded-full bg-gray-100 text-gray-400 flex items-center justify-center font-bold text-xs mr-4 border border-gray-200 group-hover:border-primary-300 group-hover:text-primary-600 transition-colors">
                                    <?php echo strtoupper(substr($u['first_name'], 0, 1) . substr($u['last_name'], 0, 1)); ?>
                                </div>
                                <div>
                                    <div class="text-sm font-bold text-gray-900 name-field"><?php echo htmlspecialchars($u['first_name'] . ' ' . $u['last_name']); ?></div>
                                    <div class="text-[10px] text-gray-400 font-mono mt-0.5 uppercase tracking-tighter">Joined: <?php echo date('d M Y', strtotime($u['created_at'])); ?></div>
                                </div>
                            </div>
                        </td>
                        
                        <td class="px-8 py-5">
                            <div class="text-sm font-semibold text-gray-700 phone-field"><?php echo htmlspecialchars($u['phone_number']); ?></div>
                            <span class="text-[10px] font-black uppercase tracking-wider <?php echo $u['user_type'] === 'admin' ? 'text-red-500' : 'text-blue-500'; ?>">
                                <?php echo str_replace('_', ' ', $u['user_type']); ?>
                            </span>
                        </td>
                        
                        <td class="px-8 py-5">
                            <?php 
                                $kycColors = ['approved' => 'bg-green-100 text-green-700', 'pending' => 'bg-yellow-100 text-yellow-700', 'rejected' => 'bg-red-100 text-red-700'];
                                $kClass = $kycColors[$u['kyc_status']] ?? 'bg-gray-100 text-gray-700';
                            ?>
                            <span class="px-3 py-1 rounded-full text-[10px] font-black uppercase <?php echo $kClass; ?>">
                                <?php echo $u['kyc_status']; ?>
                            </span>
                        </td>

                        <td class="px-8 py-5">
                            <form method="POST" class="inline">
                                <?php csrfField(); ?>
                                <input type="hidden" name="toggle_id" value="<?php echo $u['id']; ?>">
                                <button type="submit" class="flex items-center group">
                                    <div class="w-10 h-5 flex items-center <?php echo $u['is_active'] ? 'bg-primary-500' : 'bg-gray-300'; ?> rounded-full p-1 duration-300 ease-in-out">
                                        <div class="bg-white w-3 h-3 rounded-full shadow-md transform <?php echo $u['is_active'] ? 'translate-x-5' : 'translate-x-0'; ?> duration-300"></div>
                                    </div>
                                    <span class="ml-3 text-[10px] font-bold text-gray-400 group-hover:text-gray-600 transition-colors uppercase">
                                        <?php echo $u['is_active'] ? ($isHausa ? 'A Buɗe' : 'Actif') : ($isHausa ? 'A Kulle' : 'Bloqué'); ?>
                                    </span>
                                </button>
                            </form>
                        </td>

                        <td class="px-8 py-5 text-right">
                            <button onclick='openQuickView(<?php echo json_encode($u); ?>)' 
                                    class="bg-gray-100 hover:bg-primary-600 text-gray-500 hover:text-white p-2.5 rounded-xl transition-all shadow-sm">
                                <i class="fas fa-eye text-sm"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="quickViewModal" class="hidden fixed inset-0 z-[60] overflow-hidden bg-gray-900/40 backdrop-blur-sm">
    <div class="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div class="w-screen max-w-md transform transition ease-in-out duration-500 sm:duration-700">
            <div class="h-full flex flex-col bg-white shadow-2xl rounded-l-3xl overflow-y-auto">
                <div class="p-8 bg-primary-600 text-white">
                    <div class="flex justify-between items-start">
                        <div class="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-2xl font-black backdrop-blur-md" id="modalInitials">--</div>
                        <button onclick="closeQuickView()" class="text-white/60 hover:text-white transition-colors">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                    <div class="mt-6">
                        <h2 class="text-2xl font-black" id="modalName">User Name</h2>
                        <p class="text-primary-100 text-sm font-bold uppercase tracking-widest mt-1" id="modalRole">Customer</p>
                    </div>
                </div>

                <div class="p-8 space-y-8">
                    <div>
                        <p class="text-xs font-black text-gray-400 uppercase tracking-widest mb-4"><?php echo $isHausa ? 'Bayanin Kuɗi' : 'Solde du Compte'; ?></p>
                        <div class="bg-gray-50 rounded-3xl p-6 border border-gray-100">
                            <p class="text-gray-400 text-[10px] font-bold uppercase tracking-tight"><?php echo $isHausa ? 'Jimillar Kuɗi' : 'Solde Actuel'; ?></p>
                            <h3 class="text-3xl font-black text-gray-900 mt-1" id="modalBalance">0 FCFA</h3>
                            <p class="text-[10px] text-primary-600 font-mono font-bold mt-2" id="modalAcc">ACC: ----</p>
                        </div>
                    </div>

                    <div class="space-y-4">
                        <p class="text-xs font-black text-gray-400 uppercase tracking-widest"><?php echo $isHausa ? 'Bayanin Sadarwa' : 'Coordonnées'; ?></p>
                        <div class="flex items-center p-4 bg-white border border-gray-100 rounded-2xl shadow-sm">
                            <div class="w-10 h-10 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center mr-4"><i class="fas fa-phone-alt"></i></div>
                            <div>
                                <p class="text-[10px] font-bold text-gray-400 uppercase">Phone</p>
                                <p class="text-sm font-bold text-gray-800" id="modalPhone">--</p>
                            </div>
                        </div>
                        <div class="flex items-center p-4 bg-white border border-gray-100 rounded-2xl shadow-sm">
                            <div class="w-10 h-10 bg-purple-50 text-purple-500 rounded-full flex items-center justify-center mr-4"><i class="fas fa-envelope"></i></div>
                            <div>
                                <p class="text-[10px] font-bold text-gray-400 uppercase">Email</p>
                                <p class="text-sm font-bold text-gray-800" id="modalEmail">--</p>
                            </div>
                        </div>
                    </div>

                    <div class="pt-6 border-t border-gray-100 flex gap-3">
                        <button class="flex-1 bg-gray-900 text-white font-black py-4 rounded-2xl shadow-lg hover:bg-black transition-all">
                            <?php echo $isHausa ? 'GYARA ASUSU' : 'MODIFIER'; ?>
                        </button>
                        <button class="w-14 bg-gray-100 text-gray-500 flex items-center justify-center rounded-2xl hover:bg-red-50 hover:text-red-500 transition-all">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Real-time Search Function
    function filterUsers() {
        let input = document.getElementById('userSearch').value.toLowerCase();
        let rows = document.querySelectorAll('.user-row');
        
        rows.forEach(row => {
            let name = row.querySelector('.name-field').innerText.toLowerCase();
            let phone = row.querySelector('.phone-field').innerText.toLowerCase();
            if (name.includes(input) || phone.includes(input)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });
    }

    // Modal Control
    function openQuickView(user) {
        document.getElementById('modalName').innerText = user.first_name + ' ' + user.last_name;
        document.getElementById('modalInitials').innerText = user.first_name[0] + user.last_name[0];
        document.getElementById('modalRole').innerText = user.user_type.replace('_', ' ');
        document.getElementById('modalPhone').innerText = user.phone_number;
        document.getElementById('modalEmail').innerText = user.email || 'N/A';
        document.getElementById('modalAcc').innerText = 'ACC: ' + (user.account_number || 'N/A');
        
        // Formating balance
        const balance = new Intl.NumberFormat('fr-FR').format(user.balance || 0);
        document.getElementById('modalBalance').innerText = balance + ' FCFA';

        document.getElementById('quickViewModal').classList.remove('hidden');
    }

    function closeQuickView() {
        document.getElementById('quickViewModal').classList.add('hidden');
    }

    // Close on escape key
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeQuickView();
    });
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>