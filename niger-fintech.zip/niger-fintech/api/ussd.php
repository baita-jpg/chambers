<?php
/**
 * Niger Fintech System - USSD API Endpoint
 * 
 * This endpoint handles USSD requests from mobile network operators.
 * Expected POST parameters:
 * - session_id: Unique session identifier
 * - phone_number: User's phone number
 * - network_code: MNO code (e.g., 'ORANGE', 'AIRTEL')
 * - input: User input (empty for new session)
 */

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/integrations.php';

// Set content type for USSD response
header('Content-Type: text/plain');

// Get parameters from request
$sessionId = $_POST['session_id'] ?? $_GET['session_id'] ?? '';
$phoneNumber = $_POST['phone_number'] ?? $_GET['phone_number'] ?? '';
$networkCode = $_POST['network_code'] ?? $_GET['network_code'] ?? '';
$input = $_POST['input'] ?? $_GET['input'] ?? '';

// Validate required parameters
if (empty($sessionId) || empty($phoneNumber)) {
    echo "END Erreur: Paramètres manquants";
    exit;
}

// Format phone number
$phoneNumber = formatPhoneNumber($phoneNumber);

// Create USSD handler and process request
$ussd = new USSDHandler($sessionId, $phoneNumber, $networkCode, $input);
echo $ussd->process();
