<?php
/**
 * Niger Fintech System - Registration Page
 */

require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $user = getCurrentUser();
    switch ($user['user_type']) {
        case 'admin':
            header('Location: /admin/dashboard.php');
            break;
        case 'agent':
        case 'super_agent':
            header('Location: /agent/dashboard.php');
            break;
        default:
            header('Location: /customer/dashboard.php');
    }
    exit;
}

$error = '';
$success = '';
$inputs = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Zama mara inganci. Da fatan za a sake gwadawa.';
    } else {
        // Sanitize inputs
        $inputs['first_name'] = sanitizeInput($_POST['first_name'] ?? '');
        $inputs['last_name'] = sanitizeInput($_POST['last_name'] ?? '');
        $inputs['phone_number'] = sanitizeInput($_POST['phone'] ?? '');
        $inputs['nina_number'] = sanitizeInput($_POST['nina_number'] ?? '');
        $pin = $_POST['pin'] ?? '';
        $pin_confirm = $_POST['pin_confirm'] ?? '';

        // Basic validation
        if (empty($inputs['first_name']) || empty($inputs['last_name']) || empty($inputs['phone_number']) || empty($pin)) {
            $error = 'Da fatan za a cika dukkan wuraren da ake bukata.';
        } elseif ($pin !== $pin_confirm) {
            $error = 'Lambobin PIN ba su dace ba.';
        } elseif (strlen($pin) < 4 || strlen($pin) > 6 || !ctype_digit($pin)) {
            $error = 'PIN dole ne ya kasance tsakanin lambobi 4 zuwa 6.';
        // Use a generic regex if validatePhoneNumber isn't defined yet
        } elseif (function_exists('validatePhoneNumber') ? !validatePhoneNumber($inputs['phone_number']) : strlen(preg_replace('/[^0-9]/', '', $inputs['phone_number'])) < 8) {
            $error = 'Tsarin lambar waya ba daidai ba ne.';
        } else {
            $userData = [
                'first_name' => $inputs['first_name'],
                'last_name' => $inputs['last_name'],
                'phone_number' => $inputs['phone_number'],
                'pin' => $pin,
                'nina_number' => $inputs['nina_number'],
                'user_type' => 'customer',
                'kyc_tier' => 1
            ];

            $result = registerUser($userData);

            if ($result['success']) {
                if (function_exists('setFlashMessage')) {
                    setFlashMessage('success', 'An yi nasarar ƙirƙirar asusunka. Yanzu za ka iya shiga.');
                }
                header('Location: login.php');
                exit;
            } else {
                $error = $result['message'];
            }
        }
    }
}

$pageTitle = 'Bude Asusu - NigerPay';
?>
<!DOCTYPE html>
<html lang="ha">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
                    colors: {
                        primary: { 50: '#f0fdfa', 100: '#ccfbf1', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e', 800: '#115e59' }
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
        .pin-input { letter-spacing: 0.5em; font-variant-numeric: tabular-nums; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .fade-in { animation: fadeIn 0.3s ease-in; }
    </style>
</head>
<body class="bg-gradient-to-br from-primary-700 via-primary-800 to-primary-900 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-lg">
        <div class="text-center mb-6 fade-in">
            <a href="/" class="inline-flex w-20 h-20 bg-white rounded-2xl items-center justify-center mx-auto mb-4 shadow-xl transition transform hover:scale-105">
                <i class="fas fa-wallet text-primary-700 text-3xl"></i>
            </a>
            <h1 class="text-2xl font-bold text-white mb-1">Bude asusun NigerPay</h1>
            <p class="text-primary-100 text-sm">Haɗa da dubban masu amfani</p>
        </div>
        
        <div class="bg-white rounded-2xl shadow-2xl overflow-hidden fade-in">
            <div class="p-6 sm:p-8">
                <h2 class="text-xl font-semibold text-gray-900 mb-1">Bayanin Keɓaɓɓu</h2>
                <p class="text-gray-500 text-sm mb-6">Don farawa, muna buƙatar wasu bayanai.</p>
                
                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-start">
                        <i class="fas fa-exclamation-circle mt-0.5 mr-2"></i>
                        <span class="text-sm font-medium"><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>
                
                <form id="registerForm" method="POST" action="" class="space-y-4" onsubmit="return handleFormSubmit(this);">
                    <?php if(function_exists('csrfField')) csrfField(); ?>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="first_name" class="block text-sm font-medium text-gray-700 mb-1">Sunan Farko</label>
                            <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($inputs['first_name'] ?? ''); ?>" required autocomplete="given-name" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition">
                        </div>
                        <div>
                            <label for="last_name" class="block text-sm font-medium text-gray-700 mb-1">Sunan Baya</label>
                            <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($inputs['last_name'] ?? ''); ?>" required autocomplete="family-name" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition">
                        </div>
                    </div>

                    <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">Lambar Waya</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-phone text-gray-400"></i>
                            </div>
                            <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($inputs['phone_number'] ?? ''); ?>" required autocomplete="tel" placeholder="XX XX XX XX" maxlength="14" oninput="formatPhoneInput(this)" class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition">
                        </div>
                    </div>

                    <div>
                        <label for="nina_number" class="block text-sm font-medium text-gray-700 mb-1">Lambar NINA (Na zaɓi)</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-id-card text-gray-400"></i>
                            </div>
                            <input type="text" id="nina_number" name="nina_number" value="<?php echo htmlspecialchars($inputs['nina_number'] ?? ''); ?>" class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition">
                        </div>
                        <p class="text-xs text-gray-500 mt-1">Ana buƙata don ƙara iyakokin ma'amalar ku (KYC).</p>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="pin" class="block text-sm font-medium text-gray-700 mb-1">Lambar PIN (lamba 4-6)</label>
                            <div class="relative">
                                <input type="password" id="pin" name="pin" required maxlength="6" inputmode="numeric" autocomplete="new-password" class="pin-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition text-center">
                                <button type="button" onclick="togglePinVisibility('pin', 'toggleIcon1')" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 focus:outline-none">
                                    <i class="fas fa-eye" id="toggleIcon1"></i>
                                </button>
                            </div>
                        </div>
                        <div>
                            <label for="pin_confirm" class="block text-sm font-medium text-gray-700 mb-1">Tabbatar da PIN</label>
                            <div class="relative">
                                <input type="password" id="pin_confirm" name="pin_confirm" required maxlength="6" inputmode="numeric" autocomplete="new-password" class="pin-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition text-center">
                                <button type="button" onclick="togglePinVisibility('pin_confirm', 'toggleIcon2')" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 focus:outline-none">
                                    <i class="fas fa-eye" id="toggleIcon2"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <p id="pin-error" class="text-red-600 text-xs hidden font-medium mt-1">Lambobin PIN ba su dace ba.</p>

                    <div class="pt-2">
                        <p class="text-xs text-gray-500 leading-relaxed">Ta hanyar bude asusu, kun yarda da <a href="/terms.php" class="text-primary-600 font-medium hover:underline">Sharuɗɗan Amfani</a> da <a href="/privacy.php" class="text-primary-600 font-medium hover:underline">Manufar Sirri</a>.</p>
                    </div>
                    
                    <button 
                        type="submit" 
                        id="submitBtn"
                        class="w-full bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3.5 px-4 rounded-lg shadow-sm transition duration-200 flex items-center justify-center mt-2"
                    >
                        <span>Bude asusu na</span>
                        <i class="fas fa-user-plus ml-2"></i>
                    </button>
                </form>
            </div>
            
            <div class="bg-gray-50 px-6 py-5 border-t border-gray-100">
                <p class="text-center text-sm text-gray-600">
                    Ka riga kana da asusu? 
                    <a href="login.php" class="text-primary-600 hover:text-primary-700 font-semibold">
                        Shiga anan
                    </a>
                </p>
            </div>
        </div>
        
        <div class="text-center mt-6 fade-in">
            <div class="inline-flex items-center text-primary-100 text-xs">
                <i class="fas fa-shield-alt mr-2"></i>
                <span>An kiyaye shi da rufaffen 256-bit | Ya dace da BCEAO</span>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle PIN visibility
        function togglePinVisibility(inputId, iconId) {
            const pinInput = document.getElementById(inputId);
            const toggleIcon = document.getElementById(iconId);
            
            if (pinInput.type === 'password') {
                pinInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                pinInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }

        // Format phone input
        function formatPhoneInput(input) {
            let value = input.value.replace(/[^\d]/g, '');
            if (value.startsWith('227')) value = value.substring(3);
            if (value.length > 8) value = value.substring(0, 8);
            if (value.length >= 2) value = value.replace(/(\d{2})(?=(\d{2})+$)/g, '$1 ');
            input.value = value;
        }
        
        // Handle form submission and Client-Side Validation
        function handleFormSubmit(form) {
            const pin1 = document.getElementById('pin').value;
            const pin2 = document.getElementById('pin_confirm').value;
            const errorText = document.getElementById('pin-error');

            // Client-side PIN match check
            if (pin1 !== pin2) {
                errorText.classList.remove('hidden');
                document.getElementById('pin_confirm').focus();
                return false; // Stop form submission
            }
            errorText.classList.add('hidden');

            // Show loading state safely
            const btn = document.getElementById('submitBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Ana bude asusu...';
            btn.classList.add('opacity-75', 'cursor-not-allowed');
            
            setTimeout(() => {
                btn.disabled = true;
            }, 10);
            
            return true;
        }
        
        // Ensure PIN inputs only accept numbers
        document.querySelectorAll('.pin-input').forEach(input => {
            input.addEventListener('input', function(e) {
                this.value = this.value.replace(/[^0-9]/g, '').slice(0, 6);
            });
        });
        
        // Auto-focus first name on load
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('first_name').focus();
        });
    </script>
</body>
</html>