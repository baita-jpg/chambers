<?php
/**
 * Niger Fintech System - Database Configuration
 * 
 * This file contains database connection settings and PDO initialization.
 * Designed for high-security, ACID-compliant transactions.
 */

// Database credentials - Change these in production!
define('DB_HOST', $_ENV['DB_HOST'] ?? 'localhost');
define('DB_NAME', $_ENV['DB_NAME'] ?? 'niger_fintech');
define('DB_USER', $_ENV['DB_USER'] ?? 'root');
define('DB_PASS', $_ENV['DB_PASS'] ?? '');
define('DB_CHARSET', 'utf8mb4');

if (!DB_HOST || !DB_NAME || !DB_USER) {
    throw new Exception("Database configuration is incomplete. Please check your environment variables.");
}

// PDO Options for security and performance
$DB_OPTIONS = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET . " COLLATE utf8mb4_unicode_ci",
    PDO::ATTR_PERSISTENT => true
];

/**
 * Get database connection
 * @return PDO
 */
function getDB() {
    static $db = null;
    
    if ($db === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $db = new PDO($dsn, DB_USER, DB_PASS, $GLOBALS['DB_OPTIONS']);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new Exception("Service temporarily unavailable");
        }
    }
    
    return $db;
}

/**
 * Begin a database transaction
 */
function beginTransaction() {
    getDB()->beginTransaction();
}

/**
 * Commit a database transaction
 */
function commitTransaction() {
    getDB()->commit();
}

/**
 * Rollback a database transaction
 */
function rollbackTransaction() {
    getDB()->rollBack();
}

/**
 * Execute query within a transaction with automatic rollback on error
 * @param callable $callback Function that receives PDO instance
 * @return mixed Result from callback
 * @throws Exception
 */
function executeInTransaction(callable $callback) {
    $db = getDB();
    
    try {
        $db->beginTransaction();
        $result = $callback($db);
        $db->commit();
        return $result;
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}
