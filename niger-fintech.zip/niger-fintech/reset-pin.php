<?php
/**
 * Niger Fintech System - Reset PIN Page
 */

require_once __DIR__ . '/includes/auth.php';

$currentLang = getCurrentLanguage();

startSecureSession();

// Redirect if user isn't in the middle of a PIN reset
if (!isset($_SESSION['reset_pending_phone'])) {
    header('Location: forgot-pin.php');
    exit;
}

$error = '';
$phoneNumber = $_SESSION['reset_pending_phone'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = ($currentLang === 'ha') ? 'Zama mara inganci. Da fatan za a sake gwadawa.' : 'Session invalide. Veuillez réessayer.';
    } else {
        $otp = $_POST['otp'] ?? '';
        $newPin = $_POST['pin'] ?? '';
        $newPinConfirm = $_POST['pin_confirm'] ?? '';

        if (empty($otp) || empty($newPin) || empty($newPinConfirm)) {
            $error = ($currentLang === 'ha') ? 'Da fatan za a cika dukkan filayen.' : 'Veuillez remplir tous les champs.';
        } elseif ($newPin !== $newPinConfirm) {
            $error = ($currentLang === 'ha') ? 'Sabbin lambobin PIN ba su dace ba.' : 'Les nouveaux codes PIN ne correspondent pas.';
        } elseif (!preg_match('/^\d{4,6}$/', $newPin)) {
            $error = ($currentLang === 'ha') ? 'PIN dole ne ya kasance tsakanin lambobi 4 zuwa 6.' : 'Le PIN doit contenir entre 4 et 6 chiffres.';
        } else {
            // Verify the OTP first
            if (verifyOTP($otp, $phoneNumber)) {
                // OTP is correct, now reset the PIN
                $result = resetUserPINByPhone($phoneNumber, $newPin);

                if ($result['success']) {
                    // Clean up session and redirect to login with a success message
                    unset($_SESSION['reset_pending_phone']);
                    $successMessage = ($currentLang === 'ha') ? 'An yi nasarar sake saita PIN ɗinka. Yanzu za ka iya shiga.' : 'Votre PIN a été réinitialisé avec succès. Vous pouvez maintenant vous connecter.';
                    setFlashMessage('success', $successMessage);
                    header('Location: /login.php');
                    exit;
                } else {
                    $error = $result['message'];
                }
            } else {
                $error = ($currentLang === 'ha') ? 'Lambar tantancewa ba daidai ba ko ta ƙare.' : 'Code de vérification incorrect ou expiré.';
            }
        }
    }
}

$pageTitle = ($currentLang === 'ha') ? 'Sake saita PIN - NigerPay' : 'Réinitialiser le PIN - NigerPay';
?>
<!DOCTYPE html>
<html <?php echo getLangAttribute(); ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', system-ui, sans-serif; }
        .pin-input { letter-spacing: 0.5em; text-align: center; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <div class="text-center mb-6">
            <a href="/" class="inline-block">
                <div class="w-16 h-16 bg-primary-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                    <i class="fas fa-wallet text-white text-2xl"></i>
                </div>
            </a>
            <h1 class="text-2xl font-bold text-gray-900"><?php echo ($currentLang === 'ha') ? 'Saita Sabon PIN' : 'Définir un nouveau PIN'; ?></h1>
            <p class="text-gray-600 mt-2"><?php echo ($currentLang === 'ha') ? 'An aiko da lamba zuwa ' . htmlspecialchars($phoneNumber) : 'Un code a été envoyé au ' . htmlspecialchars($phoneNumber); ?></p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-8">
            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-4">
                <?php csrfField(); ?>
                
                <div>
                    <label for="otp" class="block text-sm font-medium text-gray-700 mb-1">
                        <?php echo ($currentLang === 'ha') ? 'Lambar Tabbatarwa (OTP)' : 'Code de vérification (OTP)'; ?>
                    </label>
                    <input type="text" id="otp" name="otp" required inputmode="numeric" maxlength="6" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition text-lg pin-input" placeholder="------">
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="pin" class="block text-sm font-medium text-gray-700 mb-1">
                            <?php echo ($currentLang === 'ha') ? 'Sabon PIN' : 'Nouveau PIN'; ?>
                        </label>
                        <input type="password" id="pin" name="pin" required maxlength="6" inputmode="numeric" class="pin-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition">
                    </div>
                    <div>
                        <label for="pin_confirm" class="block text-sm font-medium text-gray-700 mb-1">
                            <?php echo ($currentLang === 'ha') ? 'Tabbatar da Sabon PIN' : 'Confirmer le nouveau PIN'; ?>
                        </label>
                        <input type="password" id="pin_confirm" name="pin_confirm" required maxlength="6" inputmode="numeric" class="pin-input w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition">
                    </div>
                </div>
                <p class="text-xs text-gray-500 pt-1"><?php echo ($currentLang === 'ha') ? 'PIN dole ne ya kasance tsakanin lambobi 4 zuwa 6.' : 'Le PIN doit contenir entre 4 et 6 chiffres.'; ?></p>

                <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-200 mt-2">
                    <?php echo ($currentLang === 'ha') ? 'Sake saita PIN' : 'Réinitialiser le PIN'; ?>
                </button>
            </form>
        </div>

        <div class="text-center mt-6">
            <a href="login.php" class="text-sm font-medium text-primary-600 hover:text-primary-700">
                <i class="fas fa-arrow-left mr-1"></i>
                <?php echo ($currentLang === 'ha') ? 'Komawa zuwa shiga' : 'Retour à la connexion'; ?>
            </a>
        </div>
    </div>
    <script>
        document.querySelectorAll('input[type=password], input[type=text]').forEach(input => {
            input.addEventListener('input', function(e) {
                if (this.getAttribute('inputmode') === 'numeric') {
                    this.value = this.value.replace(/[^0-9]/g, '');
                }
            });
        });
    </script>
</body>
</html>